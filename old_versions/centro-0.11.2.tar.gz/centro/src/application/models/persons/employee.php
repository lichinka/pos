<?php
require_once 'person.php';

/**
 * This class represents an employee.
 *
 * @author Matjaz Cepar
 *
 */
class Employee extends Person
{
    var $username;
    var $password;
    var $module_ids;
    var $terminal_ids;
    
	/**
     * Returns an array of headers for the export function. The column order is the same as
     * in the exported data.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     *
     * @return an array of strings
     */
    private function construct_headers ($languages)
    {
        $headers = array (
        'headers'=>array (
                           $this->lang->line ('employees_username'),
                           $this->lang->line ('employees_password')
        ),
        'language_dependant'=>array ( )
        );
        
        $person_headers = parent::export (1, array ( ), array ( ));
        $person_headers = $person_headers[0];

        return array_merge ($person_headers, $headers['headers']);
    }
    
	/**
     * Returns an array of module ids for a single person.
     *
     * @param $id is the person's database id
     * @return an array of module ids. If there aro no modules associated with
     * 			the person, the array is empty.
     */
    private function __get_module_ids ($id)
    {
        $return_value = array ( );

        //
        // Retrieve the modules that this employee may access
        //
        $this->db->select   ('terminals_modules_employees.module_id');
        $this->db->distinct ( );
        $this->db->from     ('terminals_modules_employees');
        $this->db->where    ('terminals_modules_employees.person_id =', $id);

        $query = $this->db->get ( );

        if ($query->num_rows ( ) > 0)
        {
            foreach ($query->result ( ) as $row)
            {
                array_push ($return_value, $row->module_id);
            }
        }

        return $return_value;
    }

    /**
     * Returns an array of terminal ids for a single person.
     *
     * @param $id is the person's database id
     * @return an array of terminal ids. If there aro no terminals associated with
     * 			the person, the array is empty.
     */
    private function __get_terminal_ids ($id)
    {
        $return_value = array ( );

        //
        // Retrieve the modules that this employee may access
        //
        $this->db->select   ('terminals_modules_employees.terminal_id');
        $this->db->distinct ( );
        $this->db->from     ('terminals_modules_employees');
        $this->db->where    ('terminals_modules_employees.person_id =', $id);

        $query = $this->db->get ( );

        if ($query->num_rows ( ) > 0)
        {
            foreach ($query->result ( ) as $row)
            {
                array_push ($return_value, $row->terminal_id);
            }
        }

        return $return_value;
    }

    /**
     * This is the default constructor
     *
     * @param $id:
     * 	If this parameter is supplied, the object will represent an actual database entry.
     * 	Else it will be an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ( );
        $this->load->model ('persons/Module', '', TRUE);
        $this->load->model ('company/appconfig');
        $this->load->model ('company/terminal');

        //
        // Did we receive a parameter?
        //
        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        parent::_load ($row);
         
        $this->username = $row->username;
        $this->password = $row->password;
        $this->module_ids = $this->__get_module_ids ($row->person_id);
        $this->terminal_ids = $this->__get_terminal_ids ($row->person_id);
    }
    
	/**
     * Creates an empty bag.
     *
     * @return the database id of the empty bag
     */
    protected function _insert ( )
    {
        $id = parent::_insert ( );
        
        $this->db->set ('person_id', $id);
        $this->db->set ('username', '### USERNAME ###');
        $this->db->set ('password', '### NO VALUE ###');

        $this->db->insert ('employees');

        return $id;
    }


    /**
     * This function returns a single object, that mathces the specified id.
     *
     * @param $id: is the value of the primary key in the database. Default value is -1.
     *
     * @return An instance of this class if the id exists, null otherwise.
     */
    function get_by_id ($id = -1)
    {
        if ($id == NULL)
        {
            return NULL;
        }

        $this->db->select ('*');
        $this->db->from   ('employees');
        $this->db->join   ('people', 'people.person_id = employees.person_id');
        $this->db->where  ('employees.person_id = ' . $id);
         
        $query = $this->db->get ( );

        if ($query->num_rows ( ) > 0)
        {
            $this->_load ($query->row ( ));

            return ($this);
        }
        else
        {
            return (NULL);
        }
    }

    /**
     * Returns an array containing all existing items.
     *
     * @return Always returns an array. If there are no items the array is empty.
     */
    function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('employees');

        foreach ($query->result ( ) as $row)
        {
            $employee = new Employee ($row->person_id);
            array_push ($ret_value, $employee);
        }

        return ($ret_value);
    }


    /**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @return 	A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ( )
    {
    	return parent::get_valid_id ("employees", "person_id");
    }
    
	/**
     * Deletes all elements and any relation that has foreign keys to this model.
     */
    public function purge ( )
    {
        //
        // delete the sales data first
        //
        $this->db->empty_table ('sales_payments');
        $this->db->empty_table ('sales_details_taxes');
        $this->db->empty_table ('sales_details');
        $this->db->empty_table ('sales');
        
        $ids = array ( );
        foreach ($this->get_all ( ) as $employee)
        {
            array_push ($ids, $employee->id);
        }
        
        $this->db->where_in ('person_id ', $ids);
        $this->db->delete   ('employees');
        
        $this->db->where_in ('person_id ', $ids);
        $this->db->delete   ('people');
    }    
    
    /**
     * Checks if the object exists in the database.
     *
     * @param $id is the database id. If no id is given, the function will check the
     * 	database for the instance of this object.
     *
     * @return true, it exists, false otherwise
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Employee ($this->id);
        }
        else
        {
            $o = new Employee ($id);
        }

        return $o->get_by_id($o->id) != NULL;
    }
    
	/**
     * This function exports the model into a matrix.
     *
     * @param $mode is the exporting mode (only the number 1 is allowed)
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Person intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    public function export ($mode, $languages, $entities = NULL)
    {
        if ($mode != '1')
        {
            throw new Exception ('The exporting mode ' . $mode . ' is not supported.');
        }
        
        if ($entities === NULL)
        {
            $employees = array ($this);
        }
        else
        {
            $employees = $entities;
        }
        
        $employees_rows = array ($this->construct_headers ($languages));
        
        foreach ($employees as $employee)
        {
            $employee_row = parent::export ($mode, $languages, array ($employee));
            $employee_row = $employee_row[1];
            
            array_push ($employee_row, $employee->username);
            
            //TODO: export hashed passwords?
            array_push ($employee_row, '');
            
            array_push ($employees_rows, $employee_row);
        }
        
        return $employees_rows;
    }
    
	/**
     * Imports the flat data into the database.
     *
     * @param $mode is the importing mode
     * @param $data a matrix (array of array), where the outer index represents rows and the
     * 		  inner index represents columns. This paramater is without headers.
     * @param $languages is an array of languages, sorted in the same way as are the columns
     * 		  int the data parameter
     */
    public function import_flat ($mode, $data, $languages)
    {
        if ($mode == 1)
        {
            $this->purge ( );
        }
        
        foreach ($data as $row)
        {
            $employee = new Employee ($row[0]);
            //
            // FIXME: Issue #36
            //
            $employee->id             = $row[0];
            $employee->first_name     = $row[1];
            $employee->last_name      = $row[2];
            $employee->phone_number   = $row[3];
            $employee->email          = $row[4];
            $employee->address_1      = $row[5];
            $employee->address_2      = $row[6];
            $employee->city           = $row[7];
            $employee->state          = $row[8];
            $employee->zip_code       = $row[9];
            $employee->country        = $row[10];
            $employee->comments       = $row[11];
            
            $employee->username = $row[12];
            if (strlen ($row[13]) > 0)
            {
                $employee->password = md5 ($row[13]);
            }
            else
            {
                //
                // TODO: define a default password
                //
                $employee->password = md5 ('87654321');
            }
            
            
            if ($employee->exists ( ))
            {
                if ($mode == 1 || $mode == 2)
                {
                    $employee->update ( );
                }
            }
            else
            {
                $employee->update ( );
            }
        }
    }

    /**
     * Synchronizes the database with this object.
     */
    public function update ( )
    {
        $this->db->trans_start ( );

        $ret_value = parent::update ( );

        $this->db->set    ('username', $this->username);
        $this->db->set    ('password', $this->password);
        $this->db->where  ('person_id =', $this->id);
        $this->db->update ('employees');
        
        $ret_value |= ($this->db->affected_rows ( ) > 0);

        //
        // First clear all the permission and set the new or reset the old
        // ones. There is no other way to delete permissions.
        // TODO: Change this, if we want to have the proper return value.
        //       NOW WE DON'T
        //
        $this->db->delete('terminals_modules_employees', array('person_id' => $this->id));
        foreach ($this->get_modules ( ) as $module)
        {
            foreach ($this->get_terminals ( ) as $terminal)
            {
                $this->db->set    ('module_id',   $module->id);
                $this->db->set    ('person_id',   $this->id);
                $this->db->set    ('terminal_id', $terminal->id);
                
                $this->db->insert ('terminals_modules_employees');
            }
        }

        $this->db->trans_complete ( );
        
        //
        // Return value
        //
        return ($ret_value);
    }


    /**
     * Attempts to login employee and set session.
     * Returns boolean based on outcome.
     */
    function login ($username, $password)
    {
        $this_terminal = new Terminal ($this->appconfig->get ('this_terminal'));
        $password = md5($password);
        $employees = $this->get_all ( );

        foreach ($employees as $employee)
        {
            if ($employee->username == $username && $employee->password == $password)
            {
                foreach ($employee->get_modules ( ) as $module)
                {
                    foreach ($employee->get_terminals ( ) as $terminal)
                    {
                        if ($terminal->id == $this_terminal->id)
                        {
                            //
                            // Save the ID of the logged in employee in a cookie during the session
                            //
                            $this->session->set_userdata ('employee_id', $employee->id);

                            return (TRUE);
                        }
                    }
                }
            }
        }


        $this->logout ( );
        return (FALSE);
    }


    /**
     * Logs out the current employee by deleting
     * all session data and redirect to login.-
     */
    function logout ( )
    {
        //
        // Clean the session data that holds the logged in employee
        //
        $this->session->sess_destroy ( );
    }


    /**
     * Returns TRUE if this employee is currently logged in.-
     */
    function is_logged_in ( )
    {
        return ($this->session->userdata ('employee_id') != FALSE);
    }


    /**
     * Checks if this employee has access the specific module.
     *
     * @param $module_name: is the name of the module
     * @return true, if the employee can acces the specific module, false otherwise
     */
    function has_permission ($module_name)
    {
        //
        // If module name is empty, allow access
        //
        if ($module_name == NULL)
        {
            return (TRUE);
        }
        else if ($this->module_ids != NULL)
        {
            $found = FALSE;

            //
            // Look for the matching module name
            //
            foreach ($this->get_modules ( ) as $module)
            {
                if ($module->name == $module_name)
                {
                    $found = TRUE;
                    break;
                }
            }

            return ($found);
        }
        else
        {
            return (FALSE);
        }
    }

    /**
     * Returns an array of modules, that the person can access in this terminal
     *
     * @return an array, it may be empty
     */
    function get_active_modules ( )
    {
        $ret_value = array ( );
        $this_terminal = new Terminal ($this->appconfig->get('this_terminal'));

        $this->db->distinct ('mo.module_id');
        $this->db->from     ('modules AS mo');
        $this->db->join     ('terminals_modules_employees AS per', 'mo.module_id = per.module_id');
        $this->db->where    ('per.terminal_id =', $this_terminal->id);
        $this->db->where    ('per.person_id =', $this->id);
        $this->db->order_by ('mo.sort', 'ASC');

        $query = $this->db->get ( );

        foreach ($query->result ( ) as $row)
        {
            array_push ($ret_value, new Module ($row->module_id));
        }



        return $ret_value;
    }

    /**
     * Returns an array of module instances, as defined in the module_ids attribute.
     *
     * @return an array of module instances. It can be empty.
     */
    public function get_modules ( )
    {
        $ret_value = array ( );

        if (!($this->module_ids === NULL))
        {
            foreach ($this->module_ids as $module_id)
            {
                array_push ($ret_value, new Module($module_id));
            }
        }

        return $ret_value;
    }

    /**
     * Returns an array of terminal instances, as defined in the terminal_ids attribute.
     *
     * @return an array of Terminal instances. It can be empty.
     */
    public function get_terminals ( )
    {
        $ret_value = array ( );

        if (!($this->terminal_ids === NULL))
        {
            foreach ($this->terminal_ids as $terminal_id)
            {
                array_push ($ret_value, new Terminal($terminal_id));
            }
        }

        return $ret_value;
    }

    /**
     * Returns information about a particular employee.-
     * @deprecated
     */
    function get_info ($employee_id)
    {
        $this->db->from	('employees');
        $this->db->join	('people', 'people.person_id = employees.person_id');
        $this->db->where('employees.person_id', $employee_id);

        $query = $this->db->get();

        if ($query->num_rows ( ) == 1)
        {
            return $query->row ( );
        }
        else
        {
            //Get empty base parent object, as $employee_id is NOT an employee
            $person_obj=parent::get_info(-1);

            //Get all the fields from employee table
            $fields = $this->db->list_fields('employees');

            //append those fields to base parent object, we we have a complete empty object
            foreach ($fields as $field)
            {
                $person_obj->$field='';
            }

            return $person_obj;
        }
    }

    /**
     * Gets information about multiple employees
     * @deprecated
     */
    function get_multiple_info ($employee_ids)
    {
        $this->db->from('employees');
        $this->db->join('people', 'people.person_id = employees.person_id');
        $this->db->where_in('employees.person_id',$employee_ids);
        $this->db->order_by("last_name", "asc");
        return $this->db->get();
    }

    /**
     * Deletes one employee.-
     * @deprecated
     */
    function delete ($employee_id)
    {
        $success=false;

        //Don't let employee delete their self
        if($employee_id==$this->get_logged_in_employee_info()->person_id)
        return false;

        //Run these queries as a transaction, we want to make sure we do all or nothing
        $this->db->trans_start();

        //Delete permissions
        if($this->db->delete('permissions', array('person_id' => $employee_id)))
        {
            //delete from employee table
            if($this->db->delete('employees', array('person_id' => $employee_id)))
            {
                //delete from person table
                $success = parent::delete($employee_id);
            }
        }
        $this->db->trans_complete();
        return $success;
    }

    /**
     * Deletes a list of employees.-
     * @deprecated
     */
    function delete_list($employee_ids)
    {
        $success=false;

        //Don't let employee delete their self
        if(in_array($this->get_logged_in_employee_info()->person_id,$employee_ids))
        return false;

        //Run these queries as a transaction, we want to make sure we do all or nothing
        $this->db->trans_start();

        $this->db->where_in('person_id',$employee_ids);
        //Delete permissions
        if ($this->db->delete('terminals_modules_employees'))
        {
            //delete from employee table
            $this->db->where_in('person_id',$employee_ids);
            if ($this->db->delete('employees'))
            {
                //delete from person table
                $success = parent::delete_list($employee_ids);
            }
        }
        $this->db->trans_complete();
        return $success;
    }

    /**
     * Get search suggestions to find employees.-
     * @deprecated
     */
    function get_search_suggestions($search,$limit=5)
    {
        $suggestions = array();

        $this->db->from('employees');
        $this->db->join('people','employees.person_id=people.person_id');
        $this->db->like('first_name', $search);
        $this->db->or_like('last_name', $search);
        $this->db->or_like("CONCAT(`first_name`,' ',`last_name`)",$search);
        $this->db->order_by("last_name", "asc");
        $by_name = $this->db->get();
        foreach($by_name->result() as $row)
        {
            $suggestions[]=$row->first_name.' '.$row->last_name;
        }

        $this->db->from('employees');
        $this->db->join('people','employees.person_id=people.person_id');
        $this->db->like("email",$search);
        $this->db->order_by("email", "asc");
        $by_email = $this->db->get();
        foreach($by_email->result() as $row)
        {
            $suggestions[]=$row->email;
        }

        $this->db->from('employees');
        $this->db->join('people','employees.person_id=people.person_id');
        $this->db->like("username",$search);
        $this->db->order_by("username", "asc");
        $by_username = $this->db->get();
        foreach($by_username->result() as $row)
        {
            $suggestions[]=$row->username;
        }


        $this->db->from('employees');
        $this->db->join('people','employees.person_id=people.person_id');
        $this->db->like("phone_number",$search);
        $this->db->order_by("phone_number", "asc");
        $by_phone = $this->db->get();
        foreach($by_phone->result() as $row)
        {
            $suggestions[]=$row->phone_number;
        }


        //only return $limit suggestions
        if(count($suggestions > $limit))
        {
            $suggestions = array_slice($suggestions, 0,$limit);
        }
        return $suggestions;

    }


    /**
     * Preform a search on employees
     * @deprecated
     */
    function search($search)
    {
        $this->db->from('employees');
        $this->db->join('people','employees.person_id=people.person_id');
        $this->db->like('first_name', $search);
        $this->db->or_like('last_name', $search);
        $this->db->or_like('email', $search);
        $this->db->or_like('phone_number', $search);
        $this->db->or_like("CONCAT(`first_name`,' ',`last_name`)",$search);
        $this->db->or_like('username', $search);
        $this->db->order_by("last_name", "asc");

        return $this->db->get();
    }


    /**
     * Gets information about the currently logged in employee.
     * @deprecated
     */
    function get_logged_in_employee_info()
    {
        if($this->is_logged_in())
        {
            return $this->get_info($this->session->userdata('person_id'));
        }

        return false;
    }
}
?>

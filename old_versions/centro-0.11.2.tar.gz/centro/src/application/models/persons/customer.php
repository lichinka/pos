<?php
require_once 'person.php';

/**
 * This class represents a customer.
 *
 * @author Matjaz Cepar
 *
 */
class Customer extends Person
{
    var $account_number;
    
    /**
     * Returns an array of headers for the export function. The column order is the same as
     * in the exported data.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     *
     * @return an array of strings
     */
    private function construct_headers ($languages)
    {
        $headers = array (
        'headers'=>array (
                           $this->lang->line ('customers_account_number')
        ),
        'language_dependant'=>array ( )
        );
        
        $person_headers = parent::export (1, array ( ), array ( ));
        $person_headers = $person_headers[0];

        return array_merge ($person_headers, $headers['headers']);
    }

    /**
     * This is the default constructor
     * @param $id:
     * 	If this parameter is supplied, the object will represent an actual database entry.
     * 	Else it will be an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ( );

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        parent::_load ($row);
         
        $this->account_number = $row->account_number;
    }

    
    /**
     * Creates an empty bucket.-
     *
     * @return the database id of the empty bucket.-
     */
    protected function _insert ( )
    {
        $id = parent::_insert ( );

        $this->db->set    ('person_id', $id);
        $this->db->set    ('account_number', '### NO VALUE ###');
        $this->db->insert ('customers');

        return $id;
    }
    

    /**
     * This function returns a single object, that mathces the specified id.
     * @param $id: is the value of the primary key in the database. Default value is -1.
     * @return An instance of this class if the id exists, null otherwise.
     */
    function get_by_id ($id = -1)
    {
        if ($id == NULL)
        {
            return NULL;
        }

        $this->db->select ('people.person_id, people.first_name, people.last_name, ' .
		'people.phone_number, people.email, people.address_1, people.address_2, ' .
		'people.city, people.state, people.zip, people.country, people.comments, ' .
		'customers.account_number');
        $this->db->from   ('customers');
        $this->db->join   ('people', 'people.person_id = customers.person_id');
        $this->db->where  ('customers.person_id =', $id);
         
        $query = $this->db->get ( );
         
        if ($query->num_rows ( ) > 0)
        {
            $this->_load ($query->row ( ));
            return ($this);
        }
        else
        {
            return (NULL);
        }
    }

    
    /**
     * Returns an array of objects that CONTAIN any of the given parameters.-
     * 
     * @param $first_name   A string contained in the first name of the 
     *                      searched customer. Defaults to NULL.-
     * @param $last_name    A string contained in the last name of the 
     *                      searched customer. Defaults to NULL.-
     * @return              An array of objects that CONTAIN any of the given
     *                      parameters or an empty array if nothing has been
     *                      found.-
     */
    function get_by_name ($first_name = NULL, $last_name = NULL)
    {
        $ret_value = array ( );

        //
        // Did we get any valid parameters?
        //
        if ($first_name != NULL)
        {
	        $this->db->select ('people.person_id');
	        $this->db->from   ('people');
	        $this->db->join   ('customers','customers.person_id = people.person_id');
	        $this->db->like   ('LOWER (first_name)', strtolower ($first_name));
	        
	        //
	        // Is the second parameter also valid?
	        //
	        if ($last_name != NULL)
	        {
	           $this->db->or_like ('LOWER (last_name)', strtolower ($last_name));
	        }
	
	        $query = $this->db->get ( );
	
	        foreach ($query->result ( ) as $row)
	        {
	            $customer = new Customer ($row->person_id);
	            array_push ($ret_value, $customer);
	        }
        }

        return ($ret_value);
    }
    
    
    
    /**
     * Returns an array containing all existing items.
     * @return Always returns an array. If there are no items the array is empty.
     */
    public function get_all ( )
    {
        $ret_value = array ( );

        $this->db->select ('people.person_id');
        $this->db->from   ('people');
        $this->db->join   ('customers','customers.person_id = people.person_id');

        $query = $this->db->get ( );

        foreach ($query->result ( ) as $row)
        {
            $customer = new Customer ($row->person_id);
            array_push ($ret_value, $customer);
        }

        return ($ret_value);
    }


    /**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @return 	A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ( )
    {
    	return parent::get_valid_id ("customers", "person_id");
    }
    
    /**
     * Deletes all elements and any relation that has foregin keys to this model.
     */
    public function purge ( )
    {
        //
        // delete the sales data first
        //
        $this->db->empty_table ('sales_payments');
        $this->db->empty_table ('sales_details_taxes');
        $this->db->empty_table ('sales_details');
        $this->db->empty_table ('sales');
        
        $ids = array ( );
        foreach ($this->get_all ( ) as $customer)
        {
            array_push ($ids, $customer->id);
        }
        
        $this->db->where_in ('person_id ', $ids);
        $this->db->delete   ('customers');
        
        $this->db->where_in ('person_id ', $ids);
        $this->db->delete   ('people');
    }
    
    /**
     * Checks if the object exists in the database.
     *
     * @param $id is the database id. If no id is given, the function will check the
     * 	database for the instance of this object.
     *
     * @return true, it exists, false otherwise
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Customer ($this->id);
        }
        else
        {
            $o = new Customer ($id);
        }

        return ($o->get_by_id($o->id) != NULL);
    }
    
    
	/**
     * This function exports the model into a matrix.
     *
     * @param $mode is the exporting mode (only the number 1 is allowed)
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Person intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    public function export ($mode, $languages, $entities = NULL)
    {
        if ($mode != '1')
        {
            throw new Exception ('The exporting mode ' . $mode . ' is not supported.');
        }
        
        if ($entities === NULL)
        {
            $customers = array ($this);
        }
        else
        {
            $customers = $entities;
        }
        
        $customers_rows = array ($this->construct_headers ($languages));
        
        foreach ($customers as $customer)
        {
            $customer_row = parent::export ($mode, $languages, array ($customer));
            $customer_row = $customer_row[1];
            
            array_push ($customer_row, $customer->account_number);
            
            array_push ($customers_rows, $customer_row);
        }
        
        return $customers_rows;
    }
    
    /**
     * Imports the flat data into the database.
     *
     * @param $mode is the importing mode
     * @param $data a matrix (array of array), where the outer index represents rows and the
     * 		  inner index represents columns. This paramater is without headers.
     * @param $languages is an array of languages, sorted in the same way as are the columns
     * 		  int the data parameter
     */
    public function import_flat ($mode, $data, $languages)
    {
        if ($mode == 1)
        {
            $this->purge ( );
        }
        
        foreach ($data as $row)
        {
            $customer = new Customer ($row[0]);
            //
            // FIXME: Issue #36
            //
            $customer->id             = $row[0];
            $customer->first_name     = $row[1];
            $customer->last_name      = $row[2];
            $customer->phone_number   = $row[3];
            $customer->email          = $row[4];
            $customer->address_1      = $row[5];
            $customer->address_2      = $row[6];
            $customer->city           = $row[7];
            $customer->state          = $row[8];
            $customer->zip_code       = $row[9];
            $customer->country        = $row[10];
            $customer->comments       = $row[11];
            
            $customer->account_number = $row[12];
            
            
            if ($customer->exists ( ))
            {
                if ($mode == 1 || $mode == 2)
                {
                    $customer->update ( );
                }
            }
            else
            {
                $customer->update ( );
            }
        }
    }
    

    /**
     * Synchronizes the database with this object.
     */
    public function update ( )
    {
        $ret_value = parent::update ( );
         
        $this->db->set    ('account_number', $this->account_number);
        $this->db->where  ('person_id =',    $this->id);
        
        $this->db->update ('customers');
        
        $ret_value |= ($this->db->affected_rows ( ) > 0);
        
        //
        // Return value
        //
        return ($ret_value);
    }

    
    /**
     * Gets information about a particular customer
     * @deprecated
     */
    function get_info($customer_id)
    {
        $this->db->from('customers');
        $this->db->join('people', 'people.person_id = customers.person_id');
        $this->db->where('customers.person_id',$customer_id);
        $query = $this->db->get();

        if($query->num_rows()==1)
        {
            return $query->row();
        }
        else
        {
            //Get empty base parent object, as $customer_id is NOT an customer
            $person_obj=parent::get_info(-1);

            //Get all the fields from customer table
            $fields = $this->db->list_fields('customers');

            //append those fields to base parent object, we we have a complete empty object
            foreach ($fields as $field)
            {
                $person_obj->$field='';
            }

            return $person_obj;
        }
    }

    /**
     * Gets information about multiple customers
     * @deprecated
     */
    function get_multiple_info($customer_ids)
    {
        $this->db->from('customers');
        $this->db->join('people', 'people.person_id = customers.person_id');
        $this->db->where_in('customers.person_id',$customer_ids);
        $this->db->order_by("last_name", "asc");
        return $this->db->get();
    }

    /**
     * Inserts or updates a customer
     * @deprecated
     */
    function save(&$person_data, &$customer_data,$customer_id=false)
    {
        $success=false;
        //Run these queries as a transaction, we want to make sure we do all or nothing
        $this->db->trans_start();

        if(parent::save($person_data,$customer_id))
        {
            if (!$customer_id or !$this->exists($customer_id))
            {
                $customer_data['person_id'] = $person_data['person_id'];
                $success = $this->db->insert('customers',$customer_data);
            }
            else
            {
                $this->db->where('person_id', $customer_id);
                $success = $this->db->update('customers',$customer_data);
            }

        }

        $this->db->trans_complete();
        return $success;
    }

    /**
     * Deletes one customer
     * @deprecated
     */
    function delete($customer_id)
    {
        $success=false;

        //Run these queries as a transaction, we want to make sure we do all or nothing
        $this->db->trans_start();

        //delete from customers table
        if($this->db->delete('customers', array('person_id' => $customer_id)))
        {
            //delete from Person table
            $success = parent::delete($customer_id);
        }

        $this->db->trans_complete();
        return $success;
    }

    /**
     * Deletes a list of customers
     * @deprecated
     */
    function delete_list($customer_ids)
    {
        $success=false;

        //Run these queries as a transaction, we want to make sure we do all or nothing
        $this->db->trans_start();

        $this->db->where_in('person_id',$customer_ids);
        if ($this->db->delete('customers'))
        {
            $success = parent::delete_list($customer_ids);
        }

        $this->db->trans_complete();
        return $success;
    }

    /**
     * Get search suggestions to find customers
     * @deprecated
     */
    function get_search_suggestions($search,$limit=25)
    {
        $suggestions = array();

        $this->db->from('customers');
        $this->db->join('people','customers.person_id=people.person_id');
        $this->db->like('first_name', $search);
        $this->db->or_like('last_name', $search);
        $this->db->or_like("CONCAT(`first_name`,' ',`last_name`)",$search);
        $this->db->order_by("last_name", "asc");
        $by_name = $this->db->get();
        foreach($by_name->result() as $row)
        {
            $suggestions[]=$row->first_name.' '.$row->last_name;
        }

        $this->db->from('customers');
        $this->db->join('people','customers.person_id=people.person_id');
        $this->db->like("email",$search);
        $this->db->order_by("email", "asc");
        $by_email = $this->db->get();
        foreach($by_email->result() as $row)
        {
            $suggestions[]=$row->email;
        }

        $this->db->from('customers');
        $this->db->join('people','customers.person_id=people.person_id');
        $this->db->like("phone_number",$search);
        $this->db->order_by("phone_number", "asc");
        $by_phone = $this->db->get();
        foreach($by_phone->result() as $row)
        {
            $suggestions[]=$row->phone_number;
        }

        $this->db->from('customers');
        $this->db->join('people','customers.person_id=people.person_id');
        $this->db->like("account_number",$search);
        $this->db->order_by("account_number", "asc");
        $by_account_number = $this->db->get();
        foreach($by_account_number->result() as $row)
        {
            $suggestions[]=$row->account_number;
        }

        //only return $limit suggestions
        if(count($suggestions > $limit))
        {
            $suggestions = array_slice($suggestions, 0,$limit);
        }
        return $suggestions;

    }

    /**
     * Get search suggestions to find customers
     * @deprecated
     */
    function get_customer_search_suggestions($search,$limit=25)
    {
        $suggestions = array();

        $this->db->from('customers');
        $this->db->join('people','customers.person_id=people.person_id');
        $this->db->like('first_name', $search);
        $this->db->or_like('last_name', $search);
        $this->db->or_like("CONCAT(`first_name`,' ',`last_name`)",$search);
        $this->db->order_by("last_name", "asc");
        $by_name = $this->db->get();
        foreach($by_name->result() as $row)
        {
            $suggestions[]=$row->person_id.'|'.$row->first_name.' '.$row->last_name;
        }

        //only return $limit suggestions
        if(count($suggestions > $limit))
        {
            $suggestions = array_slice($suggestions, 0,$limit);
        }
        return $suggestions;

    }
}
?>

<?php
require_once 'application/models/entity.php';

/**
 * This abstract class defines a person. It cannot have any methods, that require to
 * create a new object.
 *
 * @author Matjaz Cepar
 *
 */
abstract class Person extends Entity
{
    var $id;
    var $first_name;
    var $last_name;
    var $phone_number;
    var $email;
    var $address_1;
    var $address_2;
    var $city;
    var $state;
    var $zip_code;
    var $country;
    var $comments;
    
    
	/**
     * Returns an array of headers for the export function. The column order is the same as
     * in the exported data.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     *
     * @return an array of strings
     */
    private function construct_headers ($languages)
    {
        $headers = array (
        'headers'=>array (
                          $this->lang->line ('common_id'),
                          $this->lang->line ('common_first_name'),
                          $this->lang->line ('common_last_name'),
                          $this->lang->line ('common_phone_number'),
                          $this->lang->line ('common_email'),
                          $this->lang->line ('common_address_1'),
                          $this->lang->line ('common_address_2'),
                          $this->lang->line ('common_city'),
                          $this->lang->line ('common_state'),
                          $this->lang->line ('common_zip'),
                          $this->lang->line ('common_country'),
                          $this->lang->line ('common_comments')
        ),
        'language_dependant'=>array ( )
        );

        return $headers['headers'];
    }

    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        $this->id 			= $row->person_id;
        $this->first_name	= $row->first_name;
        $this->last_name	= $row->last_name;
        $this->phone_number	= $row->phone_number;
        $this->email		= $row->email;
        $this->address_1	= $row->address_1;
        $this->address_2	= $row->address_2;
        $this->city			= $row->city;
        $this->state		= $row->state;
        $this->zip_code    	= $row->zip;
        $this->country		= $row->country;
        $this->comments		= $row->comments;
    }


    /**
     * Creates an empty bucket.-
     *
     * @return the database id of the empty bucket.-
     */
    protected function _insert ( )
    {
        if ($this->id != NULL)
        {
            $this->db->set ('person_id', $this->id);
        }
        $this->db->set ('first_name', '### NO VALUE ###');
        $this->db->set ('last_name',  '### NO VALUE ###');

        $this->db->insert ('people');

        return $this->db->insert_id ( );
    }

    
    /**
     * Synchronizes the database with this object instance.-
     * 
     * @return TRUE on success, FALSE otherwise.-
     */
    public function update ( )
    {
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }

        //
        // Set the table row data as in the current instance
        //
        $this->db->set    ('first_name',    $this->first_name);
        $this->db->set    ('last_name',     $this->last_name);
        $this->db->set    ('phone_number',  $this->phone_number);
        $this->db->set    ('email',         $this->email);
        $this->db->set    ('address_1',     $this->address_1);
        $this->db->set    ('address_2',     $this->address_2);
        $this->db->set    ('city',          $this->city);
        $this->db->set    ('state',         $this->state);
        $this->db->set    ('zip',           $this->zip_code);
        $this->db->set    ('country',       $this->country);
        $this->db->set    ('comments',      $this->comments);

        //
        // Change this row only
        //
        $this->db->where  ('person_id =', $this->id);
        $this->db->update ('people');

        //
        // Return value
        //
        return ($this->db->affected_rows ( ) > 0);
    }
    
    /**
     * This function exports the model into a matrix.
     *
     * @param $mode is the exporting mode (only the number 1 is allowed)
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Person intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    public function export ($mode, $languages, $entities = NULL)
    {
        if ($mode != '1')
        {
            throw new Exception ('The exporting mode ' . $mode . ' is not supported.');
        }
        
        if ($entities === NULL)
        {
            $people = array ($this);
        }
        else
        {
            $people = $entities;
        }
        
        $people_rows = array ($this->construct_headers ($languages));
        
        foreach ($people as $person)
        {
            $person_row = array ( );
            
            array_push ($person_row, $person->id);
            array_push ($person_row, $person->first_name);
            array_push ($person_row, $person->last_name);
            array_push ($person_row, $person->phone_number);
            array_push ($person_row, $person->email);
            array_push ($person_row, $person->address_1);
            array_push ($person_row, $person->address_2);
            array_push ($person_row, $person->city);
            array_push ($person_row, $person->state);
            array_push ($person_row, $person->zip_code);
            array_push ($person_row, $person->country);
            array_push ($person_row, $person->comments);
            
            array_push ($people_rows, $person_row);
        }
        
        return $people_rows;
    }
    
    
    /**
     * Gets information about a person as an array.
     * @deprecated
     */
    function get_info($person_id)
    {
        $query = $this->db->get_where('people', array('person_id' => $person_id), 1);

        if($query->num_rows()==1)
        {
            return $query->row();
        }
        else
        {
            //create object with empty properties.
            $fields = $this->db->list_fields('people');
            $person_obj = new stdClass;

            foreach ($fields as $field)
            {
                $person_obj->$field='';
            }

            return $person_obj;
        }
    }
    


    /**
     * Get people with specific ids
     * @deprecated
     */
    function get_multiple_info($person_ids)
    {
        $this->db->from('people');
        $this->db->where_in('person_id',$person_ids);
        $this->db->order_by("last_name", "asc");
        return $this->db->get();
    }

    /**
     * Inserts or updates a person
     * @deprecated
     */
    function save(&$person_data,$person_id=false)
    {
        if (!$person_id or !$this->exists($person_id))
        {
            if ($this->db->insert('people',$person_data))
            {
                $person_data['person_id']=$this->db->insert_id();
                return true;
            }

            return false;
        }

        $this->db->where('person_id', $person_id);
        return $this->db->update('people',$person_data);
    }

    /**
     * Deletes one Person
     * @deprecated
     */
    function delete($person_id)
    {
        return $this->db->delete('people', array('person_id' => $person_id));
    }

    /**
     * Deletes a list of people
     * @deprecated
     */
    function delete_list($person_ids)
    {
        $this->db->where_in('person_id',$person_ids);
        return $this->db->delete('people');
    }

}
?>

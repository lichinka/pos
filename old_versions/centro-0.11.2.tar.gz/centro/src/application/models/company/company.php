<?php
require_once 'application/models/entity.php';


/**
 * This class represents a company.-
 *
 * @author luka
 *
 */
class Company extends Entity
{
    var $id;
    var $name;
    var $address;
    var $identification;

    
    /**
     * Constructor.-
     *
     * @param $id The ID of the object being constructed, which data 
     *            is to be loaded from the database. Defaults to an 
     *            empty instance.-
     */
    function __construct ($id = NULL)
    {
        parent::__construct ($id);

        //
        // Set the table name and define
        // the attribute <=> column relation.
        //
        $this->table_name        = 'company';
        $this->column_definition = array ('id'             => 'company_id',
                                          'name'           => 'name',
                                          'address'        => 'address',
                                          'identification' => 'identification');
        
        //
        // Try to load an object instance if an ID was given
        //
        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }
}

?>

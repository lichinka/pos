<?php

/**
 * This class represents every object that may be
 * mapped to a row of a table in the database.-
 * 
 * @author luka
 *
 */
abstract class Entity extends Model
{
	//
	// The table name, where this object is mapped to.
	//
	var $table_name;
	
	//
	// An array containing the attribute => column_name
	// definition of this object.
	// The attribute name for the ID column should always be 'id'.
	// For example:
	//
	// $column_definition = array ('id'   => 'company_id',
	//                             'name' => 'name',
	//                             ...)
	//
	// where the array $key is the attribute name, and the
	// $value is the column name in the database table.
	//
	var $column_definition;
	
    //
    // An array containing the foreign key definitions of this object.
    // The $key of the array is the class name of the foreign key relation
    // table. For example (for table Stores):
    //
    // $foreign_keys = array ('Company' => 'company_id');
    //
    // where 'company_id' is the attribute name that holds the the foreign 
    // key relation in the CURRENT class.
    //
    var $foreign_keys;
	
	
    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     *
     * @param $row is a single database row
     */
	protected function _load ($row)
	{
		//
		// Copy the content from the table row to the attributes
		//
        foreach ($this->column_definition as $attribute => $column)
        {
        	$this->$attribute = $row->$column;
        }
	}

	
    /**
     * Creates an empty bucket.-
     *
     * @return The row ID of the empty bucket created.-
     */
    protected function _insert ( )
    {
    	//
    	// Set some default values for all columns
    	//
        foreach ($this->column_definition as $column)
        {
            $this->db->set ($column, '-1 | ### NO VALUE ###');
        }
    	
        //
        // Get valid IDs for the (possible) foreign keys
        //
        foreach ($this->foreign_keys as $class_name => $attribute)
        {
        	//
        	// Create an object of the foreign-key class
        	//
        	$foreign_object = new $class_name;
        	
        	//
        	// Ask the object for a valid ID, that will enable
        	// us to create an empty bucket in this table without
        	// breaking the foreign-key relation
        	//
        	$this->db->set ($this->column_definition[$attribute], 
        	                $foreign_object->get_valid_id ( ));
        }
        
    	//
    	// Keep the current ID, if we already have one.
    	// If it is NULL, it will activate the database 
    	// AUTO INCREMENT feature.-
    	//
        $this->db->set ($this->column_definition['id'], $this->id);

        //
        // Insert the new empty row in the table
        //
        $this->db->insert ($this->table_name);

        //
        // Return the ID of the inserted row
        //
        return $this->db->insert_id ( );
    }
    
    
    /**
     * Constructor.-
     *
     * @param $id The ID of the object being constructed, which data 
     *            is to be loaded from the database. Defaults to an 
     *            empty instance.-
     */
    function __construct ($id = NULL)
    {
        parent::Model ( );
    }

    
    /**
     * This function returns the object instance that matches the specified ID.-
     *
     * @param $id   The primary key value in the database. Default value is NULL.-
     * 
     * @return An instance of this class if the ID exists, NULL otherwise.-
     */
    public function get_by_id ($id = NULL)
    {
    	$ret_value = NULL;
    	
    	//
    	// Check that we received a valid ID
    	//
        if ($id != NULL)
        {
        	//
        	// Select out all the attributes/columns
        	//
        	$select_columns = '';
        	
	        foreach ($this->column_definition as $column)
	        {
	            $select_columns .= $column . ', ';
	        }
        	
	        //
	        // Delete the last comma
	        //
	        $select_columns = substr ($select_columns, 0, -2);
       
	        //
	        // Build the SQL statement with Active Record
	        //
	        $this->db->select ($select_columns);
	        $this->db->from   ($this->table_name);
	        $this->db->where  ($this->column_definition['id'] . ' = ', $id);
	         
	        $query = $this->db->get ( );
	         
	        if ($query->num_rows ( ) > 0)
	        {
	            $this->_load ($query->row ( ));
	            $ret_value = $this;
	        }
        }
        
        //
        // Return the object instance
        //
        return $ret_value;
    }    
    
    
    /**
     * Returns an array containing all existing objects.-
     *
     * @return Always returns an array. If there are no rows,
     *         the array is empty.
     */
    public function get_all ( )
    {
        $ret_value = array ( );

        //
        // The class name of this object
        //
        $object_class = get_class ($this);
        
        //
        // Select all records from the table
        //
        $query = $this->db->get ($this->table_name);

        foreach ($query->result ( ) as $row)
        {
        	$id_column   = $this->column_definition['id'];
            $new_object  = new $object_class ($row->$id_column);
            $ret_value[] = $new_object;
        }

        //
        // Return the created array
        //
        return $ret_value;
    }
    
    
    /**
     * Checks if this object exists in the database.
     *
     * @param $id   The database ID of the object to be searched for. 
     *              If no ID is given, the function will check the existance
     *              of the current object instance in the database.- 
     *
     * @return      TRUE if the ID exists, FALSE otherwise.-
     */
    public function exists ($id = NULL)
    {
    	$ret_value = false;
    	
    	//
    	// Take this instance's ID if the parameter is NULL
    	//
        $id = ($id != NULL) ? $id : $this->id;

        //
        // A NULL ID cannot exist in the database.
        //
        if ($id != NULL)
        {
	        //
	        // Search for such a row in the database table
	        //
	        $this->db->select ($this->column_definition['id']);
	        $this->db->from   ($this->table_name);
	        $this->db->where  ($this->column_definition['id'] . ' = ', $id);
	        
	        $query = $this->db->get ( );
	        
	        //
	        // Does it exist?
	        //
	        $ret_value = ($query->num_rows ( ) > 0);
        }
        
        //
        // Return the success value
        //
        return $ret_value;
    }
    

    /**
     * Synchronizes the database with this object instance.-
     * 
     * @return TRUE on success, FALSE otherwise.-
     */
    public function update ( )
    {
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }
        
        //
        // Set the table row data as in the current instance
        //
        foreach ($this->column_definition as $attribute => $column)
        {
            $this->db->set ($column, $this->$attribute);
        }
        
        //
        // Change this row only
        //
        $this->db->where  ($this->column_definition['id'] . ' = ', $this->id);
        $this->db->update ($this->table_name);
        
        //
        // Return success value
        //
        return ($this->db->affected_rows ( ) > 0);
    }


    /**
     * Returns an instance of a parent (i.e. foreign key) object.-
     *
     * @return An instance of the parent (i.e. foreign key) model.-
     */
    public function get_parent ($class_name = NULL)
    {
    	$ret_value = NULL;
    	
    	//
    	// Be sure the class_name is valid
    	//
    	if ($class_name != NULL)
    	{
    		$foreign_key_attribute = $this->foreign_keys[$class_name];
    		$ret_value             = new $class_name ($this->$foreign_key_attribute); 
    	}
    	
    	//
    	// Return the object
    	//
        return $ret_value; 
    }
    
    
    /**
     * Deletes all specified IDs from the corresponding database table.-
     *
     * @param $ids  An array containing the IDs to be deleted.-
     * 
     * @return      TRUE if no error ocurred, FALSE otherwise.-
     */
    function delete_all ($ids)
    {
    	$ret_value = false;
    	
    	//
    	// Check that the parameter is a valid array
    	//
    	if (is_array ($ids))
    	{
            $this->db->where_in ($this->column_definition['id'], $ids);
            $this->db->delete   ($this->table_name);

            //
            // Check for any possible error
            //
            $error_message = $this->db->_error_message ( );
            $ret_value     = empty ($error_message);
    	}
    	
    	//
    	// Return the success value
    	//
    	return $ret_value;
    }
    
    
    /**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @param $table		The table name from which to search for a valid ID.
     *                      If this parameter is ommited, the function will use
     *                      the value of $this->table_name.-
     * @param $id_column 	The name of the ID column in the database. If this
     *                      parameter is ommited, the function will use the
     *                      value of $this->column_definition['id'].-
     * 
     * @return 				A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ($table = NULL, $id_column = NULL)
    {
    	$ret_value = NULL;
    	
    	//
    	// Be sure we received valid parameters
    	//
    	if ($table == NULL)
    	{
    		$table = $this->table_name;
    	}
    	if ($id_column == NULL)
    	{
    		$id_column = $this->column_definition['id'];
    	}

    	//
    	// Look for one valid ID (any record will do!) 
    	//
	    $this->db->select ($id_column);
	    $this->db->from   ($table);
	    $this->db->limit  (1);
    		
	    $query = $this->db->get ( );
	         
	    if ($query->num_rows ( ) > 0)
	    {
	       $row 	  = $query->first_row ('array');
	       $ret_value = $row[$id_column];
    	}
    	
    	//
    	// Return the ID found
    	//
    	return $ret_value;
    }
    
    
    /**
     * Returns the specified value in the correct format.
     * This function is needed because all quantities are kept in 1/100 units,
     * meaning that the real value is always (value / 100).
     *
     * @param $attribute	  	This object's attribute that contains the 
     * 							value to be transformed.-
     * @param $decimal_places 	The number of decimal places displayed in the 
     * 							returned value. It defaults to 2.- 
     * 
     * @return 				A correctly formated float value, regarding the 
     * 						currently active locale settings.-
     */
    public function get_real_value ($attribute = NULL, $decimal_places = 2)
    {
    	$ret_value = NULL;
    	
    	//
    	// Be sure we received valid parameters
    	//
    	if ($attribute != NULL)
    	{
    		//
    		// Be sure the attribute is a number
    		//
    		if (is_numeric ($this->$attribute))
    		{
    			$ret_value = money_format ('%!.' . $decimal_places . 'n',
    									   $this->$attribute / 100);
    		}
    	}
    	
    	//
    	// Return the transformed value
    	//
    	return $ret_value;
    }
    
    
    /**
     * Sets the specified value in the correct format.
     * This function is needed because all quantities are kept in 1/100 units,
     * meaning that the real value is always (value / 100) and it will be kept
     * as (value * 100).-
     *
     * @param $attribute	This object's attribute that should be assigned 
     * 						the real value.-
     * @param $value		The value in human readable form, formatted
     * 						according to the current locale settings.- 
     */
    public function set_real_value ($attribute = NULL, $value = NULL)
    {
    	//
    	// Be sure we received valid parameters
    	//
    	if ($attribute != NULL && $value != NULL)
    	{
    		//
    		// Get the currently active locale settings
    		//
    		$locale_settings = localeconv ( );
    		
    		//
    		// Clean the value up
    		//
    		$value = str_replace ($locale_settings['thousands_sep'],  '', $value);
    		$value = str_replace ($locale_settings['decimal_point'], '.', $value);
    		
    		//
    		// Change the value unit
    		//
    		$value = round ($value * 100, 0);
    		
    		//
    		// Save the value to the attribute in the correct form
    		//
    		$this->$attribute = $value;
    	}
    }    
}

?>

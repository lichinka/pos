<?php
require_once 'application/models/entity.php';


/**
 * This class represents a detail line inside a sale.
 * 
 * @author luka
 *
 */
class Sale_detail extends Entity
{
	var $id;
    var $sale_id;
    var $item_id;
	var $quantity;
    var $price_unit;
    var $price_cost;
    
	/**
     * This function maps the results from the database 
     * table's row into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
    	$this->id		  = $row->sale_detail_id;
        $this->sale_id    = $row->sale_id;
        $this->item_id    = $row->item_id;
        $this->quantity   = $row->quantity_purchased;
        $this->price_unit = $row->item_unit_price;
        $this->price_cost = $row->item_cost_price;
    }


    /**
     * Creates an empty bucket for this object.
     *
     * @return The row ID of the empty bucket created.-
     */
    protected function _insert ( )
    {
    	//
    	// Load the Sale and Item models
    	//
    	$this->load->model 		 ('sales/sale', 'sale');
    	$this->load->model 		 ('items/item', 'item');
    	$this->_assign_libraries ( );
    	
        if ($this->id != NULL)
        {
            $this->db->set ('sale_detail_id', $this->id);
        }
    	
        //
        // Save some default values to the fields
        //
        $this->db->set ('sale_id',   		  $this->sale->get_valid_id ( ));
        $this->db->set ('item_id',   		  $this->item->get_valid_id ( ));
        $this->db->set ('quantity_purchased', -100);
        $this->db->set ('item_cost_price', 	  -100);
        $this->db->set ('item_unit_price', 	  -100);

        $this->db->insert ('sales_details');

        return $this->db->insert_id ( );
    }


    /**
     * Constructor.-
     *
     * @param $id The ID of the object being constructed, which data 
     * 			  is to be loaded from the database. Defaults to an 
     * 			  empty instance.-
     */
    function __construct ($id = NULL)
    {
        parent::__construct ($id);

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }

    
    /**
     * This function returns a single object, that matches the specified ID.-
     *
     * @param $id The value of the primary key in the database. Default is NULL.
     * 
     * @return An instance of this class if the ID exists, NULL otherwise.
     */
    public function get_by_id ($id = NULL)
    {
        if ($id != NULL)
        {
	        $this->db->select ('sale_detail_id, sale_id, item_id, quantity_purchased, item_cost_price, item_unit_price');
	        $this->db->from   ('sales_details');
	        $this->db->where  ('sale_detail_id =', $id);
	         
	        $query = $this->db->get ( );
	         
	        if ($query->num_rows ( ) > 0)
	        {
	            $this->_load ($query->row ( ));
	            return ($this);
	        }
	        else
	        {
	            return (NULL);
	        }
        }
        else
        {
        	return (NULL);
        }
    }

    
    /**
     * Returns an array containing all Sale_detail objects in the
     * sale with the given ID. The array structure is as follows:
     *  
     *      ($row, $row, $row, ...)
     *      
     * where $row is:
     * 
     *      'detail' 	   => $sale_detail
     *      'detail_taxes' => ($tax, $tax, ...)
     * 
     * where $sale_detail is an object of type Sale_detail and $tax 
     * is an object of type Sale_detail_tax.-
     * 
     * @return all An array containing all Sale_detail objects in 
     * 			   the sale with the given ID. If no details are 
     * 			   found, the returned array is empty.-
     */
    function get_by_sale ($sale_id = NULL)
    {
    	$ret_value = array ( );
    	
    	//
    	// Load the Sale_detail_tax model
    	//
    	$this->load->model 		 ('sales/sale_detail_tax', 'sale_detail_tax');
    	$this->_assign_libraries ( );
    	
    	//
    	// Did we recieve a valid parameter?
    	//
    	if ($sale_id != NULL)
    	{
	    	//
	    	// Set the query parameters
	    	//
	        $this->db->select ('sale_detail_id');
	        $this->db->from   ('sales_details');
	        $this->db->where  ('sale_id =', $sale_id);
	
	        $query = $this->db->get ( );
	                
	        //
	        // Found anything?
	        //
	        if ($query->num_rows ( ) > 0)
	        {
	        	//
	        	// Fill the resulting array
	        	//
	            foreach ($query->result ( ) as $result_row)
				{
					$row = array ( );
	
					//
					// Create an object instance based on the ID
					//
					$row['detail'] = new Sale_detail ($result_row->sale_detail_id);
					
					//
					// Ask for all the taxes applied to this detail line
					//
					$row['detail_taxes'] = $this->sale_detail_tax->get_by_sale_detail ($result_row->sale_detail_id);

					//
	                // Add this row to the resulting array
	                //
					array_push ($ret_value, $row);
				} 
	        }
    	}
        
        //
        // Return the array just built
        //
        return $ret_value;
    }
    
    
    /**
     * Returns an array containing all existing objects in the database.
     *
     * @return An array containing objects instances. If there are no 
     * 		   rows in the table, the array is empty.
     */
    public function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('sales_details');

        //
        // FIXME: Issue #12: This way of creating insances may cause a huge ammount of queries.
        //
        foreach ($query->result ( ) as $row)
        {
            $sale_detail = new Sale_detail ($row->sale_detail_id);
            array_push ($ret_value, $sale_detail);
        }

        return ($ret_value);
    }


    /**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @return 	A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ( )
    {
    	return parent::get_valid_id ("sales_details", "sale_detail_id");
    }
    
    
    /**
     * Checks if this object exists in the database.
     *
     * @param $id   The database ID of the object to be searched for. 
     *              If no ID is given, the function will check the existance
     *              of the current object instance in the database.- 
     *
     * @return 		TRUE if the ID exists, FALSE otherwise.-
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $id = $this->id;
        }

        $o = new Sale_detail ($id);

        return ($o->get_by_id ($o->id) != NULL);
    }

    
    /**
     * Synchronizes the database with this object instance.-
     * 
     * @return TRUE on success, FALSE otherwise.-
     */
    public function update ( )
    {
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }
        
        //
        // Set the table row data as in the current instance
        //
        $this->db->set ('sale_id',     		  $this->get_parent_sale ( )->id);
        $this->db->set ('item_id',     		  $this->get_parent_item ( )->id);
        $this->db->set ('quantity_purchased', $this->quantity);
        $this->db->set ('item_cost_price', 	  $this->get_parent_item ( )->price_cost);
        $this->db->set ('item_unit_price', 	  $this->price_unit);
        
        //
        // Change this row only
        //
        $this->db->where  ('sale_detail_id =', $this->id);
        $this->db->update ('sales_details');
        
        //
        // Return value
        //
        return ($this->db->affected_rows ( ) > 0);
    }

    
    /**
     * Returns the parent object (i.e. an object connected
     * to this one via a foreing key in the database).-
     *
     * @return an instance of the Sale model.-
     */
    public function get_parent_sale ( )
    {
    	//
    	// Load the Sale model
    	//
    	$this->load->model 		 ('sales/sale', 'sale');
    	$this->_assign_libraries ( );
    	
        return (new Sale ($this->sale_id));
    }


    /**
     * Returns the parent object (i.e. an object connected
     * to this one via a foreing key in the database).-
     *
     * @return an instance of the Item model.-
     */
    public function get_parent_item ( )
    {
    	//
    	// Load the Item model
    	//
    	$this->load->model 		 ('items/item', 'item');
    	$this->_assign_libraries ( );
    	
        return (new Item ($this->item_id));
    }
    
    
    /**
     * Deletes all specified IDs from the corresponding database tables.-
     *
     * @param $ids  An array containing the IDs to be deleted.-
     * 
     * @return 		TRUE if at least one row has been deleted, FALSE otherwise.-
     */
    function delete_all ($ids)
    {
        $this->db->where_in ('sale_detail_id', $ids);
        $this->db->delete   ('sales_details');

        return ($this->db->affected_rows ( ) > 0);
    }    
}

?>

<?php
require_once 'application/models/entity.php';

/**
 * This class represents a payment type for a sale (like cash, credit card, ...).
 * It also supports saving some fields in different languages.-
 *
 * @author luka
 *
 */
class Payment extends Entity
{
    var $id;
    var $name;


    /**
     * This is the default constructor
     *
     * @param $id The ID of the sale being constructed, which data is to be
     *            loaded from the database. Defaults to an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ( );

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        $this->id 	= $row->payment_id;
        $this->name = $row->name;
    }


    /**
     * Creates an empty bucket.-
     *
     * @return The database ID of the empty bag.-
     */
    protected function _insert ( )
    {
        //
        // Insert an empty bucket
        //
    	if ($this->id != NULL)
        {
            $this->db->set ('payment_id', $this->id);
        }

        $this->db->insert ('payments');
        
        $this->id = $this->db->insert_id ( );
        
        //
        // Also insert an empty bucket in the LANG table
        //
        $this->db->select ($this->id . ' AS payment_id, language_id,' .
                           "'### NO VALUE ###' AS name");
        $this->db->from   ('languages');
        $this->db->where  ('name = ', $this->config->item ('language'));
        
        $query = $this->db->get ( );
        
        if ($query->num_rows ( ) > 0)
        {
        	$this->db->insert ('payments_lang', $query->result_array ( ));
        }
        else
        {
        	//
        	// This should not happen
        	//
        	echo "*** ERROR: Severe => this application is not configured for language " .
        	     $this->config->item ('language');
        }
        
        //
        // Return the ID of this object
        //
        return $this->id;
    }
    
    
    /**
     * This function returns a single object, that matches the specified ID.-
     *
     * @param $id The value of the primary key in the database. Default is NULL.
     * 
     * @return    An instance of this class if the ID exists, NULL otherwise.
     */
    function get_by_id ($id = NULL)
    {
    	$ret_value = NULL;
    	
    	if ($id != NULL)
    	{
	        $this->db->select ('payments.payment_id, payments_lang.name');
	        $this->db->from   ('payments');
	        $this->db->join   ('payments_lang',         'payments.payment_id   = payments_lang.payment_id');
	        $this->db->join   ('languages', 	        'languages.language_id = payments_lang.language_id');
	        $this->db->where  ('payments.payment_id =', $id);
	        $this->db->where  ('languages.name      =', $this->config->item ('language'));
	
	        $query = $this->db->get ( );
	
	        if ($query->num_rows ( ) > 0)
	        {
	            $this->_load ($query->row ( ));
	            $ret_value = $this;
	        }
    	}
    	
    	//
    	// Return the object found
    	//
    	return $ret_value;
    }

    
    /**
     * Returns an array containing all existing sales.
     *
     * @return Always returns an array. If there are no sales, the array is empty.
     */
    function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('payments');

        foreach ($query->result ( ) as $row)
        {
            $payment = new Payment ($row->payment_id);
            array_push ($ret_value, $payment);
        }

        return $ret_value;
    }
    

    /**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @return  A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ( )
    {
        return parent::get_valid_id ("payments", "payment_id");
    }
    
    
    /**
     * Checks if the object exists in the database.
     *
     * @param $id   The database id of this object. 
     *              If no id is given, the function will check the existance
     *              of the current instance in the database. 
     *
     * @return      TRUE If it exists, FALSE otherwise.-
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Payment ($this->id);
        }
        else
        {
            $o = new Payment ($id);
        }

        return $o->get_by_id($o->id) != NULL;
    }

    
    /**
     * Synchronizes the database with this object instance.-
     * 
     * @return TRUE on success, FALSE otherwise.-
     */
    public function update ( )
    {
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }

        //
        // Set the data as in the current instance
        //
        $this->db->set    ('payments_lang.name', $this->name);
        $this->db->join   ('languages',          'languages.language_id = payments_lang.language_id');
        $this->db->where  ('payment_id =',       $this->id);
        $this->db->where  ('languages.name =',   $this->config->item ('language'));
        
        $this->db->update ('payments_lang');
        
        //
        // Return value
        //
        return ($this->db->affected_rows ( ) > 0);
    }
}

?>

<?php
require_once 'application/models/entity.php';

/**
 * This class represents a category for a group of items.
 * Categories may have a parent category, enabling the creation of sub-categories.
 * This class supports saving some fields in different languages.-
 *
 * @author luka
 *
 */
class Category extends Entity
{
    var $id;
    var $parent_id;
    var $name;
    var $description;

    /**
     * Returns an array of headers for the export function. The column order is the same as
     * in the exported data.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     *
     * @return an array of strings
     */
    private function construct_headers ($languages)
    {
        $category_headers = array (
        'headers'=>array (
        $this->lang->line ('items_category') . ' ' . $this->lang->line ('common_id'),
        $this->lang->line ('categories_parent') . ' ' . $this->lang->line ('common_id')
        ),
        'language_dependant'=>array (
        $this->lang->line ('items_category'),
        $this->lang->line ('items_description') . ' ' . $this->lang->line ('items_category')
        )
        );

        $parsed_category_headers = $category_headers['headers'];
        foreach ($category_headers['language_dependant'] as $partial_header)
        {
            foreach ($languages as $language)
            {
                array_push ($parsed_category_headers, $partial_header . '_' . $language->short_name);
            }
        }

        return $parsed_category_headers;
    }
    
	/**
     * This function maps the results from the database table's row
     * into this object's attributes.
     * 
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        $this->id 			 = $row->category_id;
        $this->parent_id	 = $row->parent_category_id;
        $this->name 		 = $row->name;
        $this->description	 = $row->description;
    }

	/**
     * Creates an empty bag.
     *
     * @return the database id of the empty bag
     */
    protected function _insert ( )
    {
        if ($this->id != NULL)
        {
            $this->db->set ('category_id', $this->id);
        }
        
        $this->db->set    ('parent_category_id', NULL);
        $this->db->insert ('categories');
        
        $id = $this->db->insert_id ( );
        $active_language = $this->language->get_current_language ( );
        
        //
        // also set the categories_lang
        //
        if ($this->id != NULL)
        {
            $this->db->set ('category_id', $this->id);
        }
        else
        {
            $this->db->set ('category_id', $id);
        }
        
        $this->db->set    ('language_id', $active_language->id);
        $this->db->set    ('name',        '### NO VALUE ###');
        $this->db->set    ('description', '### NO VALUE ###');
        
        $this->db->insert ('categories_lang');
        
        return $id;
    }

    /**
     * This is the default constructor
     * 
     * @param $id:
     * 	If this parameter is supplied, the object will represent an actual database entry.
     * 	Else it will be an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ( );
        $this->load->model ('export-import/language');

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }

    /**
     * This function returns a single object, that mathces the specified id.
     * @param $id: is the value of the primary key in the database. Default value is -1.
     * @return An instance of this class if the id exists, null otherwise.
     */
    function get_by_id ($id = -1)
    {
        $this->db->select ('categories.category_id, categories.parent_category_id, ' .
    					   'categories_lang.name, categories_lang.description');
        $this->db->from   ('categories');
        $this->db->join   ('categories_lang', 'categories.category_id = categories_lang.category_id');
        $this->db->join   ('languages', 	  'languages.language_id  = categories_lang.language_id');
        $this->db->where  ('categories.category_id', $id);
        $this->db->where  ('languages.name', 		 $this->config->item ('language'));

        $query = $this->db->get ( );

        if ($query->num_rows ( ) > 0)
        {
            $this->_load ($query->row ( ));
            return ($this);
        }
        else
        {
            return (NULL);
        }
    }

    /**
     * Returns an array containing all existing items, in the correct language.
     * @return Always returns an array. If there are no items the array is empty.
     */
    function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('categories');

        foreach ($query->result ( ) as $row)
        {
            $category = new Category ($row->category_id);
            array_push ($ret_value, $category);
        }

        return ($ret_value);
    }
    
 	/**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @return 	A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ( )
    {
    	return parent::get_valid_id ("categories", "category_id");
    }
    
	/**
     * Returns a Category instance, as defined in the category_id attribute.
     *
     * @return an instance of the Category class
     */
    function get_parent_category ( )
    {
        return new Category ($this->parent_id);
    }

    /**
     * Deletes all elements.
     */
    public function purge ( )
    {
        $this->db->empty_table ('categories_lang');

        //
        // this is needed, because of the internal foreign keys
        //
        $this->db->set    ('parent_category_id', NULL);
        $this->db->update ('categories');

        $this->db->empty_table ('categories');
    }

    /**
     * Checks if the object exists in the database.
     *
     * @param $id is the database id. If no id is given, the function will check the
     * 	database for the instance of this object.
     *
     * @return true, it exists, false otherwise
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Category ($this->id);
        }
        else
        {
            $o = new Category ($id);
        }

        return $o->get_by_id($o->id) != NULL;
    }

    /**
     * This function exports the model into a matrix.
     *
     * @param $mode is the exporting mode (only the number 1 is allowed)
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Category intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    function export ($mode, $languages, $entities = NULL)
    {
        if ($mode != '1')
        {
            throw new Exception ('The exporting mode ' . $mode . ' is not supported.');
        }


        $categories_rows = array ($this->construct_headers ($languages));

        if ($entities === NULL)
        {
            $categories = array ($this);
        }
        else
        {
            $categories = $entities;
        }


        //
        // language dependant fields
        //
        $category_fields = array ('name', 'description');

        foreach ($categories as $category)
        {
            $category_row = array ( );
            //
            // language independant fields first
            //
            array_push ($category_row, $category->id);
            array_push ($category_row, $category->parent_id);

            foreach ($category_fields as $category_field)
            {
                foreach ($languages as $language)
                {
                    $this->db->select ($category_field);
                    $this->db->from   ('categories_lang');
                    $this->db->where  ('category_id =', $category->id);
                    $this->db->where  ('language_id =', $language->id);

                    $query = $this->db->get ( );

                    if ($query->num_rows ( ) > 0)
                    {
                        foreach ($query->result ( ) as $row)
                        {
                            array_push ($category_row, eval ('return $row->' . $category_field . ';'));
                        }
                    }
                    else
                    {
                        array_push ($category_row, '');
                    }
                }
            }
            array_push ($categories_rows, $category_row);
        }
        return $categories_rows;
    }

    /**
     * Imports the flat data into the database.
     *
     * @param $mode is the importing mode
     * @param $data a matrix (array of array), where the outer index represents rows and the
     * 		  inner index represents columns. This paramater is without headers.
     * @param $languages is an array of languages, sorted in the same way as are the columns
     * 		  int the data parameter
     */
    public function import_simple ($mode, $data, $languages)
    {
        if ($mode == 1)
        {
            $this->purge ( );
        }

        if ($mode == 3)
        {
            $new_category_ids = array ( );
        }


        //
        // first iteration ignores the parents
        //
        foreach ($data as $row)
        {
            

            //
            // if exists
            //
            if ($this->db->get_where ('categories', array ('category_id' => $row[0]))->num_rows ( ) > 0)
            {
                if ($mode == 1 || $mode == 2)
                {
                    $this->db->set    ('parent_category_id', NULL);
                    $this->db->where  ('category_id =', $row[0]);
                    $this->db->update ('categories');
                }
            }
            else
            {
                $this->db->set    ('parent_category_id', NULL);
                $this->db->set    ('category_id', $row[0]);
                $this->db->insert ('categories');
                if($mode == 3)
                {
                    array_push($new_category_ids, $row[0]);
                }
            }


            //
            // set language data
            //
            for ($i = 0; $i < count ($languages); $i++)
            {
                //
                // if exists
                //
                if ($this->db->get_where ('categories_lang', array ('category_id' => $row[0], 'language_id' => $languages[$i]->id))->num_rows ( ) > 0)
                {
                    if ($mode == 1 || $mode == 2)
                    {
                        $this->db->set    ('name', $row[2 + $i]);
                        $this->db->set    ('description', $row[2 + count ($languages) + $i]);
                        $this->db->where  ('category_id =', $row[0]);
                        $this->db->where  ('language_id =', $languages[$i]->id);
                        $this->db->update ('categories_lang');
                    }
                }
                else
                {
                    $this->db->set    ('name', $row[2 + $i]);
                    $this->db->set    ('description', $row[2 + count ($languages) + $i]);
                    $this->db->set    ('category_id', $row[0]);
                    $this->db->set    ('language_id', $languages[$i]->id);
                    $this->db->insert ('categories_lang');
                }
            }
        }

        //
        // only update parents in the second iteration
        //
        foreach ($data as $row)
        {
            if ($mode == 3)
            {
                if (in_array ($row[0], $new_category_ids))
                {
                    if (! ($row[1] === ''))
                    {
                        $this->db->set    ('parent_category_id', $row[1]);
                        $this->db->where  ('category_id =', $row[0]);
                        $this->db->update ('categories');
                    }
                }
            }
            else if (! ($row[1] === ''))
            {
                $this->db->set    ('parent_category_id', $row[1]);
                $this->db->where  ('category_id =', $row[0]);
                $this->db->update ('categories');
            }
        }
    }

    /**
     * Synchronizes the database with this object.
     */
    public function update ( )
    {
        $ret_value = false;
        
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }
        
        $this->db->set    ('parent_category_id', $this->parent_id);
        $this->db->where  ('category_id =',      $this->id);
        
        $this->db->update ('categories');
        
        $ret_value |= ($this->db->affected_rows ( ) > 0);
        
        //
        // Also update the categories_lang
        //
        $active_language = $this->language->get_current_language ( );
        
        $this->db->set    ('name',          $this->name);
        $this->db->set    ('description',   $this->description);
        $this->db->where  ('category_id =', $this->id);
        $this->db->where  ('language_id =', $active_language->id);
        
        $this->db->update ('categories_lang');
        
        $ret_value |= ($this->db->affected_rows ( ) > 0);
        
        //
        // Return value
        //
        return ($ret_value);
    }

    /**
     * Returns a category based on its name. The name in the database and the parameter
     * name must be exactly the same.
     * @param $name is the desired name
     * @return a single instance of this class
     */
    function get_by_name ($name = NULL)
    {
        // FIXME: the name matches, if the parameter name has trailing spaces
        // FIXME: the database does not have the unique constraint on the name column
        $this->db->select ('categories_lang.name, categories_lang.category_id');
        $this->db->from   ('categories_lang');
        $this->db->join   ('languages', 'languages.language_id = categories_lang.language_id');
        $this->db->where  ('categories_lang.name =', $name);
        $this->db->where  ('languages.name', $this->config->item ('language'));
         
        $query = $this->db->get ( );
         
        if ($query->num_rows ( ) > 0)
        {
            return ($this->get_by_id ($query->row ( )->category_id));
        }
        else
        {
            return (NULL);
        }
    }
    
    /**
     * Deletes a single category from the database
     * 
     * @deprecated
     * @param $category_id is the category's id
     * @return True if deleted, false otherwise
     */
    public function delete ($category_id)
    {
        return $this->db->delete('categories', array('category_id' => $category_id));
    }
}
?>

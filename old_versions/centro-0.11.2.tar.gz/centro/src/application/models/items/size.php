<?php
require_once 'application/models/entity.php';

/**
 * This class represents a size of an item (e.g. S, M or L).
 * It should be used in conjunction with the Size_group class.-
 *
 * @author luka
 *
 */
class Size extends Entity
{
    var $id;
    var $name;


    /**
     * This is the default constructor
     * @param $id:
     * 	If this parameter is supplied, the object will represent an actual database entry.
     * 	Else it will be an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ( );

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        $this->id 	= $row->size_id;
        $this->name = $row->name;
    }


    /**
     * This function returns a single object, that mathces the specified id.
     * @param $id: is the value of the primary key in the database. Default value is -1.
     * @return An instance of this class if the id exists, null otherwise.
     */
    function get_by_id ($id = -1)
    {
        $this->db->select ('sizes.size_id, sizes.name');
        $this->db->from   ('sizes');
        $this->db->where  ('sizes.size_id =', $id);

        $query = $this->db->get ( );

        if ($query->num_rows ( ) > 0)
        {
            $this->_load ($query->row ( ));
            return ($this);
        }
        else
        {
            return (NULL);
        }
    }

    /**
     * Returns an array containing all existing items.
     * @return Always returns an array. If there are no items the array is empty.
     */
    function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('sizes');

        foreach ($query->result ( ) as $row)
        {
            $size = new Size ($row->size_id);
            array_push ($ret_value, $size);
        }

        return ($ret_value);
    }

    /**
     * Checks if the object exists in the database.
     *
     * @param $id is the database id. If no id is given, the function will check the
     * 	database for the instance of this object.
     *
     * @return true, it exists, false otherwise
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Size ($this->id);
        }
        else
        {
            $o = new Size ($id);
        }

        return $o->get_by_id($o->id) != NULL;
    }

    /**
     * Synchronizes the database with this object.
     */
    public function update ( )
    {
        //FIXME: implement
        //FIXME: it is impossible to insert a size into the database without knowing the group
    }

    /**
     * Creates an empty bag.
     *
     * @return the database id of the empty bag
     */
    protected function _insert ( )
    {
        // FIXME: implement
    }
}
?>

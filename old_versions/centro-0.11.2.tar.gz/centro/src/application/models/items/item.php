<?php
require_once 'application/models/entity.php';

/**
 * This class represents every item that may be
 * sold and stocked in the inventory.-
 *
 * @author luka
 *
 */
class Item extends Entity
{
    var $id;
    var $name;
    var $description;
    var $category_id;
    var $size_group_id;
    var $barcode;
    var $price_unit;
    var $price_cost;
    var $quantity;
    var $reorder_level;

    
    /**
     * Returns an array of headers for the export function. The column order is the same as
     * in the exported data.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     *
     * @return an array of strings
     */
    private function _construct_headers ($languages)
    {
        $items_headers = array (
        'headers'=>array (
        $this->lang->line ('items_item') . ' ' . $this->lang->line ('common_id'),
        $this->lang->line ('items_item_number'),
        $this->lang->line ('items_quantity'),
        $this->lang->line ('items_reorder_level'),
        $this->lang->line ('items_size_group') . ' ' . $this->lang->line ('common_id'),
        $this->lang->line ('items_category') . ' ' . $this->lang->line ('common_id')
        ),
        'language_dependant'=>array (
        $this->lang->line ('items_name'),
        $this->lang->line ('items_description'),
        $this->lang->line ('items_unit_price'),
        $this->lang->line ('items_cost_price')
        ),
        'tax_headers'=> array (
        $this->lang->line ('sales_tax')
        )
        );

        $parsed_item_headers = array_slice ($items_headers['headers'], 0, 4);
        foreach ($items_headers['language_dependant'] as $partial_header)
        {
            foreach ($languages as $language)
            {
                array_push ($parsed_item_headers, $partial_header . '_' . $language->short_name);
            }
        }

        //
        // tax_headers
        //
        $tax_headers = array ( );
        $max = -1;
        foreach ($this->get_all ( ) as $item)
        {
            $num = $this->db->get_where ('items_taxes', array ('item_id' => $item->id))->num_rows ( );
            if ($num > $max)
            {
                $max = $num;
            }
        }
        for ($i = 0; $i < $max; $i++)
        {
            for ($j = 0; $j < 3; $j++)
            {
                if ($j == 0)
                {
                    array_push ($tax_headers, $items_headers['tax_headers'][0] . ' ' . ($i + 1) . ' ' . $this->lang->line ('common_id'));
                }
                else if ($j == 1)
                {
                    array_push ($tax_headers, $items_headers['tax_headers'][0] . ' ' . ($i + 1). ' ' . $this->lang->line ('common_name'));
                }
                else if ($j == 2)
                {
                    array_push ($tax_headers, $items_headers['tax_headers'][0] . ' ' . ($i + 1) . ' %');
                }
            }
        }

        return array_merge ($parsed_item_headers, array_slice ($items_headers['headers'], 4), $tax_headers);
    }

    /**
     * This function exports the while items relation and inlines the size and category
     * data.
     *
     * @param $mode is the exporting mode
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Item intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    private function _export_flat ($mode, $languages, $entities = NULL)
    {
        $rows = array ( );

        if ($entities === NULL)
        {
            $items = array ($this);
        }
        else
        {
            $items = $entities;
        }

        $items_headers    = $this->_construct_headers ($languages);
        $size_headers     = $this->Size_group->export ($mode, $languages, array ( ));
        $category_headers = $this->Category->export ($mode, $languages, array ( ));

        //
        // needed to slice the foreign key from the items
        //
        $foreign_keys_index = 4 + 4 * count ($languages);
        $taxes_index = $foreign_keys_index + 2;

        $headers = array_merge (array_slice ($items_headers, 0, $foreign_keys_index), $size_headers[0], $category_headers[0], array_slice ($items_headers, $taxes_index));
        array_push ($rows, $headers);




        foreach ($items as $item)
        {
            $item_row = $item->_export_simple ($languages);
            $size_row = $item->get_parent_size_group ( )->export ($mode, $languages);
            $category_row = $item->get_parent_category ( )->export ($mode, $languages);

            $row = array_merge (array_slice ($item_row[1], 0, $foreign_keys_index), $size_row[1], $category_row[1], array_slice ($item_row[1], $taxes_index));
            array_push ($rows, $row);
        }

        return $rows;
    }

    /**
     * This function exports the model into a matrix. The foreign keys are listed as in the
     * database.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Item intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    private function _export_simple ($languages, $entities = NULL)
    {
        $items_rows = array ($this->_construct_headers ($languages));

        if ($entities === NULL)
        {
            $items = array ($this);
        }
        else
        {
            $items = $entities;
        }

        //
        // language dependant fields
        //
        $item_fields = array ('name', 'description', 'price_unit', 'price_cost');
        $real_number_fields = array ('price_unit', 'price_cost');

        foreach ($items as $item)
        {
            $item_row = array ( );
            //
            // language independant fields first
            //
            array_push ($item_row, $item->id);
            array_push ($item_row, $item->barcode);
            array_push ($item_row, $item->get_real_value ('quantity'));
            array_push ($item_row, $item->get_real_value ('reorder_level'));

            foreach ($item_fields as $item_field)
            {
                foreach ($languages as $language)
                {
                    $this->db->select ($item_field);
                    $this->db->from   ('items_lang');
                    $this->db->where  ('item_id =', $item->id);
                    $this->db->where  ('language_id =', $language->id);

                    $query = $this->db->get ( );
                    if ($query->num_rows > 0)
                    {
                        foreach ($query->result ( ) as $row)
                        {
                            if (in_array ($item_field, $real_number_fields))
                            {
                                $dummy_item = new Item ( );
                                $dummy_item->$item_field = $row->$item_field;
                                array_push ($item_row, $dummy_item->get_real_value ($item_field));
                            }
                            else
                            {
                                array_push ($item_row, eval ('return $row->' . $item_field . ';'));
                            }
                        }
                    }
                    else
                    {
                        array_push ($item_row, '');
                    }
                }
            }


            //
            // foreign keys
            //
            array_push ($item_row, $item->size_group_id);
            array_push ($item_row, $item->category_id);

            //
            // tax data last
            //
            $taxes = $this->tax->get_by_item ($item->id);

            foreach ($taxes as $tax)
            {
                array_push ($item_row, $tax->id);
                array_push ($item_row, $tax->name);
                array_push ($item_row, $tax->get_real_value ('percent'));
            }

            array_push ($items_rows, $item_row);
        }

        //
        // add empty cells (caused by tax_data)
        //
        $max_cells_num = count ($items_rows[0]);
        for ($i = 0; $i < count ($items_rows); $i++)
        {
            while (count ($items_rows[$i]) < $max_cells_num)
            {
                array_push ($items_rows[$i], '');
            }
        }


        return $items_rows;
    }

	/**
     * This function maps the results from the database table's row
     * into this object's attributes.
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        $this->id 			 = $row->item_id;
        $this->name 		 = $row->name;
        $this->description	 = $row->description;
        $this->category_id	 = $row->category_id;
        $this->size_group_id = $row->size_group_id;
        $this->barcode		 = $row->barcode;
        $this->price_unit	 = $row->price_unit;
        $this->price_cost	 = $row->price_cost;
        $this->quantity		 = $row->quantity;
        $this->reorder_level = $row->reorder_level;
    }
    
	/**
     * Creates an empty bag.
     *
     * @return the database id of the empty bag
     */
    protected function _insert ( )
    {
        if ($this->id != NULL)
        {
            $this->db->set ('item_id', $this->id);
        }
        
        $this->db->set    ('category_id', 	$this->category->get_valid_id ( ));
        $this->db->set    ('size_group_id', $this->size_group->get_valid_id ( ));
        $this->db->set    ('barcode', 	    '-1');
        $this->db->set    ('quantity', 		-1);
        $this->db->set    ('reorder_level', -1);
        
        $this->db->insert ('items');
        
        $id = $this->db->insert_id ( );
        $active_language = $this->language->get_current_language ( );
        //
        // also set the items_lang
        //
        if ($this->id != NULL)
        {
            $this->db->set ('item_id', $this->id);
        }
        else
        {
            $this->db->set ('item_id', $id);
        }
        
        $this->db->set    ('language_id', $active_language->id);
        $this->db->set    ('name',        '### NO VALUE ###');
        $this->db->set    ('description', '### NO VALUE ###');
        $this->db->set    ('price_unit',  -1);
        $this->db->set    ('price_cost',  -1);
        
        $this->db->insert ('items_lang');
        
        return $id;
    }

    /**
     * This is the default constructor
     *
     * @param $id:
     * 	If this parameter is supplied, the object will represent an actual database entry.
     * 	Else it will be an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ($id);
        $this->load->model ("items/Category");
        $this->load->model ("items/Size_group");
        $this->load->model ("items/tax");
        $this->load->model ("export-import/language");
        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * This function returns a single object, that mathces the specified id.
     * @param $id: is the value of the primary key in the database. Default value is -1.
     * @return An instance of this class if the id exists, null otherwise.
     */
    function get_by_id ($id = -1)
    {
        $this->db->select ('items.item_id, items_lang.name, items_lang.description, ' .
    					   'items.category_id, items.size_group_id, items.barcode, ' .
    					   'items_lang.price_unit, items_lang.price_cost, items.quantity, ' .
    					   'items.reorder_level');
        $this->db->from   ('items');
        $this->db->join   ('items_lang', 'items.item_id = items_lang.item_id');
        $this->db->join   ('languages',  'languages.language_id  = items_lang.language_id');
        $this->db->where  ('items.item_id',  $id);
        $this->db->where  ('languages.name', $this->config->item ('language'));

        $query = $this->db->get ( );

        if ($query->num_rows ( ) > 0)
        {
            $this->_load ($query->row ( ));
            return ($this);
        }
        else
        {
            return (NULL);
        }
    }

    
    /**
     * Returns an array of objects that CONTAIN any of the given parameters.
     * This function searches for name and description of items written in
     * the sames language as the GUI is currently set to.-
     * 
     * @param $name         A string contained in the name of the 
     *                      searched item. Defaults to NULL.-
     * @param $description  A string contained in the description 
     *                      of the searched item. Defaults to NULL.-
     * @return              An array of objects that CONTAIN any of the given
     *                      parameters or an empty array if nothing has been
     *                      found.-
     */
    function get_by_name_and_description ($name = NULL, $description = NULL)
    {
        $ret_value = array ( );

        //
        // Did we get any valid parameters?
        //
        if ($name != NULL)
        {
            $this->db->select ('I.item_id');
            $this->db->from   ('items_lang I');
            $this->db->join   ('languages',      'languages.language_id  = I.language_id');
            $this->db->where  ('languages.name', $this->config->item ('language'));            
            $this->db->like   ('LOWER (I.name)',   strtolower ($name));
            
            //
            // Is the second parameter also valid?
            //
            if ($description != NULL)
            {
               $this->db->or_like ('LOWER (I.description)', strtolower ($description));
            }
    
            $query = $this->db->get ( );
    
            foreach ($query->result ( ) as $row)
            {
                $item = new Item ($row->item_id);
                array_push ($ret_value, $item);
            }
        }

        return ($ret_value);
    }
    
    
    /**
     * Returns an array containing all existing items.-
     *
     * @return Always returns an array. If there are no items the array is empty.
     */
    function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('items');

        foreach ($query->result ( ) as $row)
        {
            $item = new Item ($row->item_id);
            array_push ($ret_value, $item);
        }

        return ($ret_value);
    }

    
    /**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @return 	A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ( )
    {
    	return parent::get_valid_id ("items", "item_id");
    }
    

    /**
     * Deletes all elements and every relation, that has a foreign key pointing to them.
     */
    public function purge ( )
    {
        //
        // delete the sales data first
        //
        $this->db->empty_table ('sales_payments');
        $this->db->empty_table ('sales_details_taxes');
        $this->db->empty_table ('sales_details');
        $this->db->empty_table ('sales');

        $this->db->empty_table ('items_taxes');
        $this->db->empty_table ('items_lang');
        $this->db->empty_table ('items');
    }

    /**
     * Returns a Category instance, as defined in the category_id attribute.
     *
     * @return an instance of the Category class
     */
    function get_parent_category ( )
    {
        return new Category ($this->category_id);
    }

    /**
     * Returns a Size_group instance, as defined in the size_group_id attribute.
     *
     * @return an instance of the Size_group class
     */
    function get_parent_size_group ( )
    {
        return new Size_group ($this->size_group_id);
    }

    
    /**
     * Returns an item given its barcode.
     * 
     * @param $barcode is the desired item's barcode
     * 
     * @return An instance of this class, if the item with the barcode 
     * 		   exists; NULL otherwise.
     */
    function get_by_barcode ($barcode = NULL)
    {
        $ret_value = NULL;
        
    	//
    	// Did we recieve a valid barcode?
    	//
    	if ($barcode != NULL)
    	{
	        $this->db->select ('items.item_id');
	        $this->db->from   ('items');
	        $this->db->where  ('items.barcode',  trim ($barcode));

	        $query = $this->db->get ( );
	
	        if ($query->num_rows ( ) > 0)
	        {
	            $ret_value = new Item ($query->row ( )->item_id);
	        }
    	}
    	
    	//
    	// Return the corresponding item
    	//
    	return $ret_value;
    }
    

    /**
     * Checks if the object exists in the database.
     *
     * @param $id is the database id. If no id is given, the function will check the
     * 	database for the instance of this object.
     *
     * @return true, it exists, false otherwise
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Item ($this->id);
        }
        else
        {
            $o = new Item ($id);
        }

        return $o->get_by_id($o->id) != NULL;
    }

    /**
     * This function exports the model into a matrix.
     *
     * @param $mode is the exporting mode. If it is set to 1, the foreign keys will be
     * 		  inlined, if two they will be listed as an integer (as in the database),
     * 		  an exception will be thrown otherwise.
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Item intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    public function export ($mode, $languages, $entities = NULL)
    {
        switch ($mode)
        {
            case 1:
                return $this->_export_flat ($mode, $languages, $entities);

            case 2:
                return $this->_export_simple ($languages, $entities);

            default:
                throw new Exception ('The exporting mode ' . $mode . ' is not supported.');
        }
    }

    /**
     * Imports the flat data into the database.
     *
     * @param $mode is the importing mode
     * @param $data a matrix (array of array), where the outer index represents rows and the
     * 		  inner index represents columns. This paramater is without headers.
     * @param $languages is an array of languages, sorted in the same way as are the columns
     * 		  int the data parameter
     */
    public function import_flat ($mode, $data, $languages)
    {
        if ($mode == 1)
        {
            $this->purge ( );
        }



        //
        // extract sizes
        //
        $size_index = 4 + (4 * count ($languages));
        $size_data = array ( );
        foreach ($data as $row)
        {
            $in_table = false;
            foreach ($size_data as $size_row)
            {
                if ($size_row[0] == $row[$size_index])
                {
                    $in_table = true;
                    break;
                }
            }

            if ($in_table == false)
            {
                array_push ($size_data, array_slice ($row, $size_index, 3));
            }
        }
        $this->Size_group->import_simple ($mode, $size_data);

        //
        // extract categories
        //
        $categories_index = $size_index + 3;
        $categories_data = array ( );
        foreach ($data as $row)
        {
            $in_table = false;
            foreach ($categories_data as $category_row)
            {
                if ($category_row[0] == $row[$categories_index])
                {
                    $in_table = true;
                    break;
                }
            }

            if ($in_table == false)
            {
                array_push ($categories_data, array_slice ($row, $categories_index));
            }
        }
        $this->Category->import_simple ($mode, $categories_data, $languages);

        //
        // extract items
        //
        $taxes_index = ($categories_index + 1 + 2 * count ($languages)) + 1;
        $items_data = array ( );
        foreach ($data as $row)
        {
            $item_row = array_slice ($row, 0, $size_index + 1);
            array_push ($item_row, $row[$categories_index]);
            $item_row = array_merge ($item_row, array_slice ($row, $taxes_index));
            array_push ($items_data, $item_row);
        }
        $this->import_simple ($mode, $items_data, $languages);
    }

    public function import_simple ($mode, $data, $languages)
    {
        if ($mode == 1)
        {
            $this->purge ( );
        }

        $size_index = 4 + (4 * count ($languages));
        $categories_index = $size_index + 1;
        foreach ($data as $row)
        {
            //
            // This meta item is needed for proper use of the real - variables.
            // FIXME: Find a better way
            //
            $dummy_item = new Item ( );
            $dummy_item->set_real_value ('quantity',      $row[2]);
            $dummy_item->set_real_value ('reorder_level', $row[3]);
            
            
            
            //
            // if exists
            //
            if ($this->db->get_where ('items', array ('item_id' => $row[0]))->num_rows ( ) > 0)
            {
                if ($mode == 1 || $mode == 2)
                {
                    $this->db->set    ('barcode',       $row[1]);
                    $this->db->set    ('quantity',      $dummy_item->quantity);
                    $this->db->set    ('reorder_level', $dummy_item->reorder_level);
                    $this->db->set    ('category_id',   $row[$categories_index]);
                    $this->db->set    ('size_group_id', $row[$size_index]);
                    
                    $this->db->where  ('item_id =',     $row[0]);
                    
                    $this->db->update ('items');
                }
            }
            else
            {
                $this->db->set    ('barcode',       $row[1]);
                $this->db->set    ('quantity',      $dummy_item->quantity);
                $this->db->set    ('reorder_level', $dummy_item->reorder_level);
                $this->db->set    ('category_id',   $row[$categories_index]);
                $this->db->set    ('size_group_id', $row[$size_index]);
                $this->db->set    ('item_id',       $row[0]);
                
                $this->db->insert ('items');
            }

            //
            // language data
            //
            $name_index = 4;
            $description_index = $name_index + count ($languages);
            $price_unit_index = $description_index + count ($languages);
            $price_cost_index = $price_unit_index + count ($languages);
            for ($i = 0; $i < count ($languages); $i++)
            {
                $dummy_item->set_real_value ('price_unit', $row[$price_unit_index + $i]);
                $dummy_item->set_real_value ('price_cost', $row[$price_cost_index + $i]);
                
                //
                // if exists
                //
                if ($this->db->get_where ('items_lang', array ('item_id' => $row[0], 'language_id' => $languages[$i]->id))->num_rows ( ) > 0)
                {
                    if ($mode == 1 || $mode == 2)
                    {
                        $this->db->set    ('name',          $row[$name_index + $i]);
                        $this->db->set    ('description',   $row[$description_index + $i]);
                        $this->db->set    ('price_unit',    $dummy_item->price_unit);
                        $this->db->set    ('price_cost',    $dummy_item->price_cost);
                        
                        $this->db->where  ('item_id =',     $row[0]);
                        $this->db->where  ('language_id =', $languages[$i]->id);
                        
                        $this->db->update ('items_lang');
                    }
                }
                else
                {
                    $this->db->set    ('name',        $row[$name_index + $i]);
                    $this->db->set    ('description', $row[$description_index + $i]);
                    $this->db->set    ('price_unit',  $dummy_item->price_unit);
                    $this->db->set    ('price_cost',  $dummy_item->price_cost);
                    $this->db->set    ('item_id',     $row[0]);
                    $this->db->set    ('language_id', $languages[$i]->id);
                    
                    $this->db->insert ('items_lang');
                }
            }

            //
            // tax data
            //
            $taxes_index = $categories_index + 1;
            for ($i = $taxes_index; $i < count ($row); $i += 3)
            {
                //
                // skip an empty column
                //
                if ($row[$i] == '' && $row[$i + 1] == '' && $row[$i + 2] == '')
                {
                    continue;
                }
                
                
                $tax = new Tax ($row[$i]);
                $tax->name = $row[$i + 1];
                $tax->set_real_value ('percent', $row[$i + 2]);
                $tax->item_id = $row[0];
                
                //
                // FIXME: Issue #36
                // Manually add the id, because the constructor overrides the id,
                // if the object is not in the database.
                //
                $tax->id = $row[$i];
                
                if ($mode == 1 || $mode == 2)
                {
                    $tax->update ( );
                }
                else if ($mode == 3)
                {
                    if (!$tax->exists ( ))
                    {
                        $tax->update ( );
                    }
                }
            }
        }

        // check, if we need to remove a tax
        if ($mode == 1 || $mode == 2)
        {
            $items = $this->get_all ( );

            foreach ($items as $item)
            {
                $taxes = $this->tax->get_by_item ($item->id);

                foreach ($taxes as $tax)
                {
                    $delete = true;
                    foreach ($data as $row)
                    {
                        if ($row[0] == $item->id)
                        {
                            for ($i = $taxes_index; $i < count ($row); $i += 3)
                            {
                                if ($row[$i] == $tax->id)
                                {
                                    $delete = false;
                                }
                            }
                        }
                    }

                    if ($delete)
                    {
                        $this->tax->delete_all (array ($tax->id));
                    }
                }
            }
        }
    }

    
    /**
     * Synchronizes the database with this object instance.-
     * 
     * @return TRUE on success, FALSE otherwise.-
     */
    public function update ( )
    {
    	$ret_value = false;
    	
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }
    	        
        $this->db->set    ('category_id',   $this->category_id);
        $this->db->set    ('size_group_id', $this->size_group_id);
        $this->db->set    ('barcode', 		$this->barcode);
        $this->db->set    ('quantity', 		$this->quantity);
        $this->db->set    ('reorder_level', $this->reorder_level);
        
        $this->db->where  ('item_id', $this->id);
        $this->db->update ('items');
        
        $ret_value |= ($this->db->affected_rows ( ) > 0);
        
        //
        // also update the items_lang
        //
        $active_language = $this->language->get_current_language ( );
        
        $this->db->set    ('name', 		  $this->name);
        $this->db->set    ('description', $this->description);
        $this->db->set    ('price_unit',  $this->price_unit);
        $this->db->set    ('price_cost',  $this->price_cost);
        
        $this->db->where  ('item_id =', 	$this->id);
        $this->db->where  ('language_id =', $active_language->id);
        $this->db->update ('items_lang');
        
        $ret_value |= ($this->db->affected_rows ( ) > 0);
        
        //
        // Return value
        //
        return ($ret_value);
    }

    /**
     * Gets information about a particular item.
     * @deprecated
     */
    function get_info($item_id)
    {
        $this->db->from('items');
        $this->db->where('item_id',$item_id);
        $query = $this->db->get();

        if($query->num_rows()==1)
        {
            return $query->row();
        }
        else
        {
            //Get empty base parent object, as $item_id is NOT an item
            $item_obj=new stdClass();

            //Get all the fields from items table
            $fields = $this->db->list_fields('items');

            foreach ($fields as $field)
            {
                $item_obj->$field='';
            }

            return $item_obj;
        }
    }


    /**
     * Gets information about multiple items.
     * @deprecated
     */
    function get_multiple_info($item_ids)
    {
        $this->db->from('items');
        $this->db->where_in('item_id',$item_ids);
        $this->db->order_by("item", "asc");
        return $this->db->get();
    }

    /**
     * Inserts or updates a item
     * @deprecated
     */
    function save(&$item_data,$item_id=false)
    {
        if (!$item_id or !$this->exists($item_id))
        {
            if($this->db->insert('items',$item_data))
            {
                $item_data['item_id']=$this->db->insert_id();
                return true;
            }
            return false;
        }

        $this->db->where('item_id', $item_id);
        return $this->db->update('items',$item_data);
    }

    /**
     * Updates multiple items at once
     * @deprecated
     */
    function update_multiple($item_data,$item_ids)
    {
        $this->db->where_in('item_id',$item_ids);
        return $this->db->update('items',$item_data);
    }

    /**
     * Deletes one item
     * @deprecated
     */
    function delete($item_id)
    {
        return $this->db->delete('items', array('item_id' => $item_id));
    }

    /**
     * Deletes a list of items
     * @deprecated
     */
    function delete_list($item_ids)
    {
        $this->db->where_in('item_id',$item_ids);
        return $this->db->delete('items');
    }

    /**
     * Get search suggestions to find items
     * @deprecated
     */
    function get_search_suggestions($search,$limit=25)
    {
        $suggestions = array();

        $this->db->from('items');
        $this->db->like('name', $search);
        $this->db->order_by("name", "asc");
        $by_name = $this->db->get();
        foreach($by_name->result() as $row)
        {
            $suggestions[]=$row->name;
        }

        $this->db->select('category');
        $this->db->from('items');
        $this->db->distinct();
        $this->db->like('category', $search);
        $this->db->order_by("category", "asc");
        $by_category = $this->db->get();
        foreach($by_category->result() as $row)
        {
            $suggestions[]=$row->category;
        }

        $this->db->from('items');
        $this->db->like('item_number', $search);
        $this->db->order_by("item_number", "asc");
        $by_item_number = $this->db->get();
        foreach($by_item_number->result() as $row)
        {
            $suggestions[]=$row->item_number;
        }


        //only return $limit suggestions
        if(count($suggestions > $limit))
        {
            $suggestions = array_slice($suggestions, 0,$limit);
        }
        return $suggestions;

    }

    /**
     * @deprecated
     */
    function get_item_search_suggestions($search,$limit=25)
    {
        $suggestions = array();

        $this->db->from('items');
        $this->db->like('name', $search);
        $this->db->order_by("name", "asc");
        $by_name = $this->db->get();
        foreach($by_name->result() as $row)
        {
            $suggestions[]=$row->item_id.'|'.$row->name;
        }
        //only return $limit suggestions
        if(count($suggestions > $limit))
        {
            $suggestions = array_slice($suggestions, 0,$limit);
        }
        return $suggestions;

    }

    /**
     * @deprecated
     */
    function get_category_suggestions($search)
    {
        $suggestions = array();
        $this->db->distinct();
        $this->db->select('category');
        $this->db->from('items');
        $this->db->like('category', $search);
        $this->db->order_by("category", "asc");
        $by_category = $this->db->get();
        foreach($by_category->result() as $row)
        {
            $suggestions[]=$row->category;
        }

        return $suggestions;
    }

    /**
     * Preform a search on items
     * @deprecated
     */
    function search($search)
    {
        $this->db->from('items');
        $this->db->like('name', $search);
        $this->db->or_like('item_number', $search);
        $this->db->or_like('category', $search);
        $this->db->order_by("name", "asc");
        return $this->db->get();
    }
}
?>

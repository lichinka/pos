<?php
require_once 'application/models/entity.php';

/**
 * This class represents a size group (e.g. {XS, S, M, L, XL} or {36, 38, 40, ...}) for items.-
 *
 * @author luka
 *
 */
class Size_group extends Entity
{
    var $id;
    var $name;
    var $size_ids;

    /**
     * Returns an array of headers for the export function. The column order is the same as
     * in the exported data.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     *
     * @return an array of strings
     */
    private function construct_headers ($languages)
    {
        $size_headers = array (
        'headers'=>array (
        $this->lang->line ('items_size_group') . ' ' . $this->lang->line ('common_id'),
        $this->lang->line ('items_size_group') . ' ' . $this->lang->line ('common_name'),
        $this->lang->line ('items_size_group')
        ),
        'language_dependant'=>array ( )
        );

        return $size_headers['headers'];
    }
    
	/**
     * Returns an array of sizes, that belong to this size group.
     *
     * @param $id is the database id of this size group.
     * @return an array, that contains instances of the Size class. It may also be empty.
     */
    private function __get_sizes ($id)
    {
        // FIXME: this function should be added to the UML, or inlined into the _load function.
        $result = array ( );

        $this->db->select   ('sizes.size_id');
        $this->db->from     ('sizes');
        $this->db->where    ('sizes.size_group_id =', $id);
        $this->db->order_by ('sizes.order', 'ASC');

        foreach ($this->db->get ( )->result ( ) as $row)
        {
            array_push ($result, $row->size_id);
        }


        return $result;
    }
    
	/**
     * Loads the size group data held in the row received as parameter.
     */
    protected function _load ($row)
    {
        $this->id 	    = $row->size_group_id;
        $this->name     = $row->name;
        $this->size_ids = $this->__get_sizes ($row->size_group_id);
    }
    
	/**
     * Creates an empty bag.
     *
     * @return the database id of the empty bag
     */
    protected function _insert ( )
    {
        if ($this->id != NULL)
        {
            $this->db->set ('size_group_id', $this->id);
        }
        $this->db->set     ('name', '### NO VALUE ###');
        $this->db->insert  ('size_groups');

        
        $id = $this->db->insert_id ( );
        //
        // This should never do anything.
        //
        $this->db->where  ('size_group_id =', $id);
        $this->db->delete ('sizes');
        
        return $id;
    }

    /**
     * Constructor
     */
    function __construct ($id = NULL)
    {
        parent::__construct ( );
        $this->load->model ("items/Size");

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * Returns a size group based on its ID.-
     */
    function get_by_id ($id = -1)
    {
        $query = $this->db->get_where ('size_groups', array ('size_group_id' => $id), 1);

        if ($query->num_rows ( ) > 0)
        {
            $this->_load ($query->row ( ));
             
            //
            // Retrieve all sizes contained in this group in the specified order
            //
            $this->db->order_by ('order', 'ASC');
            $this->db->order_by ('name',  'ASC');
             
            $query = $this->db->get_where ('sizes', array ('size_group_id' => $id));
             
            if ($query->num_rows ( ) > 0)
            {
                //
                // Initialize the array of sizes for this size group
                //
                $this->size_ids = array ( );

                foreach ($query->result ( ) as $row)
                {
                    array_push ($this->size_ids, $row->size_id);
                }
            }
             
            return ($this);
        }
        else
        {
            return (NULL);
        }
    }


    /**
     * Returns an array containing all existing size groups.-
     */
    function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('size_groups');

        foreach ($query->result ( ) as $row)
        {
            $size_group = new Size_group ($row->size_group_id);
            array_push ($ret_value, $size_group);
        }

        return ($ret_value);
    }
    
 	/**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @return 	A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ( )
    {
    	return parent::get_valid_id ("size_groups", "size_group_id");
    }

    /**
     * Deletes all elements (sizes and size groups).
     */
    public function purge ( )
    {
        $this->db->empty_table ('sizes');
        $this->db->empty_table ('size_groups');
    }

    /**
     * Returns an array of  Size instances, as defined in the site_ids attribute.
     *
     * @return an array of Size instances. It may be empty.
     */
    function get_sizes ( )
    {
        $return_val = array ( );
        if (!empty ($this->size_ids))
        {
            foreach ($this->size_ids as $size_id)
            {
                array_push ($return_val, new Size ($size_id));
            }
        }
        return $return_val;
    }

    /**
     * Checks if the object exists in the database.
     *
     * @param $id is the database id. If no id is given, the function will check the
     * 	database for the instance of this object.
     *
     * @return true, it exists, false otherwise
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Size_group ($this->id);
        }
        else
        {
            $o = new Size_group ($id);
        }

        return $o->get_by_id($o->id) != NULL;
    }

    /**
     * This function exports the model into a matrix.
     *
     * @param $mode is the exporting mode (only the number 1 is allowed)
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Size_group intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    public function export ($mode, $languages, $entities = NULL)
    {
        if ($mode != '1')
        {
            throw new Exception ('The exporting mode ' . $mode . ' is not supported.');
        }

        $sizes_rows = array ($this->construct_headers ($languages));

        if ($entities === NULL)
        {
            $size_groups = array ($this);
        }
        else
        {
            $size_groups = $entities;
        }


        foreach ($size_groups as $size_group)
        {
            $size_row = array ( );
            $sizes_cell = '';
            foreach ($size_group->get_sizes ( ) as $size)
            {
                $sizes_cell = $sizes_cell . ';' . $size->name;
            }
            if ($sizes_cell != '')
            {
                $sizes_cell = substr ($sizes_cell, 1);
            }

            array_push ($size_row, $size_group->id);
            array_push ($size_row, $size_group->name);
            array_push ($size_row, $sizes_cell);

            array_push ($sizes_rows, $size_row);
        }

        return $sizes_rows;
    }

    /**
     * Imports the flat data into the database.
     *
     * @param $mode is the importing mode
     * @param $data a matrix (array of array), where the outer index represents rows and the
     * 		  inner index represents columns. This paramater is without headers.
     * @param $languages is an array of languages, sorted in the same way as are the columns
     * 		  int the data parameter
     */
    public function import_simple ($mode, $data)
    {
        if ($mode == 1)
        {
            $this->purge ( );
        }


        foreach ($data as $row)
        {
            $temp = new Size_group ( );
            $temp->id = $row[0];
            $temp->name = $row[1];
            $temp->update ( );


            $sizes_cell = '';
            foreach ($temp->get_sizes ( ) as $size)
            {
                $sizes_cell = $sizes_cell . ';' . $size->name;
            }
            if ($sizes_cell != '')
            {
                $sizes_cell = substr ($sizes_cell, 1);
            }


            if ($mode == 1 || $mode == 2 || $mode == 3 && $sizes_cell != $row[2])
            {
                $this->db->where  ('size_group_id', $temp->id);
                $this->db->delete ('sizes');

                $size_strings = explode (';', $row[2]);
                for ($i = 0; $i < count ($size_strings); $i++)
                {
                    $this->db->set    ('size_group_id', $temp->id);
                    $this->db->set    ('name', $size_strings[$i]);
                    $this->db->set    ('order', $i + 1);
                    $this->db->insert ('sizes');
                }
            }
        }
    }

    /**
     * Synchronizes the database with this object.
     */
    public function update ( )
    {   
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }
        $this->db->set    ('name',            $this->name);
        $this->db->where  ('size_group_id =', $this->id);
        
        $this->db->update ('size_groups');
        
        //
        // Return value
        //
        return ($this->db->affected_rows ( ) > 0);
    }
    
    /**
     * Replaces this groups sizes with the sizes in the ordered array.
     * 
     * @deprecated
     * @param $sizes is an array of size strings
     */
    public function replace_sizes ($sizes)
    {
        $this->db->where  ('size_group_id', $this->id);
        $this->db->delete ('sizes');
        
        for ($i = 0; $i < count ($sizes); $i++)
        {
            $this->db->set    ('size_group_id', $this->id);
            $this->db->set    ('name', $sizes[$i]);
            $this->db->set    ('order', $i + 1);
            $this->db->insert ('sizes');
        }
    }
    
    /**
     * Deletes a single size group and its sizes.
     * 
     * @deprecated
     * @param $size_group_id is the size_group's id
     * @return True, if succeeded, false otherwise
     */
    public function delete ($size_group_id)
    {
        $this->db->where  ('size_group_id =', $size_group_id);
        $this->db->delete ('sizes');
        
        $this->db->where  ('size_group_id =', $size_group_id);
        $this->db->delete ('size_groups');
        
        return true;
    }
}
?>

<?php
$lang['login_login']='Prijava';
$lang['login_username']='Uporabniško ime';
$lang['login_password']='Geslo';
$lang['login_go']='Naprej';
$lang['login_cancel']='Prekliči';
$lang['login_invalid_username_and_password']='Napančni vnos uporabniškega imena in/ali gesla.';
$lang['login_welcome_message']='Dobrodošli na sistemu CenTRO!';
?>
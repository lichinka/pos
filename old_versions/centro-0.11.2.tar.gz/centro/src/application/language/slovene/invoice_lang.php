<?php
$lang['invoice_title']   = 'Račun';
$lang['invoice_keyword'] = 'račun';

$lang['invoice_phone'] = 'Tel';

$lang['invoice_time']          = 'Ura';
$lang['invoice_time_format']   = '%X';
$lang['invoice_date']          = 'Datum';
$lang['invoice_date_format']   = '%x';
$lang['invoice_sale_metadata'] = 'Blagajna - št. računa';

$lang['invoice_price_ammount'] = 'Znesek';
$lang['invoice_item_name']     = 'Naziv artikla';
$lang['invoice_price']         = 'Cena(EUR)';

$lang['invoice_sum']                           = 'V S O T A';
$lang['invoice_total_price']                   = 'Za plačilo EUR';
$lang['invoice_secondary_currency']            = 'SIT';
$lang['invoice_secondary_currency_conversion'] = '(1 EUR = 239,6400 SIT)';

$lang['invoice_tax_rate_price']  = 'ZNESKI PO DAVČNIH STOPNJAH';
$lang['invoice_tax_rate']        = 'Davčna stop.';
$lang['invoice_tax_total_price'] = 'Znesek plač.';
$lang['invoice_tax_price']       = 'Vračun. DDV';
$lang['invoice_tax_price_sum']   = 'Skupaj DDV';

$lang['invoice_payed']         = 'Plačano';
$lang['invoice_returned']      = 'Vrnjeno';
$lang['invoice_discount_info'] = 'Popusti ne veljajo za izdelke označene z *.';

$lang['invoice_cashier'] = 'Blagajnik';

$lang['invoice_footer'] = 'Sem se bodo verjetno vpisale dodatne informacije. Sedaj služi za test znakov : ČĆĐŠŽčćđžš';
$lang['invoice_thanks'] = 'HVALA ZA NAKUP';
$lang['invoice_url']    = '----www.centro.si----'
?>
<?php
$lang['customers_add']='Nova stranka';
$lang['customers_edit']='Uredi stranko';
$lang['customers_customer']='Stranka';
$lang['customers_plural']='Stranke';
$lang['customers_update']='Spremeni stranko';
$lang['customers_confirm_delete']='Ali želite izbrisati izbrane stranke?';
$lang['customers_none_selected']='Niste izbrali nobene stranke za izbris.';
$lang['customers_error_adding_updating'] = 'Med spremembo stranke je prišlo do napake.';
$lang['customers_successful_adding']='Ustvarjenje nove stranke je bilo uspešno.';
$lang['customers_successful_updating']='Stranka je bila uspešno spremenjena.';
$lang['customers_successful_deleted']='Stranka je bila uspešno izbrisana.';
$lang['customers_one_or_multiple']='stranka/stranke';
$lang['customers_cannot_be_deleted']='Ne morem nadaljevati z izbrasanjem stranke, ker ima vezano prodajo.';
$lang['customers_basic_information']='Informacija o stranki';
$lang['customers_account_number']='Številka računa';
?>
<?php
$lang['sizes_single'] = "Velikost";
$lang['sizes_plural'] = "Velikosti";
$lang['sizes_groups_plural'] = "Skupine velikosti";
$lang['sizes_add']='Dodaj novo skupino velikosti';
$lang['sizes_edit']='Uredi skupino velikosti';
$lang['sizes_group_name']='Ime skupine';
$lang['sizes_basic_information']='Podatki o velikostih';
$lang['sizes_no_size_error']='Polje 1. Velikost ne sme biti prazno.';
?>
<?php
$lang['export'] = 'Izvozi podatke';
$lang['export_relation'] = 'Izberi objekte za izvoz';
$lang['export_mode'] = 'Izberi način izvoza';
$lang['export_languages'] = 'Izberi jezik(e) za izvoz';
$lang['export_mode_flat'] = 'Ena datoteka';
$lang['export_mode_files'] = 'Več datotek';
$lang['export_flat_reference_warning'] = 'Če izvažate artikle v eno datoteko in če obstajajo kategorije ali velikosti, ki jih ne vsebuje noben artikel, le te ne bodo izvožene.';
$lang['export_fields_warning'] = 'Vedno je treba izbrati vsaj en jezik.';
$lang['export_multiple_warning'] = 'V več datotek se da izvoziti le artikel.';
$lang['export_employees_warning'] = 'Delavci ne izvozijo gesel, terminalov in modulov';
$lang['export_notes'] = 'Opombe';
$lang['export_select'] = 'Izberi';
$lang['export_english'] = 'Angleščina';
$lang['export_slovene'] = 'Slovenščina';

$lang['import'] = 'Uvozi podatke';
$lang['import_relation'] = 'Izberi objekte za uvoz';
$lang['import_upload'] = 'Naloži datoteke';
$lang['import_mode'] = 'Izberi način za uvoz';
$lang['import_file'] = 'datoteka';
$lang['import_mode_replace_all'] = 'Zamenjaj celotno zbirko podatkov';
$lang['import_mode_replace_existing'] = 'Prepiši obstoječe elemente in dodaj nove';
$lang['import_mode_no_replace'] = 'Dodaj samo nove elemente';
$lang['import_mode_replace_all_warning'] = 'Vrsta uvoza "' . $lang['import_mode_replace_all'] . '" bo izbrisala vse podatke o prodaji';
$lang['import_number_files_warning'] = 'Vedno je potrebno naložiti vsaj eno datoteko.';
$lang['import_multiple_files_warning'] = 'Več datotek lahko uvozite le za aritkle.';
$lang['import_items_multiple_files_warning'] = 'Če uvažate več datotek, morajo biti v naslednjem vrstem redu: 1. datoteka: artikli, 2. datoteka: velikosti, 3. datoteka: kategorije.';
$lang['import_employees_password_warning'] = 'Vsi delavci s praznim geslom, bodo dobili geslo: 87654321';
$lang['import_error_no_files'] = 'Niste naložili nobene datoteke';
$lang['import_error_number_files'] = 'Napačno število datotek';
$lang['import_error_number_languages'] = 'Ta terminal nima vseh potrebnih jezikov';
?>
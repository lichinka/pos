<?php
$lang['categories_name']='Kategorije';
$lang['categories_single']='Kategorija';
$lang['categories_plural']='Kategorije';
$lang['categories_parent']='Nadkategorija';
$lang['categories_new']='Dodaj kategorijo';
$lang['categories_edit']='Uredi kategorijo';
$lang['categories_basic_information']='Podatki o kategoriji';
?>
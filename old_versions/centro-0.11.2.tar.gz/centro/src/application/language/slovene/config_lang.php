<?php
$lang['config_company_page_title']='Nastavitve podjetja';
$lang['config_company_info']='Podatki o podjetju';
$lang['config_company_name']='Ime podjetja';
$lang['config_company_address']='Naslov podjetja';
$lang['config_company_identification'] = 'ID za DDV';
$lang['config_store_edit_stores'] = 'Uredi P.E.';

$lang['config_store_add'] = 'Dodaj P.E.';
$lang['config_store_page_title'] = 'Poslovne enote';
$lang['config_store_info'] = 'Podatki o poslovni enoti';
$lang['config_store_name'] = 'Ime P.E.';
$lang['config_store_address'] = 'Naslov';
$lang['config_store_telephone']='Telefonska številka';
$lang['config_store_delete'] = 'Ali ste prepričani, da želite izbrisati izbrano P.E.?';
$lang['config_store_delete_none_selected'] = 'Niste izbrali nobene P.E.';

$lang['config_store_info'] = 'Podatki o poslovni enoti';
$lang['config_store_edit_page_title'] = 'Uredi P.E.';

$lang['config_terminal_edit_terminals'] = 'Uredi terminale';
$lang['config_terminal_add'] = 'Dodaj terminal';
$lang['config_terminal_page_title'] = 'Terminali';
$lang['config_terminal_name'] = 'Serijska številka';
$lang['config_terminal_delete'] = 'Ali ste prepričani, da želite izbrisati izbrane terminale?';
$lang['config_terminal_delete_none_selected'] = 'Niste izbrali nobenega terminala.';

$lang['config_terminal_info'] = 'Podatki o terminalu';
$lang['config_terminal_edit_page_title'] = 'Uredi terminal';


$lang['config_website']='Spletna stran';
$lang['config_fax']='Številka faksa';
$lang['config_default_tax_rate']='Privzeta davčna stopnja %';
$lang['config_company_required']='Polje `Ime podjetja` ne sme biti prazno.';
$lang['config_address_required']='Polje `Naslov podjetja` ne sme biti prazno.';
$lang['config_telephone_required']='Polje `Telefonska številka podjetja` ne sme biti prazno.';
$lang['config_default_tax_rate_required']='Polje `Privzeta davčna stopnja` ne sme biti prazno.';
$lang['config_default_tax_rate_number']='Privzeta davčna stopnja mora biti številka.';
$lang['config_company_website_url']='Oblika polja `Spletna stran podjetja` ni pravilna (http://...)';
$lang['config_saved_successfully']='Nastavitve so bile uspešno shranjene.';
$lang['config_saved_unsuccessfully']='Med shranjevanjem nastavitev je prišlo do napake.';
$lang['config_return_policy_required']='Polje `Pravilnik o vrnitvi blaga` ne sme biti prazno.';
?>
<?php
$lang['error_no_permission_module']='Žal nimate dostopa do izbranega modula.';
$lang['error_unknown']='Neznana napaka.';
$lang['too_many_rows']='Opozorilo! Zadnja poizvedba je vrnila nepričakovano število vrstic.';
?>
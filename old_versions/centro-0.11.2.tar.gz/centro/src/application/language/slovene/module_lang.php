<?php
$lang['module_home']='Začetna stran';

$lang['module_customer']='Stranke';
$lang['module_customer_desc']='Dodajanje, spreminanje, izbrisanje in iskanje strank';

$lang['module_employee']='Osebje';
$lang['module_employee_desc']='Dodajanje, spreminanje, izbrisanje in iskanje osebja';

$lang['module_sales']='Prodaja';
$lang['module_sales_desc']='Prodaja in vrnitev blaga';

$lang['module_reports']='Poročila';
$lang['module_reports_desc']='Pogled in ustvarjanje poročil';

$lang['module_categories']='Kategorije artiklov';
$lang['module_categories_desc']='Dodajanje, spreminanje, izbrisanje in iskanje kategorij artiklov';

$lang['module_items']='Artikli';
$lang['module_items_desc']='Dodajanje, spreminanje, izbrisanje in iskanje artiklov';

$lang['module_config']='Nastavitve sistema';
$lang['module_config_desc']='Spreminanje nastavitev blagajniškega sistema CenTRO';

?>
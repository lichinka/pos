<?php
$lang['employees_employee']='Delavec';
$lang['employees_plural']='Delavci';
$lang['employees_add']='Dodaj delavca';
$lang['employees_update']='Spremeni delavca';
$lang['employees_confirm_delete']='Ali želite izbrisati izbrane delavce?';
$lang['employees_none_selected']='Niste izbrali nobenega delavca za izbris.';
$lang['employees_error_adding_updating'] = 'Med spremembo delavca je prišlo do napake.';
$lang['employees_successful_adding']='Ustvarjenje novega delavca je bilo uspešno.';
$lang['employees_successful_updating']='Podatki delavca so bili uspešno spremenjeni.';
$lang['employees_successful_deleted']='Delavec je bil izbrisan.';
$lang['employees_one_or_multiple']='delavci';
$lang['employees_cannot_be_deleted']='Ne morem nadaljevati z izbrasanjem delavcev, ker ima vezano prodajo.';
$lang['employees_username']='Uporabniško ime';
$lang['employees_password']='Geslo';
$lang['employees_repeat_password']='Ponovitev gesla';
$lang['employees_username_required']='Polje `Uporabniško ime` ne sme biti prazno.';
$lang['employees_username_minlength']='Uporabniško ime mora vsebovati vsaj 5 znakov.';
$lang['employees_password_required']='Polje `Geslo` ne sme biti prazno.';
$lang['employees_password_minlength']='Geslo mora vsebovati vsaj 8 znakov.';
$lang['employees_password_must_match']='Gesli se ne ujemata.';
$lang['employees_basic_information']='Osnovni podatki delavca';
$lang['employees_login_info']='Podatki za prijavo delavca';
$lang['employees_permission_info']='Dovoljenja in dostopi delavca';
$lang['employees_permission_desc']='Označite dostop do posameznih modulov.';
$lang['employees_login_terminal_desc']='Izberite v katere terminale se uporabnik lahko prijavi.';
$lang['employees_login_terminal_store_selected']='Preverite podatke o terminalih.';
?>
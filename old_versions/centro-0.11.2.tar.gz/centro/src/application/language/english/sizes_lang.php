<?php
$lang['sizes_single'] = "Size";
$lang['sizes_plural'] = "Sizes";
$lang['sizes_groups_plural'] = "Size grups";
$lang['sizes_add']='Add  new size group';
$lang['sizes_edit']='Edit the size group';
$lang['sizes_group_name']='Size group name';
$lang['sizes_basic_information']='Sizes data';
$lang['sizes_no_size_error']='The field 1. Size is required';
?>
<?php
$lang['categories_name']='Categories';
$lang['categories_single']='Category';
$lang['categories_plural']='Categories';
$lang['categories_parent']='Parent category';
$lang['categories_new']='Add category';
$lang['categories_edit']='Edit category';
$lang['categories_basic_information']='Category data';
?>
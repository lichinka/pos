<?php
$lang['error_no_permission_module']='You do not have permission to access the module named';
$lang['error_unknown']='Unknown error';
$lang['too_many_rows']='WARNING: The last query returned too many rows.';
?>
<?php
$lang['export'] = 'Export data';
$lang['export_relation'] = 'Select objects to export';
$lang['export_mode'] = 'Select the export mode';
$lang['export_languages'] = 'Select the laguages to export';
$lang['export_mode_flat'] = 'One file';
$lang['export_mode_files'] = 'Multiple files';
$lang['export_flat_reference_warning'] = 'If you export items and select one file, are any categories or sizes, that are not refferenced by at least one item will not be exported.';
$lang['export_fields_warning'] = 'You must always choose at least one language.';
$lang['export_multiple_warning'] = 'Only items can be expoterd into multiple files.';
$lang['export_employees_warning'] = 'Employees do not export passwords, terminals and modules.';
$lang['export_notes'] = 'Notes';
$lang['export_select'] = 'Select';
$lang['export_english'] = 'English';
$lang['export_slovene'] = 'Slovene';

$lang['import'] = 'Import data';
$lang['import_relation'] = 'Select objects to import';
$lang['import_upload'] = 'Select files to upload';
$lang['import_mode'] = 'Select the importing mode';
$lang['import_file'] = 'file';
$lang['import_mode_replace_all'] = 'Repalce the entire database';
$lang['import_mode_replace_existing'] = 'Replace existing elements and append new data';
$lang['import_mode_no_replace'] = 'Add the new elements only';
$lang['import_mode_replace_all_warning'] = 'The "' . $lang['import_mode_replace_all'] . '" import will erase the sales data';
$lang['import_number_files_warning'] = 'Always upload at least one file.';
$lang['import_multiple_files_warning'] = 'Only items can be imported through multiple files.';
$lang['import_items_multiple_files_warning'] = 'If you import multiple files, you must upload the files in the following order: 1. file: items, 2. file: sizes, 3. file: categories';
$lang['import_employees_password_warning'] = 'All employees with no password wil recieve the default password: 87654321';
$lang['import_error_no_files'] = 'No files were uploaded';
$lang['import_error_number_files'] = 'Wrong number of files';
$lang['import_error_number_languages'] = 'This terminal does not have all the required languages';
?>
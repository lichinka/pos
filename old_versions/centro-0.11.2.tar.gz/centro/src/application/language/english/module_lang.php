<?php
$lang['module_home']='Home';

$lang['module_customer']='Customers';
$lang['module_customer_desc']='Add, Update, Delete, and Search customers';

$lang['module_employee']='Employees';
$lang['module_employee_desc']='Add, Update, Delete, and Search employees';

$lang['module_sales']='Sales';
$lang['module_sales_desc']='Process sales and returns';

$lang['module_reports']='Reports';
$lang['module_reports_desc']='View and generate reports';

$lang['module_categories']='Categories';
$lang['module_categories_desc']='Add, Update, Delete, and Search categories';

$lang['module_items']='Items';
$lang['module_items_desc']='Add, Update, Delete, and Search items';

$lang['module_config']='Store Config';
$lang['module_config_desc']='Change the store\'s configuration';

?>
<?php
$lang['invoice_title']   = 'Invoice';
$lang['invoice_keyword'] = 'invoice';

$lang['invoice_phone'] = 'Tel';

$lang['invoice_time']          = 'Time';
$lang['invoice_time_format']   = '%X';
$lang['invoice_date']          = 'Date';
$lang['invoice_date_format']   = '%x';
$lang['invoice_sale_metadata'] = 'Register - invoice no.';

$lang['invoice_price_ammount'] = 'Ammount';
$lang['invoice_item_name']     = 'Item name';
$lang['invoice_price']         = 'Price($)';

$lang['invoice_sum']                           = 'S  U  M';
$lang['invoice_total_price']                   = '$ to pay';
$lang['invoice_secondary_currency']            = 'EUR';
$lang['invoice_secondary_currency_conversion'] = '(1 $ = 0.71500 EUR)';

$lang['invoice_tax_rate_price']  = 'AMMOUNTS BY TAX RATES';
$lang['invoice_tax_rate']        = 'Tax rate';
$lang['invoice_tax_total_price'] = 'Ammount paid';
$lang['invoice_tax_price']       = 'Tax ammount';
$lang['invoice_tax_price_sum']   = 'Total tax';

$lang['invoice_payed']         = 'Payed';
$lang['invoice_returned']      = 'Returned';
$lang['invoice_discount_info'] = 'Discounts do not apply for items marked with *.';

$lang['invoice_cashier'] = 'Cashier';

$lang['invoice_footer'] = 'This bar will contain additional info. Currently serves for testing letters: WXYQwxyq';
$lang['invoice_thanks'] = 'THANKS FOR BUYING';
$lang['invoice_url']    = '----www.centro.com----'
?>
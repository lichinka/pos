<?php
$lang['config_company_page_title'] = 'Company data';
$lang['config_company_info'] = 'Company\'s data';
$lang['config_company_name'] = 'Company Name';
$lang['config_company_address'] = 'Company Address';
$lang['config_company_identification'] = 'Tax ID';

$lang['config_store_edit_stores'] = 'Edit stores';
$lang['config_store_add'] = 'Add Store';
$lang['config_store_page_title'] = 'Stores';
$lang['config_store_name'] = 'Store\'s name';
$lang['config_store_address'] = 'Store\'s adress';
$lang['config_store_telephone'] = 'Store\'s phone';
$lang['config_store_delete'] = 'Are you sure you want to delete the selected stores?';
$lang['config_store_delete_none_selected'] = 'No stores were marked for deletion.';

$lang['config_store_info'] = 'Store\'s data';
$lang['config_store_edit_page_title'] = 'Edit store';

$lang['config_terminal_edit_terminals'] = 'Edit terminals';
$lang['config_terminal_add'] = 'Add Terminal';
$lang['config_terminal_page_title'] = 'Terminals';
$lang['config_terminal_name'] = 'Serial number';
$lang['config_terminal_delete'] = 'Are you sure you want to delete the selected terminals?';
$lang['config_terminal_delete_none_selected'] = 'No terminals were marked for deletion.';

$lang['config_terminal_info'] = 'Terminal\'s data';
$lang['config_terminal_edit_page_title'] = 'Edit terminal';


$lang['config_website']='Website';
$lang['config_fax']='Fax';
$lang['config_default_tax_rate']='Default Tax Rate %';
$lang['config_company_required']='Company name is a required field';
$lang['config_address_required']='Company address is a required field';
$lang['config_telephone_required']='Company phone is a required field';
$lang['config_default_tax_rate_required']='The default tax rate is a required field';
$lang['config_default_tax_rate_number']='The default tax rate must be a number';
$lang['config_company_website_url']='Company website is not a valid URL (http://...)';
$lang['config_saved_successfully']='Configuration saved successfully';
$lang['config_saved_unsuccessfully']='Configuration saved unsuccessfully';
$lang['config_return_policy_required']='Return policy is a required field';
?>
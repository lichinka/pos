<?php
/**
 * Override the default TCPDF config file 
 */
if(!defined('K_TCPDF_EXTERNAL_CONFIG'))
{
    define('K_TCPDF_EXTERNAL_CONFIG', TRUE);
}

# include TCPDF
require      (APPPATH . 'config/tcpdf' . EXT);
require_once ($tcpdf['base_directory'] . '/tcpdf.php');



/************************************************************
 * TCPDF - CodeIgniter Integration
 * Library file
 * ----------------------------------------------------------
 * @author Jonathon Hill http://jonathonhill.net
 * @version 1.0
 * @package tcpdf_ci
 ***********************************************************/
class pdf extends TCPDF
{
    /**
     * TCPDF system constants that map to settings in our config file
     *
     * @var array
     * @access private
     */
    private $cfg_constant_map = array (
		'K_PATH_MAIN'	=> 'base_directory',
		'K_PATH_URL'	=> 'base_url',
		'K_PATH_FONTS'	=> 'fonts_directory',
		'K_PATH_CACHE'	=> 'cache_directory',
		'K_PATH_IMAGES'	=> 'image_directory',
		'K_BLANK_IMAGE' => 'blank_image',
		'K_SMALL_RATIO'	=> 'small_font_ratio',
    );

    /**
     * Settings from our APPPATH/config/tcpdf.php file
     *
     * @var array
     * @access private
     */
    private $_config = array ( );

    /**
     * This is the static widht of the bill (in mm).
     *
     * @var integer
     * @access private
     */
    private $_static_width = 80;

    /**
     * This is the length of an empty bill (in mm).
     *
     * @var integer
     * @access private
     */
    private $_static_empty_size = 125;

    /**
     * This is the size of a single item row (in mm).
     *
     * @var integer
     * @access private
     */
    private $_item_row_size = 10;

    /**
     * This is the number of charactes that a single row can contain.
     * The calculated value was 13, but is set to 12, because a row 
     * can have multiple large characters.
     *
     * @var integer
     * @access private
     */
    private $_item_line_break_index = 12;

    
    /**
     * Returns the size of the items section of the bill
     * 
     * @param $items is an array of instances of the Item class
     */
    private function _get_items_size ($items)
    {
        $length = count ($items);

        foreach ($items as $item)
        {
            $length += ((int)(strlen ($item->name) / $this->_item_line_break_index)) * $this->_item_row_size;
        }

        return $length;
    }



    /**
     * Creates the header of the bill. This is not is not equal to 
     * the PDF header object.
     * 
     * @param $sale: an instance of the Sale model class
     */
    private function _write_header ($sale)
    {
        $terminal = $sale->get_parent_terminal ( );
        $store    = $terminal->get_parent_store ( );
        $company  = $store->get_parent_company ( );
        
        $CI =& get_instance ( );
        
        $this->_write_line ($company->name);
        $this->_write_line ($company->address);
        $this->_write_line ($store->name);
        $this->_write_line ($store->address);
        $this->_write_text ($CI->lang->line ('invoice_phone') . ':' . $store->telephone, "L", false);
        $this->_write_text ($company->identification, "R", true);
        $this->_write_delimiter ( );
    }


    /**
     * Writes the metada of the bill (time ,date, registry, ...)
     * 
     * @param $sale: is an instance of the Sale model
     */
    private function _write_bill_metadata ($sale)
    {
        $terminal = $sale->get_parent_terminal ( );
        
        $CI =& get_instance ( );
        $CI->load->helper ('date');
        
        // we need to calculate the correct cell width
        $cell_width = $this->_get_effective_width ( ) / 2;

        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_time') . ': ' . strftime ($CI->lang->line ('invoice_time_format'), human_to_unix ($sale->time)) . "       " . $CI->lang->line ('invoice_date') . ": ", 0, 'J', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, strftime ($CI->lang->line ('invoice_date_format'), human_to_unix ($sale->time)), 0, 'R', 0, 1, '', '', true);

        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_sale_metadata') . ":", 0, 'J', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, $terminal->name . " - " . $sale->id,             0, 'J', 0, 1, '', '', true);
    }

    /**
     * Writes the data about each item.-
     * 
     * @param $sale: an instance of the Sale model class
     */
    private function _write_items_data ($sale)
    {
        $CI =& get_instance ( );
        $sale_details = $CI->sale_detail->get_by_sale ($sale->id);
        
        //calculate the cell width
        $cell_width = $this->_get_effective_width ( ) / 3;

        // write headers

        // this is a cheap workaround, that displays the entry as the top element in the right column
        $this->_write_text ($CI->lang->line ('invoice_price_ammount'), "R", true);

        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_item_name'), 0, 'L', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, $CI->lang->line ('items_quantity'),    0, 'C', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_price'),     0, 'R', 0, 1, '', '', true);

        //write a delimiter and loop through the items
        $this->_write_delimiter ( );


        foreach ($sale_details as $sale_detail)
        {            
            // this formula is empiraclly derived
            // I do not know (yet) why 3.5, but it seems to work regardless of the number of line breaks
            $cell_heigth = max ($this->getNumLines ($sale_detail['detail']->get_parent_item ( )->name, $cell_width), $this->getNumLines ($sale_detail['detail']->get_real_value ('quantity'), $cell_width), $this->getNumLines ($sale_detail['detail']->get_real_value ('price_unit'), $cell_width));
            if ($cell_heigth == 1)
            {
                $cell_heigth = 0;
            }
            else
            {
                $cell_heigth *= 3.5;
            }
            
            
             
            // we must add the tax to the total price of an item
            $actual_price = $this->_calculate_item_price ($sale_detail);
            
            $this->MultiCell ($cell_width, $cell_heigth, $sale_detail['detail']->get_parent_item ( )->name,   0, 'L', 0, 0, '', '', true);
            $this->MultiCell ($cell_width, $cell_heigth, $sale_detail['detail']->get_real_value ('quantity'), 0, 'C', 0, 0, '', '', true);
            $this->MultiCell ($cell_width, $cell_heigth, $this->_format_numeric_output ($actual_price),       0, 'R', 0, 1, '', '', true);
        }

        $this->_write_delimiter ( );
    }

    /**
     * Writes the data about payment.
     * 
     * @param $sale: an instance of the Sale model class
     */
    private function _write_payment_data ($sale)
    {
        $CI =& get_instance ( );
        $sale_details = $CI->sale_detail->get_by_sale ($sale->id);
        
        // SIT to € conversion
        $conversion_rate = 239.64;

        //calculate the total price, including taxes
        $sum = 0;
        foreach ($sale_details as $sale_detail)
        {
            $sum += $sale_detail['detail']->quantity / 100.0 * $this->_calculate_item_price ($sale_detail);
        }


        //calculate the cell width
        $cell_width = $this->_get_effective_width ( ) / 2;

        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_sum'),      0, 'J', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, $this->_format_numeric_output ($sum), 0, 'R', 0, 1, '', '', true);

        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_total_price'), 0, 'J', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, $this->_format_numeric_output ($sum),    0, 'R', 0, 1, '', '', true);

        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_secondary_currency'),          0, 'R', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, $this->_format_numeric_output ($sum * $conversion_rate), 0, 'R', 0, 1, '', '', true);

        $this->_write_line ($CI->lang->line ('invoice_secondary_currency_conversion'));
        $this->Ln (0.8);
    }

    /**
     * Writes the data about taxes.
     * 
     * @param $sale: an instance of the Sale model class
     */
    private function _write_tax_data ($sale)
    {
        $CI =& get_instance ( );
        $sale_details = $CI->sale_detail->get_by_sale ($sale->id);

        $tax_data = $this->_calculate_tax_data ($sale_details);

        // calculate the total tax
        $sum = 0;
        foreach ($tax_data as $tax)
        {
            $sum += $tax[2];
        }

        $this->_write_line ($CI->lang->line ('invoice_tax_rate_price'));

        $cell_width = $this->_get_effective_width ( ) / 3;

        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_tax_rate'),        0, 'L', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_tax_total_price'), 0, 'C', 0, 0, '', '', true);
        $this->MultiCell ($cell_width, 0, $CI->lang->line ('invoice_tax_price'),       0, 'C', 0, 1, '', '', true);

        foreach ($tax_data as $tax)
        {
            $this->MultiCell ($cell_width, 0, $tax[0],                                 0, 'C', 0, 0, '', '', true);
            $this->MultiCell ($cell_width, 0, $this->_format_numeric_output ($tax[1]), 0, 'C', 0, 0, '', '', true);
            $this->MultiCell ($cell_width, 0, $this->_format_numeric_output ($tax[2]), 0, 'C', 0, 1, '', '', true);
        }


        $this->MultiCell (2* $cell_width, 0, $CI->lang->line ('invoice_tax_price_sum') . ":", 0, 'C', 0, 0, '', '', true);
        $this->MultiCell ($cell_width,    0, $this->_format_numeric_output ($sum),            0, 'C', 0, 1, '', '', true);
    }

    /**
     * Writes the data about the transaction.
     * 
     * @param $sale: an instance of the Sale model class
     */
    private function _write_transaction_data ($sale)
    {
        //
        // TODO: better integration
        //
        $CI =& get_instance ( );
        $sale_payment = $CI->sale_payment->get_by_sale ($sale->id);
        $sale_payment = $sale_payment[0];
        $payment = $sale_payment->get_parent_payment ( );
        
        $this->_write_line ("-- " . $CI->lang->line ('invoice_payed') . ": --");

        $this->_write_text ($payment->name,                            "L", false);
        $this->_write_text ($sale_payment->get_real_value ('amount'),  "R", true);

        $this->_write_line ("-- " . $CI->lang->line ('invoice_returned') . ": --");

        $this->Ln ( );
        $this->Ln ( );
        // $this->_write_text ("GOTOVINA", "L", false);
        // $this->_write_text ("???",      "R", true);

        $this->_write_line ($CI->lang->line ('invoice_discount_info'));
    }

    /**
     * Writes who made the sale.
     * 
     * @param $sale: an instance of the Sale class
     */
    private function _write_cashier_data ($sale)
    {
        $CI =& get_instance ( );
        $employee = $sale->get_parent_employee ( );
        
        $this->Ln ( );
        $this->_write_line ($CI->lang->line ('invoice_cashier') . ": " . $employee->last_name . " " . $employee->first_name);
        $this->Ln ( );
    }

    /**
     * Writes the static text at the bottom of the bill.
     */
    private function _write_end_text ( )
    {
        $CI =& get_instance ( );
        
        $this->_write_text ($CI->lang->line ('invoice_footer'), "C", true);
        $this->_write_text ($CI->lang->line ('invoice_thanks'), "C", true);
        $this->_write_text ($CI->lang->line ('invoice_url'),    "C", true);
        $this->_write_delimiter ( );
    }


    /**
     * Draws a single vertical line at the current position.
     */
    private function _write_delimiter ( )
    {
        $margins = $this->getMargins ( );

        $this->Ln ( );
        $this->Line ($margins['left'], $this->GetY ( ), $this->getPageWidth ( ) - $margins['right'], $this->GetY ( ), array ("dash" => "2 1"));
        $this->Ln ( );

    }

    /**
     * Writes the text and inserts a line break at the end of it.
     * @param string $text is the text to be written
     */
    private function _write_line ($text)
    {
        $this->Write (0, $text, '', 0, '', true, 0, false, false, 0);
    }

    /**
     * This a utility function, that wraps the TCPDF's write function.
     *
     * @param string $text is the text to be written
     * @param string $align can have 4 values (L,C,R,J)
     * @param boolean $line_break, if true: a new line will start at the end of the text, if false: the cursor will remain at the end position.
     */
    private function _write_text ($text, $align, $line_break)
    {
        $this->Write (0, $text, '', 0, $align, $line_break, 0, false, false, 0);
    }

    /**
     * Returns the writable width of the current page.
     */
    private function _get_effective_width ( )
    {
        $margins = $this->getMargins ( );
        return $this->getPageWidth ( ) - $margins['left'] - $margins['right'];
    }

    /**
     * Calculates the tax data from the items.
     * 
     * @param $sale_details: an array of Sale_detail instances
     * @return an indexed array, that represents the tax data. The outer array
     * wraps the tax rates an the inner arrays are formatted as:
     *  index 0: is the tax rate;
     *  index 1: is the total price at the tax rate;
     *  index 2: is the total price of the taxes only
     */
    private function _calculate_tax_data ($sale_details)
    {
        $result = array ( );

        $taxes = array ( );
        $CI =& get_instance ( );
        foreach ($sale_details as $sale_detail)
        {
            $taxes = array_merge ($taxes, $sale_detail['detail_taxes']);
        }
        
        // first fetch all the different tax rates
        $rates = array ( );
        foreach ($taxes as $tax)
        {
            if (!in_array ($tax->get_real_value ('percent'), $rates, true))
            {
                array_push ($rates, $tax->get_real_value ('percent'));
            }
        }


        // for each tax rate, we calculate the total values
        foreach ($rates as $rate)
        {
            $total_cost = 0;
            $total_tax = 0;
            foreach ($sale_details as $sale_detail)
            {
                foreach ($sale_detail['detail_taxes'] as $tax)
                {
                    if ($rate == $tax->get_real_value ('percent'))
                    {
                        $total_cost += $sale_detail['detail']->quantity / 100.0 * ($sale_detail['detail']->price_unit / 100.0 + $sale_detail['detail']->price_unit / 100.0 * $tax->percent / 100.0 / 100.0);
                        $total_tax  += $sale_detail['detail']->quantity / 100.0 * ($sale_detail['detail']->price_unit / 100.0 * $tax->percent / 100.0 / 100.0);
                    }   
                }
            }
            
            array_push ($result, array ($rate . '%', 
                                        $total_cost, 
                                        $total_tax));
        }

        return $result;
    }
    
    /**
     * Calculates the total price of an item.
     * 
     * @param $sale_detail: is the Sale_detail of the item
     */
    private function _calculate_item_price ($sale_detail)
    {   
        $sale_detail_taxes = $sale_detail['detail_taxes'];
        $actual_price = $sale_detail['detail']->price_unit / 100.0;
        foreach ($sale_detail_taxes as $sale_detail_tax)
        {
            $actual_price += $sale_detail['detail']->price_unit / 100.0 * $sale_detail_tax->percent / 100.0 / 100.0;
        }
        
        return $actual_price;
    }
    
    /**
     * Formats the numeric value, so that it can be properly outputed.
     * 
     * @param $value: is the numeric value
     * @return: a formatted number
     */
    private function _format_numeric_output ($value)
    {
        return money_format ('%!.2n', $value);   
    }
    
    /**
     * Initialize and configure TCPDF with the settings in our config file
     *
     */
    function __construct()
    {

        # load the config file
        require(APPPATH.'config/tcpdf'.EXT);
        $this->_config = $tcpdf;
        unset($tcpdf);



        # set the TCPDF system constants
        foreach($this->cfg_constant_map as $const => $cfgkey)
        {
            if(!defined($const))
            {
                define($const, $this->_config[$cfgkey]);
                //echo sprintf("Defining: %s = %s\n<br />", $const, $this->_config[$cfgkey]);
            }
        }

        # initialize TCPDF
        parent::__construct(
        $this->_config['page_orientation'],
        $this->_config['page_unit'],
        $this->_config['page_format'],
        $this->_config['unicode'],
        $this->_config['encoding'],
        $this->_config['enable_disk_cache']
        );


        # language settings
        if(is_file($this->_config['language_file']))
        {
            include($this->_config['language_file']);
            $this->setLanguageArray($l);
            unset($l);
        }

        # margin settings
        $this->SetMargins($this->_config['margin_left'], $this->_config['margin_top'], $this->_config['margin_right']);

        # header settings
        $this->print_header = $this->_config['header_on'];
        #$this->print_header = FALSE;
        $this->setHeaderFont(array($this->_config['header_font'], '', $this->_config['header_font_size']));
        $this->setHeaderMargin($this->_config['header_margin']);
        $this->SetHeaderData(
        $this->_config['header_logo'],
        $this->_config['header_logo_width'],
        $this->_config['header_title'],
        $this->_config['header_string']
        );

        # footer settings
        $this->print_footer = $this->_config['footer_on'];
        $this->setFooterFont(array($this->_config['footer_font'], '', $this->_config['footer_font_size']));
        $this->setFooterMargin($this->_config['footer_margin']);

        # page break
        $this->SetAutoPageBreak($this->_config['page_break_auto'], $this->_config['footer_margin']);

        # cell settings
        $this->cMargin = $this->_config['cell_padding'];
        $this->setCellHeightRatio($this->_config['cell_height_ratio']);

        # document properties
        $this->author = $this->_config['author'];
        $this->creator = $this->_config['creator'];

        # font settings
        $this->AddFont($this->_config['page_font'], '', strtolower($this->_config['page_font']).'php', $this->_config['embed_subset']);
        $this->SetFont($this->_config['page_font'], '', $this->_config['page_font_size']);

        # image settings
        $this->imgscale = $this->_config['image_scale'];
    }

    
    /**
     * Creates the bill.
     * 
     * @param $sale: an instance of the Sale model class
     * @param $terminal: an instance of the Terminal model class
     */
    public function create_bill ($sale)
    {        
        $CI =& get_instance ( );
        $CI->load->model ('sales/sale_detail');
        $CI->load->model ('sales/sale_detail_tax');
        $CI->load->model ('sales/sale_payment');
        
        
        $items = array ( );
        foreach ($sale->get_details ( ) as $sale_detail)
        {
            array_push ($items, $sale_detail['detail']->get_parent_item ( ));
        }
        
        // set size
        $this->setPageFormat (array ($this->_static_width, $this->_static_empty_size + $this->_get_items_size ($items)));
         
        // set document information
        $this->SetSubject  ($CI->lang->line ('invoice_title'));
        $this->SetKeywords ($CI->lang->line ('invoice_keyword'));
         
        // add a page
        $this->AddPage();


        $this->_write_header ($sale);
        $this->_write_bill_metadata ($sale);
        $this->_write_items_data ($sale);
        $this->_write_payment_data ($sale);
        $this->_write_tax_data ($sale);
        $this->_write_transaction_data ($sale); // this function is implemented only as GUI
        $this->_write_cashier_data ($sale);
        $this->_write_end_text ( ); // this function is currently hardcoded
    }
}
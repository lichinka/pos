<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


/**
 * Keeps a stack of visited addresses by just calling 'push' and 'pop'
 * when needed. By using this library, you may alter the standard browser
 * flow of history (i.e. BACK button behaviour).
 * 
 * To add the current page to the stack, call:
 *  
 *  $this->navigation_stack->push ( );
 *  
 *  or
 *  
 * 	$this->navigation_stack->push (arbitrary_address);
 *  
 * Going back is simple also:
 * 
 * 	$this->navigation_stack->pop_and_redirect ( );
 * 
 * or
 * 
 * 	$this->whence->pop_and_redirect (number_of_stack_element_to_pop);
 * 
 * You can also arbitrarily remove addresses from the stack:
 * 
 * 	$this->navigation_stack->pop (number_of_addresses_to_pop);
 * 
 * 
 * 
 * 
 * @author luka
 *
 */
class Navigation_stack
{
	//
	// We will remember this many navigation nodes
	//
    protected $max_stack_depth = 10;
    
    //
    // The home page of this application
    //
    protected $homepage 	   = '';
    
    //
    // A reference to the CodeIgniter's engine
    //
    protected $_ci 			   = null;
 

        
    /**
     * Checks if a change in the browser history is a consequence of an AJAX request.-
     * 
     * @return	TRUE if so.
     */
    private function _is_ajax ( ) 
    {
        return (isset ($_SERVER['HTTP_X_REQUESTED_WITH']) && 
        		$_SERVER['HTTP_X_REQUESTED_WITH'] == "XMLHttpRequest");
    }
    
    
    /**
     * Constuctor
     * 
     * @param $config	The configuration element (saved in 
     * 					the 'config' directory of the application).
     */
    public function __construct ($config)
    {
        $this->_ci =& get_instance ( );
        
        //
        // There will always be exactly max_stack_depth elements in the array
        //
        $this->max_stack_depth = $config['max_stack_depth'];
        $this->homepage 	   = $config['homepage'];
        
        //
        // We will save the stack as a session element
        //
        if(!isset ($this->_ci->session->userdata['navigation_stack']))
        {
            $this->clear_stack ( );
        }
    }
    
    
    /**
     * Constructor
     * 
     * @param $config	The configuration element (saved in 
     * 					the 'config' directory of the application).
     */
    public function Navigation_stack ($config)
    {
        $this->__construct ($config);
    }
    
    
    /**
     * Prepares the stack to start working.-
     */
    public function clear_stack ( )
    {
        $root_element = strtolower ($this->homepage);
        
        $navigation_array = array ( );
        
        for ($i = 0 ; $i < $this->max_stack_depth ; $i ++)
        {
            $navigation_array[] = $root_element;
        }
        
        //
        // Save the created stack to this user's session data
        //
        $this->_ci->session->set_userdata (array ("navigation_stack" => $navigation_array));
    }
 
    
    /**
     * Pushes an arbitrary address into the navigation stack.-
     * 
     * @param $uri The address to push. It defaults to the current address.-
     */
    public function push ($uri = NULL)
    {
        if ($uri == NULL)
        {
            $uri = strtolower (substr (stristr ($_SERVER['REQUEST_URI'], 'index.php?/'), 11));
            
            if ($uri == '')
            {
                $uri = strtolower (substr (stristr ($_SERVER['REQUEST_URI'], 'index.php/'), 10));
                
                if ($uri == '')
                {
                    $uri = $this->homepage;
                }
            }
        }
        
        //
        // Don't save this URI if it is the result of an AJAX request or a page reload
        //
        if ($this->_is_ajax ( ) || 
        	$uri == $this->_ci->session->userdata['navigation_stack'][$this->max_stack_depth - 1])
        {
            return;
        }
        else 
        {
        	//
        	// Make room for the new URI
        	//            
	        $navigation_stack = $this->_ci->session->userdata['navigation_stack'];
	        array_shift ($navigation_stack);
	        array_push  ($navigation_stack, $uri);
	        
	        //
	        // Save the new stack to the user's session data
	        //
	        $this->_ci->session->set_userdata ('navigation_stack', $navigation_stack);
        }
    }
    
    
    /**
     * Pops the top address off this user's navigation stack.- 
     * 
     * @param $n	The number of element to pop off the stack. Defaults to 1 element.-
     * 
     * @return 		The last element poped off the stack.-
     */
    public function pop ($n = 1)
    {
        //
        // Be sure the current session didn't time out ... 
        //
    	if (!isset ($this->_ci->session->userdata['navigation_stack']))
        {
        	//
        	// Session timed out ... reset the stack
        	//
            $this->clear_stack ( );
        }
        
        //
        // Pick up some data before rearranging the stack
        //
        $root_node 		  = $this->homepage;
        $navigation_stack = $this->_ci->session->userdata['navigation_stack'];
        $poped_address	  = $root_node;

        for ($j = 0; $j < $n; $j ++)
        {
        	//
      	    // Shift the navigation array
            //
            $poped_address = array_pop ($navigation_stack);
            array_unshift ($navigation_stack, $root_node);
        }
        
        //
        // Save the new navigation stack in the user's session
        //
        $this->_ci->session->set_userdata ('navigation_stack', $navigation_stack);
        
        //
        // Return the poped address
        //
        return $poped_address;
    }

    
    /**
     * Returns the top element of the navigation stack without popping it.
     *  
     * @return The value of the top element of the navigation stack.-
     */
    public function peek ( )
    {
    	$navigation_stack = $this->_ci->session->userdata['navigation_stack'];
    	
    	return ($navigation_stack[count ($navigation_stack) - 1]);
    }
    
    
    /**
     * Returns the content of the current user's navigation stack.-
     * 
     * @return The content of the current user's navigation stack.-
     */
    public function dump ( )
    {
        return (print_r ($this->_ci->session->userdata['navigation_stack']));
    }
 } 

?>

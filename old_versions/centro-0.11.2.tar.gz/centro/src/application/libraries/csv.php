<?php
require_once APPPATH . '3rdparty/Text/Diff.php';
require_once APPPATH . '3rdparty/Text/Diff/Renderer.php';
require_once APPPATH . '3rdparty/Text/Diff/Renderer/inline.php';

class CSV
{
    /**
     * Creates a temporary file and returns its handle.
     *
     * @param $input is a two-dimensional array of Strings. The first dimension are rows, the
     * 		  second dimension are columns.
     *
     * @return a still open file handle
     */
    private function create_file ($input)
    {
        $file = tmpfile ( );
        foreach ($input as $row)
        {
            fputcsv($file, $row);
        }

        fseek ($file, 0);

        return $file;
    }

    /**
     * Constructor
     */
    function __construct ( )
    {
        $CI =& get_instance ( );

        //
        // file data
        //
        $config['upload_path'] = APPPATH . 'uploads/';
        $config['allowed_types'] = 'csv';
        $config['file_name'] = 'temp';

        $CI->load->library ('upload', $config);
    }

    /**
     * Returns the CSV file, as a two-dimensional array of Strings.
     *
     * @param $fieldname is the name of the form upload filed, that contains the file
     *
     * @return a two-dimensional array of String. The first dimension are rows, the second
     * 		   dimension are columns.
     */
    function read_file ($fieldname)
    {
        //
        // upload the file
        //
        $CI =& get_instance ( );
        $CI->upload->do_upload ($fieldname);

        //
        // load the array
        //
        $data = array ( );
        $file_path = APPPATH . 'uploads/temp.csv';
        $i = 0;

        while (file_exists ($file_path) === FALSE && $i < 100)
        {
            //
            // this whole loop is needed to compensate a CI bug
            //
            $file_path = $file_path . '.csv';
            $i++;
        }
        $file = fopen ($file_path, 'r');

        if ($file)
        {
            $row = fgetcsv ($file);
            while (! ($row === FALSE))
            {
                array_push ($data, $row);
                $row = fgetcsv ($file);
            }
        }
        fclose ($file);

        //
        // delete the file
        //
        unlink ($file_path);

        return $data;
    }

    /**
     * Creates the CSV file, from the two-dimensional array.
     *
     * @param $input is a two-dimensional array of Strings. The first dimension are rows, the
     * 		  second dimension are columns.
     * @return a file object, created with the fopen ( ) method
     */
    function write_to_file ($input)
    {
        $data = '';

        $file = $this->create_file ($input);

        while (!feof($file))
        {
            $data = $data . fgetc($file);
        }
        fclose ($file);

        return $data;
    }

    /**
     * Compares two csv matrixes.
     *
     * @param $old_state is the old data matrix.
     * @param $new_state is the new data matrix.
     * 
     * @return, a string of differences, if it is empty, the files were the same.
     */
    function diff ($old_state, $new_state)
    {

        $old_file = $this->create_file ($old_state);
        $old_array = array ( );
        while (!feof($old_file))
        {
            array_push ($old_array, fgets ($old_file));
        }
        fclose ($old_file);


        $new_file = $this->create_file ($new_state);
        $new_array = array ( );
        while (!feof ($new_file))
        {
            array_push ($new_array, fgets ($new_file));
        }
        fclose ($new_file);



        // perform diff, print output
        $diff = new Text_Diff ($old_array, $new_array);
        $renderer = new Text_Diff_Renderer_inline ( );
        return $renderer->render ($diff);
    }
}
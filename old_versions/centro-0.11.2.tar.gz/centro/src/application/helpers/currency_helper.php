<?php
function to_currency($number)
{
    //FIXME: currently obsolete, but has potential
	return $number;
}
?>
<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| NAVIGATION STACK library
| -------------------------------------------------------------------
| This is the configuration file for the 'navigation_stack' library.
| It needs the 'session' library loaded as a dependency.- 
*/

//
// The maximum number of navigation nodes to remember.
//
$config['max_stack_depth'] = 10;

//
// The home page of this application
//
$config['homepage'] = 'login';
?>  

<div id="title_bar">
 <div id="page_title" class="float_left">{page_title}</div>
</div>

{form_open}
 <div id="fields_wrapper">
 <fieldset id="basic_info">
  <legend>{export_notes}</legend>
  
  <ul style="text-align:left;">
  {notes}
   <li>{note}</li>
  {/notes}
  </ul>
  </fieldset>
 
 <fieldset id="objects">
  <legend>{export_object}</legend>
  
  {objects}
   <div class="field_row clearfix">
    {label}
    <div class='form_field'>{input}</div>
   </div>
  {/objects}
  </fieldset> 
  
  <fieldset id="mode">
  <legend>{export_type}</legend>
  
  {modes}
   <div class="field_row clearfix">
    {label}
    <div class='form_field'>{input}</div>
   </div>
  {/modes}
  </fieldset>
  
  <fieldset id="languages">
  <legend>{export_languages}</legend>
  
  {languages}
   <div class="field_row clearfix">
    {label}
    <div class='form_field'>{input}</div>
   </div>
  {/languages}
 </fieldset>
 </div>
{form_close}

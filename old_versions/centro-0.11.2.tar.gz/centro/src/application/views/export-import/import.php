<div id="title_bar">
 <div id="page_title" class="float_left">{page_title}</div>
</div>

{form_open}
 <div id="fields_wrapper">
 <fieldset id="basic_info">
  <legend>{import_notes}</legend>
  
  <ul style="text-align:left;">
  {notes}
   <li>{note}</li>
  {/notes}
  </ul>
  </fieldset>
 
 <fieldset id="objects">
  <legend>{import_object}</legend>
  
  {objects}
   <div class="field_row clearfix">
    {label}
    <div class='form_field'>{input}</div>
   </div>
  {/objects}
  </fieldset> 
  
  <fieldset id="mode">
  <legend>{import_mode}</legend>
  
  {modes}
   <div class="field_row clearfix">
    {label}
    <div class='form_field'>{input}</div>
   </div>
  {/modes}
  </fieldset>
  
  <fieldset id="languages">
  <legend>{import_files}</legend>
  
  {upload_slots}
   <div class="field_row clearfix">
    {label}
    <div class='form_field'>{input}</div>
   </div>
  {/upload_slots}
 </fieldset>
 </div>
{form_close}

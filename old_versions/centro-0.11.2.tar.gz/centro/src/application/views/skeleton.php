<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<?php $this->load->view ("partial/header"); ?>

<body>
	<!-- MAIN CONTAINER -->
	<div id="container">

		<!-- CONTENT PANEL -->
		<div id="content-panel">
		    <h1><?php echo $module_name ?></h1>
		    
		    <br />

			<?php
				//
				// This HTML is dinamically generated in the controller
				// by using the built-in template engine.
				//
				echo $content;
			?>			
		</div>

		<!-- MODULE PANEL -->
		<?php $this->load->view ("partial/modules"); ?>

		<!-- STATUS PANEL and PAGE FOOTER -->
		<?php $this->load->view ("partial/footer"); ?>
	</div>
	
	<!-- PROGRAM NAME AND VERSION -->
	<?php 
	echo $this->lang->line ('common_you_are_using_phppos') . ' ' . 
		 $this->config->item ('version'); 
	?>	
</body>

</html>

<div id="back_button">{back_button}</div>

<!-- DO NOT DISPLAY THE EDIT BUTTON -->
<div id="edit_button" style="opacity: 0;"></div>

<!-- DO NOT DISPLAY THE ADD BUTTON -->
<div id="new_button" style="opacity: 0;"><a></a></div>

<!-- DO NOT DISPLAY THE SUBMIT BUTTON -->
<div id="submit_button" style="opacity: 0;"></div>


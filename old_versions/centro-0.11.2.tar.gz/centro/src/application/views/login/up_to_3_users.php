<!-- TOP ICON ROW --> 
<div id='top_icon_row'>
    <!-- EMPTY SQUARE -->
    <div id='icon_square'>
    </div>
    <?php
        //
        // Display the users' names and icons
        //
        foreach ($employees as $employee)
        {
        	echo "<div id='icon_square'>";
        	
        	//
        	// The username with a callback function for whenever click-on-icon occurs
        	//
        	echo "<a href='#' id='user_" . $employee->id . "' ";        	
            echo "onclick=\"return user_selected (event, '" . $employee->username . "', document.forms[0]);\">";
        	
        	//
        	// The user's icon
        	//
        	echo "<img ";
        	
        	//
        	// FIXME: Add the possibility to select the icon
        	//
        	if (($employee->id % 2) == 0)
        	{
        	    echo "src='images/login/style_green_girl_medium.png'/>";
        	}
        	else
        	{
        		echo "src='images/login/style_green_man_medium.png'/>";
        	}
        	
            //
            // The user's name
            //
            echo $employee->first_name . ' ' . $employee->last_name;
        	echo "</a>";
        	echo "</div>";
        }
    ?>    
    <!-- EMPTY SQUARE -->
    <div id='icon_square'>
    </div>    
</div>

<!-- CENTER ROW WITHOUT ICONS AND WITH THE PASS PANEL -->
<div id='center_row'>
    <div id='icon_column_left'>
    </div>
               
    <?php
        //
        // Load the password panel
        // 
        $this->load->view ("login/passwd_panel");
    ?>
           
    <div id='icon_column_right'>
    </div>
</div>

<!-- EMPTY BOTTOM ICON ROW -->
<div id='bottom_icon_row'>
</div>

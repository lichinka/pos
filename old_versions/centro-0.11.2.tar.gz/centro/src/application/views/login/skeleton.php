<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<?php $this->load->view ("login/header"); ?>

<body>
	<div id="container">
	   <?php
	       //
	       // Find out which view we have to load, 
	       // based on the number of users.
	       //
	       if (count ($employees) < 4)
	       {
	       	   $data['employees'] = $employees;
	           $this->load->view ('login/up_to_3_users', $data);
	       }
	       else 
	       {
	       	   //
	       	   // FIXME: Implement for up to 5, 8 and 10 employees
	       	   //
	       }
	   ?>

        <!-- THE PAGE FOOTER -->
        <?php 
            $this->load->view ("login/footer"); 
        ?>
	</div>
</body>
</html>
<!-- PAGE FOOTER -->
<div id="page_footer">
    <!-- PROGRAM NAME AND VERSION -->
    <?php 
    echo $this->lang->line ('common_you_are_using_phppos') . 
         '   ' . $this->config->item ('version');
    ?>  
</div>

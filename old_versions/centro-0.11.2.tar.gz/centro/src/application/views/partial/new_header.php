<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<base href="<?php echo base_url();?>" />
	<title><?php echo $this->config->item('company').' -- '.$this->lang->line('common_powered_by').' CenTRO ' ?></title>
	<link rel="stylesheet" rev="stylesheet" href="<?php echo base_url();?>css/refresh.css" />
	<link rel="stylesheet" rev="stylesheet" href="<?php echo base_url();?>css/phppos_print.css"  media="print"/>
	<script src="<?php echo base_url();?>js/jquery-1.2.6.min.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/jquery.color.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/jquery.metadata.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/jquery.form.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/jquery.tablesorter.min.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/jquery.ajax_queue.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/jquery.bgiframe.min.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/jquery.autocomplete.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/jquery.validate.min.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/thickbox.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/common.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
	<script src="<?php echo base_url();?>js/manage_tables.js" type="text/javascript" language="javascript" charset="UTF-8"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
		<h1>CENTRO</h1>
		<p>
			<?php echo $this->lang->line('common_powered_by').' Linux'; ?> |
		    <?php echo $this->lang->line('common_welcome')." ".$registered_employee->first_name." ".$registered_employee->last_name; ?> |
		    <?php echo date('d. F, Y') ?>
		</p>
		</div>
		
		<div id="menu">
			<ul>
			<li>
				<a href="<?php echo site_url('home');?>"><?php echo $this->lang->line("module_home") ?></a>
			</li>

			<?php
			foreach($registered_employee->get_active_modules ( ) as $module)
			{
			?>
			<li>
				<a href="<?php echo site_url("$module->name");?>"><?php echo $this->lang->line("module_".$module->name) ?></a>
			</li>
			<?php
			}
			?>
			<li>
        		<?php echo anchor("home/logout",$this->lang->line("common_logout")); ?>
			</li>
			
			</ul>
		</div>
	</div>
    <div id="page">
    	<div id="page-bgtop">
    		<div id="page-bgbtm">
    			<div id="content">
    				<div class="post">

            		<div style="clear: both;">&nbsp;</div>
            		</div>	<!-- end post -->
            	</div>	<!-- end content -->
            	
            	
        		<div style="clear: both;">&nbsp;</div>
            	
            </div> <!-- end page-bgbtm -->
        </div> <!--end page-bgtop -->
    </div> <!-- end page -->
</div> <!-- end wrapper -->
<div id="footer-wrapper">
	<div id="footer">
		<!--  <p><?php echo $this->lang->line('common_you_are_using_phppos').' '.$this->config->item('version');?></p>-->
		<p>Copyright (c) 2008 Sitename.com. All rights reserved. Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</p>
	</div>
</div>
</body>
</html>
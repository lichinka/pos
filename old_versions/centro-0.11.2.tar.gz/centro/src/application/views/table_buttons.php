<div id="back_button">{back_button}</div>

<!-- DO NOT DISPLAY THE EDIT BUTTON -->
<div id="edit_button" style="opacity: 0;"><a></a></div>

<div id="new_button">{new_button}</div>

<!-- DO NOT DISPLAY THE SAVE BUTTON -->
<div id="submit_button" style="opacity: 0;"><a></a></div>

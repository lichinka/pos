<div id="title_bar">
 <div id="page_title" class="float_left">{page_title}</div>
</div>

{form_open}
 <div id="fields_wrapper">
 <fieldset id="basic_info">
  <legend>{page_info}</legend>
  <div id="required_fields_message">{fields_required_message}</div> 
  
  {data}
   <div class="field_row clearfix">
    {label}
    <div class='form_field'>{input}</div>
   </div>
  {/data} 
  
 </fieldset>
 </div>
{form_close}

<div id="back_button">{back_button}</div>

<div id="payment_button">{payment_button}</div>

<!-- DO NOT DISPLAY THE ADD BUTTON -->
<div id="new_button" style="opacity: 0;"><a></a></div>

<div id="submit_button">{submit_button}</div>


<div id="title_bar">
	<div id="page_title" class="float_left">{page_title}</div>
</div>

{links}
 <div id="module-button" style="text-align:center;">
  <a href="{link}">{text}</a>
 </div>
{/links}


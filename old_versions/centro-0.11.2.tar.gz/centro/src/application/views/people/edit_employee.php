<div id="title_bar">
 <div id="page_title" class="float_left">{page_title}</div>
</div>

{form_open}
 <div id="fields_wrapper">
 <fieldset id="basic_info">
  <legend>{page_info}</legend>
  <div id="required_fields_message">{fields_required_message}</div> 
  
  {data}
   <div class="field_row clearfix">
    {label}
    <div class='form_field'>{input}</div>
   </div>
  {/data} 
  
 </fieldset>
 
 <fieldset id="login_info">
  <legend>{login_information}</legend>
   <div id="required_fields_message">{fields_required_message}</div> 
  
   {login_data}
    <div class="field_row clearfix">
     {label}
     <div class='form_field'>{input}</div>
    </div>
   {/login_data}
 </fieldset>
 
 <fieldset id="permissions_info">
  <legend>{permission_info}</legend>
   <div>{permission_description}</div> 
  
   <table style="text-align:left;">
	{module_data}
	 <tr>
	  <td>{thick}</td>
	  <td><span>{module_name}:</span></td>
	  <td><span>{module_description}</span></td>
	 </tr>
	{/module_data}
   </table>
   
  <legend>{terminal_description}</legend>
   {terminal_data}
    <div class="field_row clearfix">
     {label}
     <div class='form_field'>{input}</div>
    </div>
   {/terminal_data}
 </fieldset>
 
 </div>
{form_close}

<?php

/**
 * Handles the BACK functionality with help of the navigation stack library.-
 * 
 * @author luka
 */
class Back extends Controller 
{
	/**
	 * Constructor
	 */
	function __construct ( )
	{
		parent::Controller ( );
	}
	
	
	/**
	 * Redirects the user to the correct address based on her/his navigation stack.-
	 */
	function index ( )
	{
		//
		// Discard the top address of the stack (i.e. where we are comming from)
		//
		$this->navigation_stack->pop ( );
		
		//
		// Redirect the user to the address she/he previously visited
		//
		redirect($this->navigation_stack->peek ( ), 'refresh');
	}
}
?>
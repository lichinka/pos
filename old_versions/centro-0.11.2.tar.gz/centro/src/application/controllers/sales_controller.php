<?php
require_once ("secure_area.php");


/**
 * Controller for creating and editing invoices.- 
 *
 * @author luka
 *
 */
class Sales_controller extends Secure_area 
{
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $sales  An array containing all sales to be displayed.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_of_sales_template ($sales)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));

        //
        // The page title
        //
        $ret_value['page_title'] = $this->lang->line ('sales_select_open_invoice');
                                   
        //
        // The table column titles
        //
        $ret_value['column_titles'] = array (array ('title' => $this->lang->line ('sales_date')),
                                             array ('title' => $this->lang->line ('sales_invoice')),
                                             array ('title' => $this->lang->line ('sales_customer')),
                                             //
                                             // Column for the EDIT button
                                             //
                                             array ('title'=>'&nbsp'),
                                             //
                                             // Column for the DELETE button
                                             //
                                             array ('title'=>'&nbsp'));
                                             
        //
        // Display or hide the 'No elements' message?
        //
        if (count ($sales) == 0)
        {
            $ret_value['display_status'] = 'display: inline;';
            $ret_value['empty_table']    = $this->lang->line ('common_nothing_to_display');
        }
        else
        {
            $ret_value['display_status'] = 'display:none;';
            $ret_value['empty_table']    = '';
        }

        //
        // Set the actual detailed data for the whole table
        //
        $ret_value['table_data'] = array ( );
        
        foreach ($sales as $sale)
        {
            $table_row = array ('date'     => $sale->time,
                                'invoice'  => $sale->id,
                                'customer' => $sale->get_parent_customer ( )->first_name . ' ' .
                                              $sale->get_parent_customer ( )->last_name,
            
                                'edit_link' => anchor ($controller_uri . '/view_sale/' . $sale->id . '/', 
                                                       '...',
                                                       array ('title' => $this->lang->line ('common_edit'))),
                                                             
                                'delete_link' => anchor ('#',
                                                         'x', 
                                                         array ('id'    => 'delete',
                                                                'title' => $this->lang->line ('common_delete'))));
                                                                 //
                                                                 // This code connects this anchor with the Delete functionality
                                                                 //
                                                                 //'onClick' => "return delete_table_row (event);")));
            //
            // Save the data of the current detail line
            //
            array_push ($ret_value['table_data'], $table_row);
        }
        
        //
        // Return the dynamic template built
        //
        return $ret_value;
    }
	

    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return             An array ready to be applied over the template page.-
     */
    private function _build_table_of_sales_buttons_template ( )
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));

        //
        // The NEW button
        //
        $ret_value['new_button'] = anchor ($controller_uri . '/add_new_sale/', ' ',
                                           array ('title' => $this->lang->line ('sales_create_invoice')));
        //
        // Return the template just built
        //
        return $ret_value;
    }
    
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $sale   	The sale object that is parent of the $details.- 
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_right_column_content_template ($sale)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));
    	
        //
        // The CUSTOMER button on the right column
        //
        $ret_value['customer_button'] = anchor ($controller_uri . '/search_customer/' . $sale->id . '/', ' ',
                                                array ('title' => $this->lang->line ('sales_customer'),
                                                       //
                                                       // This code connects this anchor with the Search customer functionality
                                                       //
                                                       'onClick' => "return search_element (event, document.getElementById ('search-string'))"));
                                                
        //
        // The SEARCH button on the right column
        //
        $ret_value['item_search_button'] = anchor ($controller_uri . '/search_item/' . $sale->id . '/', ' ',
                                                   array ('title' => $this->lang->line ('sales_search_item'),
                                                          //
                                                          // This code connects this anchor with the Search item functionality
                                                          //
                                                          'onClick' => "return search_element (event, document.getElementById ('search-string'))"));
    	
        //
        // The customer name
        //
        $ret_value['customer_name'] = $sale->get_parent_customer ( )->first_name 
                                      . ' ' .
                                      $sale->get_parent_customer ( )->last_name;

        //
        // Calculate the diffent amount values of this sale
        //
        $ret_value['subtotal'] = $sale->get_subtotal ( );
        $ret_value['taxes']    = $sale->get_taxes    ( );
        $ret_value['total']    = $ret_value['subtotal'] + $ret_value['taxes'];
                                      
        //
        // Change the calculated numbers to the right format
        //
        $ret_value['subtotal'] = money_format ('%!.2n', $ret_value['subtotal']);
        $ret_value['taxes']    = money_format ('%!.2n', $ret_value['taxes']);
        $ret_value['total']    = money_format ('%!.2n', $ret_value['total']);

		//
        // Return the dynamic template built
        //
        return $ret_value;
	}
    
    
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $details  An array containing all detail lines in $sale.-
     * @param $sale   	The sale object that is parent of the $details.- 
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_content_template ($details, $sale)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));

        //
        // The title is the invoice number + the page title
        //
        $ret_value['page_title'] = $this->lang->line ('sales_invoice') . ' #' .
                                   $sale->id;
                                   
        //
        // The table column titles
        //
        $ret_value['column_titles'] = array (array ('title' => $this->lang->line ('sales_item_name')),
                                             array ('title' => $this->lang->line ('sales_quantity')),
                                             array ('title' => $this->lang->line ('sales_price')),
                                             //
                                             // Column for the EDIT button
                                             //
                                             array ('title'=>'&nbsp'),
                                             //
                                             // Column for the DELETE button
                                             //
                                             array ('title'=>'&nbsp'));
                                             
        //
        // Display or hide the 'No elements' message?
        //
        if (count ($details) == 0)
        {
            $ret_value['display_status'] = 'display: inline;';
            $ret_value['empty_table']    = $this->lang->line ('common_nothing_to_display');
        }
        else
        {
            $ret_value['display_status'] = 'display:none;';
            $ret_value['empty_table']    = '';
        }

        //
        // Set the actual detailed data for the whole table
        //
        $ret_value['table_data'] = array ( );
        
        foreach ($details as $line)
        {
            $sale_detail = array ('name'      => $this->item->get_by_id ($line['detail']->item_id)->name,
                                  'quantity'  => $line['detail']->get_real_value ('quantity'),
                                  'price'     => $line['detail']->get_real_value ('price_unit'),
            
                                  'edit_link' => anchor ($controller_uri . '/edit_detail/' . $line['detail']->id . '/', 
                                                         '...',
                                                         array ('title' => $this->lang->line ('common_edit'))),
                                                             
                                  'delete_link' => anchor ($controller_uri . '/delete_detail/' . $line['detail']->id . '/',
                                                           'x', 
                                                           array ('id'    => 'delete',
                                                                  'title' => $this->lang->line ('common_delete'),
                                                                  //
                                                                  // This code connects this anchor with the Delete functionality
                                                                  //
                                                                  'onClick' => "return delete_table_row (event);")));
            //
            // Save the data of the current detail line
            //
            array_push ($ret_value['table_data'], $sale_detail);
        }
        
        //
        // Return the dynamic template built
        //
        return $ret_value;
    }

    
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @param $sale The sale object that is parent of this terminal.-
     *  
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_buttons_template ($sale)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
                                            array ('title' => $this->lang->line ('common_back')));

        //
        // The PAYMENT button
        //
        $ret_value['payment_button'] = anchor ($controller_uri . '/define_payment/' . $sale->id, ' ',
                                               array ('title' => $this->lang->line ('sales_payment')));
                                            
        //
        // The SAVE (or Submit) button
        //
        $ret_value['submit_button'] = anchor ($controller_uri . '/finish_sale/' . $sale->id . '/', ' ',
                                              array ('title' => $this->lang->line ('sales_complete_sale'),
                                              //
                                              // This code connects this anchor with the Finish sale functionality
                                              //
                                              'onClick' => "return search_element (event, '')"));
        //
        // Return the template just built
        //
        return $ret_value;
    }
	
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $sale_detail 	The line detail of the sale being edited.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_content_template ($sale_detail)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));
    	
        //
        // General page data
        //
        $ret_value['page_title']              = $this->lang->line ('sales_invoice') . ' #' . $sale_detail->sale_id; 
        $ret_value['fields_required_message'] = $this->lang->line ('common_fields_required_message');
        $ret_value['page_info']               = $this->lang->line ('sales_edit_item');
        
        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/save_detail/' . $sale_detail->id, 
                                               array ('id' => 'sale_detail_form'));
        $ret_value['form_close'] = form_close ( );

        //
        // Data about the sale detail parameter
        //
        $ret_value['data'] = array ( );

        //
        // Field "Item"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('sales_item_name'),
                                      'item',
                                      array ('class' => 'wide required'));

        //
        // Fill the possible values for the "Item" field
        //
        $options = array ( );
        
        foreach ($this->item->get_all ( ) as $my_item)
        {
            $options[$my_item->id] = $my_item->name;
        }

        //
        // ... and add a drop down with all the possible values
        //
        $selected       = $sale_detail->item_id;
        $field['input'] = form_dropdown ('item', $options, $selected);
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Quantity"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('sales_quantity'), 
                                      'quantity',
                                      array ('class'=>'wide required'));
                                      
        $field['input'] = form_input (array ('name' => 'quantity', 
                                             'id'   => 'quantity', 
                                             'value' => $sale_detail->get_real_value ('quantity')));
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Price"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('sales_price'), 
                                      'price',
                                      array ('class'=>'wide required'));
                                      
        $field['input'] = form_input (array ('name' => 'price', 
                                             'id'   => 'price', 
                                             'value' => $sale_detail->get_real_value ('price_unit')));
        
        array_push ($ret_value['data'], $field);
        
        //
        // Return the dynamic template built
        //
        return $ret_value;
    }
    

    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return 			   An array ready to be applied over the template page.-
     */
    private function _build_edit_buttons_template ( )
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
                                            array ('title' => $this->lang->line ('common_back')));

        //
        // The SAVE (or Submit) button
        //
        $ret_value['submit_button'] = anchor ('#', ' ',
                                              array ('title' => $this->lang->line ('common_submit'),
                                              //
                                              // This code connects this anchor with the Submit functionality
                                              //
                                              'onClick' => "return validate_form_data (event, document.forms[0]);"));
        //
        // Return the template just built
        //
        return $ret_value;
    }
    

    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $sale_id  The ID of the sale being paid.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_payment_content_template ($sale_id)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));
        
        //
        // General page data
        //
        $ret_value['page_title']              = $this->lang->line ('sales_payment') . ' - ' .
        										$this->lang->line ('sales_invoice') . ' #'  .
        										$sale_id; 
        $ret_value['fields_required_message'] = $this->lang->line ('common_fields_required_message');
        $ret_value['page_info']               = $this->lang->line ('sales_select_payment');
        
        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/calculate_payment/' . $sale_id, 
                                               array ('id' => 'payment_form'));
        $ret_value['form_close'] = form_close ( );

        //
        // Data about the different payment methods
        //
        $ret_value['data'] = array ( );

        //
        // Here we will calculate the amount payed
        // for all different payment types
        //
        $ret_value['amount_payed'] = 0.0;
        
        //
        // Fill all possible values for each payment method
        //
        $fields = array ( );

		//
		// Are there any existing payments for this sale?
		//
		$sale_payments = $this->sale_payment->get_by_sale ($sale_id);
		
		if (empty ($sale_payments))
		{
			//
			// No existing payments for this sale, display empty ones
			//
	        foreach ($this->payment->get_all ( ) as $my_payment)
	        {
		        //
		        // The ID is used to set which icon has to be displayed
		        //
		        $field['payment_id'] = $my_payment->id;
		        
		        //
		        // The name of this payment method in the current language
		        //
		        $field['name'] = $my_payment->name;
	
		        //
		        // The zero float value with the current locale settings
		        //
		        $field['amount'] = money_format ('%!.2n', 0);
		        
		        //
		        // Add this payment to the array
		        //
		        array_push ($ret_value['data'], $field);
	        }
		}
		else 
		{
			//
			// Display the existing payments for this sale
			//
	        foreach ($sale_payments as $sale_payment)
	        {
		        //
		        // The ID is used to set which icon has to be displayed
		        //
		        $field['payment_id'] = $sale_payment->payment_id;
		        
		        //
		        // The name of this payment method in the current language
		        //
		        $field['name'] = $this->payment->get_by_id ($sale_payment->payment_id)->name;
	
		        //
		        // The amount value with the current locale settings
		        //
		        $field['amount'] = $sale_payment->get_real_value ('amount');
		        
		        //
		        // Accumulate the amount payed
		        //
		        $ret_value['amount_payed'] += $sale_payment->amount;
		        
		        //
		        // Add this payment to the array
		        //
		        array_push ($ret_value['data'], $field);
	        }
		}
        
		//
		// Change the units of the amount payed
		//
		$ret_value['amount_payed'] /= 100;
		
		//
		// The amount due is the difference between payed and sale total
		//
		$sale = new Sale ($sale_id);
		
		$ret_value['amount_due'] = $ret_value['amount_payed'] -
		                           ($sale->get_subtotal ( ) +
								    $sale->get_taxes    ( ));
								   
		//
		// Change the amounts to the correct formats and units!
		//
		$ret_value['amount_payed'] = money_format ('%!.2n', 
		                                           $ret_value['amount_payed']);

        //
        // If the amount due is negative, then 
        // we are still missing some money
        //
        if ($ret_value['amount_due'] > 0)
        {
			$ret_value['amount_due'] = money_format ('%!.2n', 
			                                         $ret_value['amount_due']);
        }
        else
        {
            $ret_value['amount_due'] = ''; 
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }
    

    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_payment_buttons_template ( )
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
                                            array ('title' => $this->lang->line ('common_back')));

        //
        // The SAVE (or Submit) button
        //
        $ret_value['submit_button'] = anchor ('#', ' ',
                                              array ('title' => $this->lang->line ('sales_open_drawer'),
                                              //
                                              // This code connects this anchor with the 'calculate_payment'
                                              //
                                              'onClick' => "return validate_form_data (event, document.forms[0]);"));
        //
        // Return the template just built
        //
        return $ret_value;
    }
    

    
    
    /**
     * Returns HTML code containing a list of customers' names.
     * This function is called after a search for customers has 
     * returned more than one result for the user to select from.-
     * 
     * @param $sale_id   The ID of the sale where the search took place.-
     * @param $customers An array containing the Customer objects to
     *                   be displayed.-
     * 
     * @return          A string of dynamically generated HTML code.-
     */
    private function _build_customer_table ($sale_id = NULL, $customers = NULL )
    {
    	$ret_value = '';

        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));

    	//
    	// Check that the parameters are valid
    	//
    	if ($sale_id != NULL && $customers != NULL)
    	{
            //
            // Build a table with the customers just found ...
            //
            foreach ($customers as $customer)
            {
                //
                // Append this customer
                //
                $ret_value .= anchor ($controller_uri . '/set_customer/' . $sale_id . '/' . $customer->id . '/',
                                      $customer->first_name . ' ' . $customer->last_name,
                                      array ('title' => $this->lang->line ('sales_select_customer')));
                $ret_value .= '<br />';
            }
    	}
    	
        //
        // Return the table just built
        //
        return $ret_value;
    }
    

    /**
     * Returns HTML code containing a list of items' names, 
     * price and current quantity in stock.
     * This function is called after a search for items has 
     * returned more than one result for the user to select from.-
     * 
     * @param $sale_id  The ID of the sale where the search took place.-
     * @param $items    An array containing the Items objects to be
     *                  displayed.-
     * 
     * @return          A string of dynamically generated HTML code.-
     */
    private function _build_item_table ($sale_id = NULL, $items = NULL )
    {
        $ret_value = '';

        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1));

        //
        // Check that the parameters are valid
        //
        if ($sale_id != NULL && $items != NULL)
        {
            //
            // Build a table with the customers just found ...
            //
            foreach ($items as $item)
            {
                //
                // Append this item
                //
                $ret_value .= anchor ($controller_uri . '/add_item_to_sale/' . $sale_id . '/' . $item->id . '/',
                                      $item->name . '<br />' . 
                                          ' ('  . $item->get_real_value ('quantity', 0) .
                                          ')  ' . $item->get_real_value ('price_unit'),
                                      array ('title' => $this->lang->line ('sales_select_item')));
                $ret_value .= '<br />';
            }
        }
        
        //
        // Return the table just built
        //
        return $ret_value;
    }
    
    
    /**
     * Validates the data entered in the form for editing a line detail.-
     *
     * @return A string of error description if any validation rule fails.
     *         An empty string if there were no validation errors.-
     */
    private function _validate_save_detail ( )
    {
        //
        // Set the rules that have to be validated
        //
        $this->form_validation->set_rules ('item', 
                                           $this->lang->line ('sales_item_name'), 
                                           'required|trim');
                                           
        $this->form_validation->set_rules ('quantity', 
                                           $this->lang->line ('sales_quantity'), 
                                           'required|trim');
                                           
        $this->form_validation->set_rules ('price', 
                                           $this->lang->line ('sales_price'), 
                                           'required|trim');

        //
        // Start the data validation based on the rules just added
        //
        if ($this->form_validation->run ( ))
        {
            //
            // Data is valid, no errors
            //
            return '';
        }
        else
        {
            //
            // Data is invalid, return an error message with 
            // a given prefix (' ') and suffix (' ')
            //
            return validation_errors (' ', ' ');
        }
    }


    /**
     * Validates the data entered in the form for payment.-
     *
     * @return A string of error description if any validation rule fails.
     *         An empty string if there were no validation errors.-
     */
    private function _validate_payment ( )
    {
        //
        // Set the rules that have to be
        // validated for all payment types
        //
        foreach ($this->payment->get_all ( ) as $payment)
        {
	        $this->form_validation->set_rules ('amount_' . $payment->id, 
	                                           $payment->name, 
	                                           'required|trim');
        }
        
        //
        // Run data validation based on the rules just added
        //
        if ($this->form_validation->run ( ))
        {
            //
            // Data is valid, no errors
            //
            return '';
        }
        else
        {
            //
            // Data is invalid, return an error message with 
            // a given prefix (' ') and suffix (' ')
            //
            return validation_errors (' ', ' ');
        }
    }
    
    
    /**
	 * Constructor.-
	 */
	function __construct ( )
	{
		parent::__construct ('sales');
		
		$this->load->model   ('sales/sale', 	   'sale');
		$this->load->model   ('sales/sale_detail', 'sale_detail');
		$this->load->model   ('sales/sale_payment','sale_payment');
		$this->load->model   ('sales/payment',     'payment');
		$this->load->model   ('items/item', 	   'item');
		$this->load->model   ('persons/customer',  'customer');
		$this->load->model   ('compay/terminal',   'terminal');
		
		$this->load->library ('pdf');
        $this->load->library ('parser');		
		$this->load->library ('form_validation');

		$this->load->helper  ('url');
	}


    /**
     * The default entry point of this controller.-
     */
	function index ( )
	{
        //
        // Prepare the navigation stack to work inside this module
        //
        $this->navigation_stack->clear_stack ( );
        $this->navigation_stack->push ( );
		
        //
        // FIXME: Add extra functionality to this module
        //        by allowing editing previous invoices, returns, ...
        //
		$this->view ( );		
	}
	

    /**
     * Displays a list of active sales on the screen.-
     */
    function view ( )
    {
        //
        // Remember this address as a navigation node to come back later
        //
        $this->navigation_stack->push ( );
        
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;

        //
        // Create an array containing the currently active sales
        //
        $active_sales = $this->sale->get_active_sales_by_employee ($this->registered_employee->id);
        
        //
        // Fill the page templates with data
        //
        $page_content = $this->_build_table_of_sales_template         ($active_sales);
        $page_buttons = $this->_build_table_of_sales_buttons_template ( );
        
        $data['content'] = $this->parser->parse ('sales/table_sales',
                                                 $page_content,
                                                 true);
        $data['buttons'] = $this->parser->parse ('sales/table_sales_buttons', 
                                                 $page_buttons,
                                                 true);
                                                 
        //
        // Disable the right column
        //
        $data['disable_right_column'] = true;
        
        //
        // Load and display the view
        //
        $this->load->view ('sales/skeleton', $data);
    }
	
    /**
     * Creates a new empty sale.-
     */
    function add_new_sale ( )
    {
    	//
    	// Create a new sale object
    	//
    	$sale = new Sale ( );
    	
    	//
    	// Set some basic sale data ...
    	//
    	$sale->set_time (time ( ));
    	
    	//
    	// FIXME: Make this configurable (i.e. to set 
    	//        the default customer for a new sale).-
    	//
    	$sale->customer_id = 3;
    	$sale->employee_id = $this->registered_employee->id;
    	$sale->is_active   = true;
    	$sale->terminal_id = $this->appconfig->get ('this_terminal');

    	//
    	// ... and save it
    	//
    	$sale->update ( );
        
        //
        // Display the newly created sale by using redirect
        // so that the navigation stack behaves normally.
        //
        $controller_uri = strtolower ($this->uri->segment (1));
    	
        redirect ($controller_uri . '/view_sale/' . $sale->id);
    }
    
    
    /**
     * Displays a sale on the screen.-
     *
     * @param $sale_id The ID of the sale currently displayed.-
     */
    function view_sale ($sale_id = NULL)
    {
        //
        // Remember this address as a navigation node to come back later
        //
        $this->navigation_stack->push ( );
        
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        
        //
        // Did we receive a valid sale ID?
        //
        if ($sale_id == NULL)
        {
            //
            // Create a new empty sale with valid data
            //
            $sale = new Sale ( );
            
            $sale->employee_id = $this->registered_employee->id;
            $sale->comment     = '-';
            
            $sale->set_time (time ( ));
            $sale->update   ( );
            
            //
            // Now we have a valid ID
            //
            $sale_id = $sale->id;
        }
       
        //
        // Get a reference to the correct sale
        //
        $sale = new Sale ($sale_id);
        
        //
        // Fetch the invoice detail of this sale
        //
        $sale_details = $sale->get_details ( );
        
        //
        // Fill the page templates with data
        //
        $page_content = $this->_build_table_content_template ($sale_details, $sale);
        $page_buttons = $this->_build_table_buttons_template ($sale);
        
        $data['content'] = $this->parser->parse ('sales/table_details',
                                                 $page_content,
                                                 true);
        $data['buttons'] = $this->parser->parse ('sales/table_details_buttons', 
                                                 $page_buttons,
                                                 true);
        //
        // Add the data to build the right column
        //
        $data = array_merge ($data, $this->_build_right_column_content_template ($sale));
                                                 
        //
        // Load and display the view
        //
        $this->load->view ('sales/skeleton', $data);
    }
	
    
    /**
     * Displays a form for editing a sale detail (i.e. line) of a sale.-
     *
     * @param $sale_detail_id  	The ID of the sale detail line being edited.-
     */
    function edit_detail ($sale_detail_id = NULL)
    {
    	//
    	// Check if we received valid parameters
    	//
    	if ($sale_detail_id == NULL)
    	{
    		//
    		// Do nothing, because we didn't get any valid parameters
    		//
    		return (false);
    	}
    	else
    	{
	        //
	        // Remember this address as a navigation node to come back later
	        //
	        $this->navigation_stack->push ( );
	    	
	        //
	        // The data about the registered employee is held in the parent class
	        //
	        $data['registered_employee'] = $this->registered_employee;
	
	        //
	        // Fetch the sale detail being edited
	        //
	        $sale_detail = new Sale_detail ($sale_detail_id);
	
	        //
	        // Fill the page templates wih data
	        //
	        $page_content = $this->_build_edit_content_template ($sale_detail);
	        $page_buttons = $this->_build_edit_buttons_template ($sale_detail);
	                                                             
	        $data['content'] = $this->parser->parse ('sales/edit', 
	                                                 $page_content, 
	                                                 true);
	                                                 
	        $data['buttons'] = $this->parser->parse ('sales/edit_buttons', 
	                                                 $page_buttons,
	                                                 true);
			//
			// Add the data to build the right column
			//
			$data = array_merge ($data, $this->_build_right_column_content_template ($sale_detail->get_parent_sale ( )));
		                                                 
	        //
	        // Load and display the edit form
	        //
	        $this->load->view ('sales/skeleton', $data);
    	}
    }
    

    /**
     * Saves a line detail of the sale into the database.
     *
     * @param $sale_detail_id The ID of the sale detail being saved.-
     */
    function save_detail ($sale_detail_id = NULL)
    {
    	$ret_value = array ( );
    	
    	//
    	// Did we receive a valid ID?
    	//
    	if ($sale_detail_id != NULL)
    	{
	        //
	        // Validate all data in the form before saving it to the database
	        //
	        $errors = $this->_validate_save_detail ( );
	        
	        //
	        // Are there any validation errors?
	        //
	        if (empty ($errors))
	        {
	            //
	            // No errors. Create a new sale detail object
	            // and update its data in the database
	            //
	            $sale_detail = new Sale_detail ($sale_detail_id);
	
	            $sale_detail->item_id  = $this->input->post ('item');
	            $sale_detail->set_real_value ('quantity',   $this->input->post ('quantity'));	            
	            $sale_detail->set_real_value ('price_unit', $this->input->post ('price'));
	    
	            $sale_detail->update ( );
	
	            //
	            // Return a JSON-encoded message about the successful update
	            //
	            $ret_value['success'] = true;
	            $ret_value['message'] = $this->lang->line ('common_change_successful');
	        }
	        else
	        {
	        	//
	            // Return a JSON-encoded message with the error description
	            //
	            $ret_value['success'] = false;
	            $ret_value['message'] = $errors;
	        }
	
	        //
	        // Return a JSON-encoded message with the error description
	        //
	        echo json_encode ($ret_value);
    	}
    	else
    	{
    		//
    		// Go nowhere because of invalid ID
    		//
    		return (false); 
    	}
    }
    

    /**
     * Deletes a detail line from the sale with the given ID.-
     *
     * @param $sale_detail_id	The sale detail ID being deleted.-
     * 
     * @return    				A JSON-encoded string informing about the outcome.-
     */
    function delete_detail ($sale_detail_id = NULL)
    {
    	$ret_value = array ( );
    	
        //
        // Did we receive any valid ID?
        //
        if ($sale_detail_id != NULL)
        {
            //
            // Delete the store with the given ID
            //
            if ($this->sale_detail->delete_all (array ($sale_detail_id)))
            {
                $ret_value['success'] = true;
                $ret_value['message'] = $this->lang->line ('common_change_successful');
            }
            else
            {
            	$ret_value['success'] = false;
            	$ret_value['message'] = $this->lang->line ('common_change_unsuccessful');
            }
        }
        
        //
        // Return the JSON-encoded outcome
        //
        echo json_encode ($ret_value); 
    }
    
    
    /**
	 * Adds the specified item to the specified sale
	 * and redisplays the invoice content.-
	 *
	 * @param $sale_id 	The ID of the sale to which the item should be added.
	 * @param $item_id 	The ID of the item being added.
	 * 
	 * @return 			A JSON-encoded string containing the results.-
	 */
    function add_item_to_sale ($sale_id = NULL, $item_id = NULL)
	{
		$ret_value = array ( );
		
		//
		// Create a valid Sale object
		//
		if ($sale_id != NULL)
		{
			$sale = new Sale ($sale_id);
			
			//
			// Add the item to the sale
			//
			if ($sale->add_item ($item_id, 1))
	        {
	        	//
	        	// Item added
	        	//
	        	redirect (strtolower ($this->uri->segment (1)) . '/view_sale/' . $sale_id);
	        }
	        else
	        {
	        	//
	        	// Something went wrong ...
	        	//
	        	// FIXME: Display a nice error message
	        	//
	        	$ret_value['success'] = false;
	        	$ret_value['message'] = $this->lang->line ('sales_unable_to_add_item');

	        	//
	      		// Return the JSON-encoded answer
    			//
    			echo json_encode ($ret_value);
	        }    			
		}
	}
    
    
    /**
     * Sets the specified customer to the specified sale
     * and redisplays the invoice content.-
     *
     * @param $sale_id      The ID of the sale which customer should be changed.-
     * @param $customer_id  The ID of the customer being set.
     */
    function set_customer ($sale_id = NULL, $customer_id = NULL)
    {
        //
        // Did we receive a valid customer ID?
        //
        if ($customer_id != NULL)
        {
            $sale = new Sale ($sale_id);
            
            //
            // Is the Sale object valid?
            //
            if ($sale != NULL)
            {
            	$sale->customer_id = $customer_id;
            	
	            $sale->update ( );
	            
                //
                // Customer has changed
                //
                redirect (strtolower ($this->uri->segment (1)) . '/view_sale/' . $sale_id);
            }
        }
    }
    

    /**
     * Searches an item with the corresponding barcode or description.
     * If an exact match if found for the barcode, then the item is
     * automatically appended to the current sale.-
     *
     * @param $sale_id          The item found customer will be added to
     *                          the sale with this ID. It defaults to NULL.-
     * @param $search_string    The string that should be searched for a
     *                          barcode or an item description.-
     * 
     * @return                  A JSON-encoded string containing the results.-
     */
    public function search_item ($sale_id = NULL, $search_string = NULL)
    {
        $ret_value = array ( );
        
        //
        // Did we receive a valid search string?
        //
        if ($search_string != NULL)
        {
            //
            // First we will look for the barcode
            //
            $item = $this->item->get_by_barcode ($search_string);
            
            if ($item == NULL)
            {
                //
                // No matching barcode found.
                // Let's try to look for item descriptions
                //
                $items = $this->item->get_by_name_and_description ($search_string,
                                                                   $search_string);
                
                if (empty ($items))
                {
                	//
                	// Nothing found
                	//
	                $ret_value['elements_found'] = 0;
	                $ret_value['message']        = $this->lang->line ('sales_unable_to_add_item');
                }
                else
                {
	                //
	                // Inform the user that we found some items ...
	                //
	                $ret_value['elements_found'] = count ($items);
	                $ret_value['message']        = $this->lang->line ('sales_select_item');
	                
	                //
	                // ... and show her/him a list to choose from
	                // 
	                // FIXME: Try something else, not to hard-code the name of the
	                //        DIV where we want the search results to be displayed.
	                //
	                $ret_value['element_list']       = $this->_build_item_table ($sale_id, $items); 
	                $ret_value['element_list_panel'] = '#search_results_panel';
                }
            }               
            else
            {
                //
                // Found an exact barcode match! 
                //
                $ret_value['elements_found'] = 1;
                $ret_value['message']        = $this->lang->line ('sales_new_item');
                
                //  
                // Do we have a valid sale ID?
                //
                if ($sale_id != NULL)
                {
                    //
                    // The URI of this controller
                    //
                    $controller_uri = strtolower ($this->uri->segment (1));

                    //
                    // Build the address to add the item found to the sale
                    //
                    $ret_value['follow_address'] = site_url ($controller_uri . 
                                                            '/add_item_to_sale/' . 
                                                             $sale_id . '/' . $item->id);
                }
            }
        }
        
        //
        // Return the JSON-encoded answer
        //
        echo json_encode ($ret_value);
    }
    
    
    /**
     * Searches a customer by name.-
     *
     * @param $sale_id       The found customer will be added to the sale 
     *                       with this ID. It defaults to NULL.-
     * @param $search_string The string being searched for. Defaults to NULL.-
     *
     * @return               A JSON-encoded string containing the search results.-
     */
    public function search_customer ($sale_id = NULL, $search_string = NULL)
    {
        $ret_value = array ( );
        
        //
        // Did we receive a valid search string?
        //
        if ($search_string != NULL)
        {
            //
            // Look for this string as part of the name of the customer ...
            //
            $customers = $this->customer->get_by_name ($search_string,
                                                       $search_string);
            
            if (empty ($customers))
            {
                //
                // Nothing found ...
                //
                $ret_value['elements_found'] = 0;
                $ret_value['message']         = $this->lang->line ('common_nothing_to_display');
            }               
            else
            {
                //
                // Inform the user that we found some customers ...
                //
            	$ret_value['elements_found'] = count ($customers);
                $ret_value['message']         = $this->lang->line ('sales_select_customer');
                
                //
                // ... and show her/him a list to choose from
                // 
                // FIXME: Try something else, not to hard-code the name of the
                //        DIV where we want the search results to be displayed.
                //
                $ret_value['element_list']       = $this->_build_customer_table ($sale_id, $customers); 
                $ret_value['element_list_panel'] = '#search_results_panel';
            }
        }
        
        //
        // Return the JSON-encoded answer
        //
        echo json_encode ($ret_value);
    }

    
    /**
     * Closes an active sale by saving all its data to the database,
     * updating item stock quantities and customers accounts.-
     *
     * @param $sale_id       The sale currently being finished.- 
     *
     * @return               A JSON-encoded string with an information message.-
     */
    public function finish_sale ($sale_id = NULL)
    {
    	$ret_value = array ( );
    	$success   = true;
    	
    	//
    	// Did we receive a valid ID?
    	//
    	if ($sale_id != NULL)
    	{
    		//
    		// Create a new DB transaction before updating
    		//
    		$this->db->trans_start ( );
    		 
    		//
    		// Create a Sale object
    		//
    		$sale 		  = new Sale ($sale_id);
    		$sale_details = $sale->get_details ( );
    		
    		//
    		// For each of the items sold ...
    		//
    		foreach ($sale_details as $sale_detail)
    		{
	    		//
	    		// Substract the quantity sold from the item stock
	    		//
	    		$item 			 = new Item ($sale_detail['detail']->item_id);
	    		$item->quantity -= $sale_detail['detail']->quantity;
	    		
	    		//
	    		// Save the success value after updating the item
	    		//
	    		$success &= $item->update ( );
    		}
    		
    		//
    		// If everything went ok, close the active sale
    		//
    		if ($success)
    		{
    			$sale->set_time ( );
    			$sale->is_active = false;
    			$success 		&= $sale->update ( );
    		}
    		
    		//
    		// If everything was updated ok, commit
    		// the active transaction. Otherwise
    		// rollback all the changes.
    		//
    		if ($success)
    		{
    			$this->db->trans_complete ( );
    			
	        	$ret_value['elements_found'] = 1;
	        	$ret_value['message'] 		 = $this->lang->line ('common_change_successful');
	        	
	        	//
	        	// After displaying the success message, go to this address
	        	//
        		$controller_uri = strtolower ($this->uri->segment (1));
	        	
	        	$ret_value['follow_address'] = site_url ($controller_uri . '/generate_pdf_invoice/' . $sale_id);
    		}
    		else
    		{
    			$this->db->trans_rollback ( );
    			
	        	$ret_value['elements_found'] = 0;
	        	$ret_value['message'] 		 = $this->lang->line ('common_change_unsuccessful');
    		}
    	}
    	
    	//
    	// Tell the user about what we did
    	//
    	echo json_encode ($ret_value);
    }
    
    
    /**
     * Opens the payment selection view to let the user
     * define how the sale is being paid.-
     * 
     * @param $sale_id  The ID of the sale being paid.-
     */
    public function define_payment ($sale_id = NULL)
    {
    	//
    	// Did we receive a valid ID?
    	//
    	if ($sale_id != NULL)
    	{
	        //
	        // Remember this address as a navigation node to come back later
	        //
	        $this->navigation_stack->push ( );
	    	
	        //
	        // Create a valid Sale object
	        //
	        $sale = new Sale ($sale_id);
	         
		    //
		    // Fill the page templates wih data
		    //
		    $page_content = $this->_build_payment_content_template ($sale_id);
		    $page_buttons = $this->_build_payment_buttons_template ($sale_id);
		                                                                 
		    $data['content'] = $this->parser->parse ('sales/edit_payment', 
		                                             $page_content, 
		                                             true);
		    $data['buttons'] = $this->parser->parse ('sales/edit_buttons', 
		                                             $page_buttons,
		                                             true);
			//
			// Add the data to build the right column
			//
			$data = array_merge ($data, $this->_build_right_column_content_template ($sale));
	
		    //
		    // Load and display the edit form
		    //
		    $this->load->view ('sales/skeleton', $data);
    	}
    	else 
    	{
    		//
    		// Do nothing because of an invalid ID
    		//
    		return false;
    	}
    }
    
    /**
     * Generates and outputs the PDF invoice.
     * 
     * @param $sale_id: The ID of the sale, for which the invoice will be generated.
     */
    public function generate_pdf_invoice ($sale_id = NULL)
    {
        $sale = new Sale ($sale_id);
        if ($sale->exists ( ))
        {
            //
            // FIXME: remove this, when the sale contains the terminal
            //
            $this->load->model ('company/terminal');
            $terminal = $this->terminal->get_all ( );
            $terminal = $terminal[0];
            
            //
            // The output buffer contains a new line. It must be cleared, if
            // we want to output the PDF file
            //
            ob_clean ( );
            
            //
            // Create the bill.
            // 
            $this->pdf->create_bill ($sale, $terminal);
            
            //
            // Close and output PDF document.
            //
            $this->pdf->Output ('racun.pdf', 'I');
        }
    }
    

    /**
     * After the payment of a given sale has been specified,
     * it validates and calculates the received and due amounts.
     * This function is called from the onClick event of the
     * 'Submit' anchor.-
     * 
     * @param $sale_id  The ID of the sale being paid.-
     */
    public function calculate_payment ($sale_id = NULL)
    {
    	$ret_value = array ( );
    	$success   = true;
    	
    	//
    	// Did we receive a valid ID?
    	//
    	if ($sale_id != NULL)
    	{
	        //
	        // Validate all data in the form before
	        // saving it to the database
	        //
	        $errors = $this->_validate_payment ( );
	        
	        //
	        // Are there any validation errors?
	        //
	        if (empty ($errors))
	        {
	        	//
	        	// Start a transaction so that all changes will be consistent
	        	//
	        	$this->db->trans_start ( );
	        	
	            //
	            // No errors. Create (or update) Sale_payment 
	            // objects as needed
	            //
	            $sale_payments = $this->sale_payment->get_by_sale ($sale_id);

	            //
	            // Create or update this sale payments?
	            //
	            if (!empty ($sale_payments))
	            {
	            	//
	            	// We will first delete all payments of this sale
	            	//
	            	$delete_ids = array ( );
	            	
	            	foreach ($sale_payments as $payment)
	            	{
	            		$delete_ids[] = $payment->id;
	            	}
	            	
	            	$success &= $this->sale_payment->delete_all ($delete_ids);
	            }
	            
	            //
	            // We should only continue if no errors occurred
	            //
	            if ($success)
	            {
		            //
		            // Create the payments for this sale
		            //
		            $all_payments = $this->payment->get_all ($sale_id);
		            
		            foreach ($all_payments as $payment)
		            {
		            	//
		            	// Create an entry for this payment type
		            	//
		            	$sale_payment = new Sale_payment ( );
		            	
		            	$sale_payment->payment_id = $payment->id;
		            	$sale_payment->sale_id    = $sale_id;
		            	$sale_payment->set_real_value ('amount', $this->input->post ('amount_' . $payment->id));
		            											 
		            	$success &= $sale_payment->update ( );
		            }

		            //
		            // Any errors?
		            //
		            if ($success)
		            {
		            	//
		            	// Commit the opened transaction
		            	//
		            	$this->db->trans_complete ( );
		            	
			            //
			            // Return a JSON-encoded message about the successful update
			            //
			            $ret_value['success']        = true;
			            $ret_value['message']        = $this->lang->line ('common_change_successful');
			            $ret_value['follow_address'] = site_url (strtolower ($this->uri->segment (1)) . 
                                                                 '/define_payment/' . $sale_id);		            
		            }
	            }
	            
	            //
	            // Any errors during database updating?
	            //
	            if (!$success)
	            {
	            	//
	            	// Rollback the opened transaction
	            	//
	            	$this->db->trans_rollback ( );
	            	
		            //
		            // Return a JSON-encoded message about the unsuccessful
		            //
		            $ret_value['success'] = true;
		            $ret_value['message'] = $this->lang->line ('common_change_unsuccessful');
	            }
	        }
	        else
	        {
	        	//
	            // Return a JSON-encoded message with the error description
	            //
	            $ret_value['success'] = false;
	            $ret_value['message'] = $errors;
	        }
	        
	        //
	        // Return a JSON-encoded message with the error description
	        //
	        echo json_encode ($ret_value);
    	}
    	else
    	{
    		//
    		// Go nowhere because of invalid ID
    		//
    		return (false); 
    	}
    }    
}
?>
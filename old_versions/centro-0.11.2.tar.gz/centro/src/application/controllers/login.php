<?php
class Login extends Controller 
{
	/**
	 * Constructor
	 */
	function __construct ( )
	{
		parent::Controller ( );
		
		$this->load->model   ("persons/Employee");
		
		$this->load->library ("form_validation");
	}
	
	
	/**
	 * The default entry point of this controller.-
	 */
	function index ( )
	{
		if ($this->Employee->is_logged_in ( ))
		{
			redirect ('home');
		}
		else
		{
			//
    	    // Display the login screen, because the user has not yet authenticated
    	    //
			$data = array ('employees' => $this->Employee->get_all ( ));
			
			$this->load->view ('login/skeleton', $data);
		}
	}
	
	
	/**
	 * This function is used to check the login data entered by the user. 
	 * It is set as the action of the login form.-
	 */
	function login_check ( )
	{
		$username = $this->input->post ("username");
		$password = $this->input->post ("geslo");	
		
		//
		// Try to log in this employee with the supplied information
		//
		if ($this->Employee->login ($username, $password))
		{
			$this->index ( );
		}
		else
		{
			//
			// Display an error message alla "Login incorrect"
			//
			$this->form_validation->set_message ('login_check', 
												 $this->lang->line ('login_invalid_username_and_password'));
			return (FALSE);
		}
	}
}
?>

<?php
require_once (APPPATH . '/controllers/secure_area.php');

class Customer_controller extends Secure_area
{
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $customers  An array containing all customers.
     * 
     * @return An array ready to be applied over the template page.-
     */
   	private function _build_table_content_template ($customers)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // The title is customers
        //
        $ret_value['page_title']    = $this->lang->line ('customers_plural'); 
        //
        // The list column titles
        //
        $ret_value['column_titles'] = array (array ('title' => $this->lang->line ('common_last_name')),
        									 array ('title' => $this->lang->line ('common_first_name')),
        									 array ('title' => $this->lang->line ('common_email')),
        									 array ('title' => $this->lang->line ('common_phone_number')),
        									 //
        									 // Column for the EDIT button
        									 //
        									 array ('title'=>'&nbsp'),
        									 //
        									 // Column for the DELETE button
        									 //
        									 array ('title'=>'&nbsp'));
        //
        // Display or hide the 'No elements' message?
        //
        if (count ($customers) == 0)
        {
            $ret_value['display_status'] = 'display: inline;';
            $ret_value['empty_table']    = $this->lang->line ('common_nothing_to_display');
        }
        else
        {
            $ret_value['display_status'] = 'display: none;';
            $ret_value['empty_table']    = '';
        }

        //
        // Set the actual customer data for the whole table of records
        //
        $ret_value['table_data'] = array ( );
        
        foreach ($customers as $customer)
        {
            $customer_data = array ('last_name'    => $customer->last_name,
                             	    'first_name'   => $customer->first_name,
                             	    'email'        => $customer->email,
                                    'phone_number' => $customer->phone_number,
            
                                    'edit_link'    => anchor ($controller_uri . '/edit/' . $customer->id, 
            										          '...',
            										          array ('title' => $this->lang->line ('common_edit'))),
            										      
                    			    'delete_link'  => anchor ($controller_uri . '/delete/' . $customer->id . '/',
            										          'x', 
            					                              array ('id'    => 'delete',
            					                          	 	     'title' => $this->lang->line ('common_delete'),
					        							   	  	     //
					        							   	  	     // This code connects this anchor with the Delete functionality
					        							   	 	     //
					        							   	 	     'onClick' => "return delete_table_row (event);")));
        	//
        	// Save the data of the current customer
        	//
            array_push ($ret_value['table_data'], $customer_data);
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }


    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
	 *  
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_buttons_template ( )
    {
    	$ret_value = array ( );
    	
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
    	
        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
	                                        array ('title' => $this->lang->line ('common_back')));
        
		//
		// The NEW (or Add) CUSTOMER button
		//
        $ret_value['new_button'] = anchor ($controller_uri . '/edit/', ' ',
                                           array ('title' => $this->lang->line('customers_add')));
                                          
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }
    
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $customer	The customer being edited.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_content_template ($customer)
    {
        $ret_value = array ( );
        
    	//
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // General page data
        //
        $ret_value['page_title'] 			  = $this->lang->line ('customers_edit');
        $ret_value['fields_required_message'] = $this->lang->line ('common_fields_required_message');
        $ret_value['page_info'] 	 		  = $this->lang->line ('customers_basic_information');
        
        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/save/' . $customer->id, 
        								   	   array ('id' => 'customer_form'));
        $ret_value['form_close'] = form_close ( );
        
        //
        // Data about the customer parameter
        //
        $ret_value['data'] = array ( );
        
        //
        // Field "Customer first_name"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('common_first_name'), 
        							  'first_name', 
        							  array ('class'=>'wide required'));
        							  
        $field['input'] = form_input (array ('name' => 'first_name', 
        							  		 'id'   => 'first_name', 
        							  		 'value' => $customer->first_name));
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Customer last name"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('common_last_name'),
        							  'last_name', 
        							  array ('class' => 'wide required'));
        							  
        $field['input'] = form_input (array ('name' => 'last_name', 
        							  		 'id'   => 'last_name', 
        							  		 'value' => $customer->last_name));
        
        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Email"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('common_email'),
        							  'email', 
        							  array ('class' => 'wide'));
        							  
        $field ['input'] = form_input (array ('name' => 'email',
        									  'id'   => 'email',
        									  'value'=> $customer->email));

        array_push ($ret_value['data'], $field);

        //
        // Field "Customer telephone"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_phone_number'), 
        							   'phone_number', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'phone_number',
        									  'id'   => 'phone_number',
        									  'value'=> $customer->phone_number));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Customer address_1"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_address_1'), 
        							   'address_1', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'address_1',
        									  'id'   => 'address_1',
        									  'value'=> $customer->address_1));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Customer address_2"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_address_2'), 
        							   'address_2', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'address_2',
        									  'id'   => 'address_2',
        									  'value'=> $customer->address_2));

        array_push ($ret_value['data'], $field);
        
        
		//
        // Field "Customer city"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_city'), 
        							   'address_2', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'city',
        									  'id'   => 'city',
        									  'value'=> $customer->city));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Customer state"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_state'), 
        							   'state', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'state',
        									  'id'   => 'state',
        									  'value'=> $customer->state));

        array_push ($ret_value['data'], $field);
        
        //
        // Field "Customer zip_code"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_zip'), 
        							   'zip_code', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'zip_code',
        									  'id'   => 'zip_code',
        									  'value'=> $customer->zip_code));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Customer country"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_country'), 
        							   'country', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'country',
        									  'id'   => 'country',
        									  'value'=> $customer->country));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Customer country"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_comments'), 
        							   'comments', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'comments',
        									  'id'   => 'comments',
        									  'value'=> $customer->comments));

        array_push ($ret_value['data'], $field);
        
        //
        // Field "Customer account_number"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('customers_account_number'), 
        							   'account_number', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'account_number',
        									  'id'   => 'account_number',
        									  'value'=> $customer->account_number));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Return the dynamic template built
        //
        return $ret_value;
    }

    
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_buttons_template ( )
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
        							   		array ('title' => $this->lang->line ('common_back')));

        //
    	// The SAVE (or Submit) button
    	//
    	$ret_value['submit_button'] = anchor ('#', ' ',
        							   	 	  array ('title'   => $this->lang->line ('common_submit'),
        							   	 	  //
        							   	 	  // This code connects this anchor with the Submit functionality
        							   	 	  //
        							   	 	  'onClick' => "return validate_form_data (event, document.forms[0]);"));
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }

    /**
     * Validates the data retrieved from the input.
     *
     * @return a string of errors, if it is an empty string, there were no validation errors
     */
    private function _validate_save ( )
    {
        $this->form_validation->set_rules ('first_name', $this->lang->line ('common_first_name'), 'trim|required');
        $this->form_validation->set_rules ('last_name', $this->lang->line ('common_last_name'), 'trim|required');
        $this->form_validation->set_rules ('email', $this->lang->line ('common_email'), 'trim|valid_email');

        if ($this->form_validation->run ( ) == false)
        {
            return validation_errors (' ',' ');
        }
        else
        {
            return '';
        }
    }

    /**
     * Constructor
     */
    function __construct ( )
    {
        parent::__construct ('customer');
        $this->load->model('persons/customer');
        $this->load->library ('parser');
        $this->load->library ('form_validation');
    }

    /**
     * The default entry point of this controller.-
     */
    function index ( )
    {
        //
        // Prepare the navigation stack to work inside this module
        //
        $this->navigation_stack->clear_stack ( );
        $this->navigation_stack->push ( );
    	
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['module_name'] = $this->lang->line ('module_customer');
        
        //
        // Fetch the customers
        //
        $customers = $this->customer->get_all ( );
        
        //
        // Fill the page templates with data
        //
        $page_content = $this->_build_table_content_template ($customers);
        $page_buttons = $this->_build_table_buttons_template ( );
        
        $data['content'] = $this->parser->parse ('people/table_people', 
        										 $page_content,
        										 true);
        $data['buttons'] = $this->parser->parse ('table_buttons', 
        										 $page_buttons,
        										 true);
        //
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
    }

    /**
     * Loads the customer edit form.
     */
    function edit ($customer_id = NULL)
    {
        //
	    // Remember this address as a navigation node to come back later
	    //
	    $this->navigation_stack->push ( );
	    
	    //
	    // The data about the registered employee is held in the parent class
	    //
	    $data['registered_employee'] = $this->registered_employee;
	    $data['module_name'] = $this->lang->line ('module_customer');
	    
	
	    //
	    // Fetch the customer being edited
	    //
	    $customer = new Customer ($customer_id);
	
	    //
	    // Fill the page templates wih data
	    //
	    $page_content = $this->_build_edit_content_template ($customer);
	    $page_buttons = $this->_build_edit_buttons_template ($customer);
	       
	    $data['content'] = $this->parser->parse ('edit_common', 
	      										 $page_content, 
	       										 true);
	        										 
	    $data['buttons'] = $this->parser->parse ('edit_common_buttons', 
	       										 $page_buttons,
	       										 true);
	    //
	    // Load and display the edit form
	    //
	    $this->load->view ('skeleton', $data);
    }

    /**
     * Inserts/updates a customer
     */
    function save ($customer_id = NULL)
    {
        // Form validation
        $errors = $this->_validate_save ( );
        if ($errors != '')
        {
            echo json_encode (array ('success'=>false, 'message'=>$errors));
            return;
        }


        $customer               = new Customer ($customer_id);
        $customer->first_name   = $this->input->post ('first_name');
        $customer->last_name    = $this->input->post ('last_name');
        $customer->email        = $this->input->post ('email');
        $customer->phone_number = $this->input->post ('phone_number');
        $customer->address_1    = $this->input->post ('address_1');
        $customer->address_2    = $this->input->post ('address_2');
        $customer->city         = $this->input->post ('city');
        $customer->state        = $this->input->post ('state');
        $customer->zip_code     = $this->input->post ('zip_code');
        $customer->country      = $this->input->post ('country');
        $customer->comments     = $this->input->post ('comments');
         
        if ($this->input->post ('account_number') == '')
        {
            $customer->account_number = NULL;
        }
        else
        {
            $customer->account_number = $this->input->post ('account_number');
        }

        $customer->update ( );
         
        echo json_encode(array('success'=>true,'message'=>$this->lang->line ('common_change_successful')));
    }

    /**
     * Deletes a customer from the database.
     *
     * @param $id The customer ID being deleted.-
     */
    function delete ($id = NULL)
    {
    	//
    	// Did we receive any valid ID?
    	//
    	if ($id != NULL)
    	{
    		//
    		// Delete the customer with the given ID FIXME: delete is deprecated
    		//
	        if ($this->customer->delete ($id))
	        {
	            echo json_encode (array ('success'=>true, 'message'=>$this->lang->line ('common_change_successful')));
	        }
	        else
	        {
	            echo json_encode (array ('success'=>false, 'message'=>$this->lang->line ('common_change_unsuccessful')));
	        }
    	}
    }

    /**
     * FIXME: Implement ...
     */
    function search ( )
    {
        // FIXME: implement
        echo 'Implement';
    }


    /**
     * FIXME: Implement ...
     */
    function suggest ( )
    {
        // FIXME: implement
        echo 'Implement';
    }
}
?>
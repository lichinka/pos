<?php
require_once (APPPATH . '/controllers/secure_area.php');

/**
 * This controller handles the Items module.-
 * 
 * @author luka
 */
class Item_controller extends Secure_area 
{
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $items  An array containing all items.
     * 
     * @return An array ready to be applied over the template page.-
     */
   	private function _build_table_content_template ($items)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // The title is articels
        //
        $ret_value['page_title']    = $this->lang->line ('items_plural'); 
        //
        // The list column titles
        //
        $ret_value['column_titles'] = array (array ('title' => $this->lang->line ('items_name')),
        									 array ('title' => $this->lang->line ('categories_name')),
        									 array ('title' => $this->lang->line ('items_size_group')),
        									 array ('title' => $this->lang->line ('items_cost_price')),
        									 array ('title' => $this->lang->line ('items_unit_price')),
        									 array ('title' => $this->lang->line ('items_tax_percents')),
        									 array ('title' => $this->lang->line ('items_quantity')),
        									 //
        									 // Column for the EDIT button
        									 //
        									 array ('title'=>'&nbsp'),
        									 //
        									 // Column for the DELETE button
        									 //
        									 array ('title'=>'&nbsp'));
        //
        // Display or hide the 'No elements' message?
        //
        if (count ($items) == 0)
        {
            $ret_value['display_status'] = 'display: inline;';
            $ret_value['empty_table']    = $this->lang->line ('common_nothing_to_display');
        }
        else
        {
            $ret_value['display_status'] = 'display: none;';
            $ret_value['empty_table']    = '';
        }

        //
        // Set the actual item data for the whole table of records
        //
        $ret_value['table_data'] = array ( );
        
        foreach ($items as $item)
        {
            $item_data = array ('name'         => $item->name,
                          	    'category'     => $item->get_parent_category ( )->name,
                           	    'sizes'        => $item->get_parent_size_group ( )->name,
                                'price_cost'   => $item->get_real_value ('price_cost'),
                                'price_unit'   => $item->get_real_value ('price_unit'),
                                'tax_rates'    => $this->_get_tax_cell ($item),
                                'quantity'     => $item->get_real_value ('quantity', 0),
            
                                'edit_link'    => anchor ($controller_uri . '/edit/' . $item->id, 
            		    						          '...',
            									          array ('title' => $this->lang->line ('common_edit'))),
            										      
                    		    'delete_link'  => anchor ($controller_uri . '/delete/' . $item->id . '/',
            									          'x', 
            				                              array ('id'    => 'delete',
            			                       	 	      'title' => $this->lang->line ('common_delete'),
					        				   	  	      //
					        				   	  	      // This code connects this anchor with the Delete functionality
					        				   	 	      //
					        				   	 	      'onClick' => "return delete_table_row (event);")));
        	//
        	// Save the data of the current item
        	//
            array_push ($ret_value['table_data'], $item_data);
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }
    
    
 	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
	 *  
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_buttons_template ( )
    {
    	$ret_value = array ( );
    	
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
    	
        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
	                                        array ('title' => $this->lang->line ('common_back')));
        
		//
		// The NEW (or Add) ITEM button
		//
        $ret_value['new_button'] = anchor ($controller_uri . '/edit/', ' ',
                                           array ('title' => $this->lang->line('items_new')));
                                          
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }
    
    
    /**
     * Returns the tax info cell data for a single item.
     * 
     * @param $item is the item, that will have its taxes returned
     * 
     * @return A properly formatted HTML table cell
     */
    private function _get_tax_cell ($item)
    {
    	$ret_value = '';
        $taxes 	   = $this->tax->get_by_item ($item->id);
        
        foreach ($taxes as $tax)
        {
            $ret_value .= $tax->get_real_value ('percent') . '%, ';
        }
        
        //
        // Return the string without the last comma
        // 
        return substr ($ret_value, 0, -2);
    }
    
    
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $item	The item being edited.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_content_template ($item)
    {
        $ret_value = array ( );
        
    	//
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // General page data
        //
        $ret_value['page_title'] 			  = $this->lang->line ('items_edit');
        $ret_value['fields_required_message'] = $this->lang->line ('common_fields_required_message');
        $ret_value['page_info'] 	 		  = $this->lang->line ('items_basic_information');
        
        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/save/' . $item->id, 
        								   	   array ('id' => 'item_form'));
        $ret_value['form_close'] = form_close ( );
        
        //
        // Data about the item parameter
        //
        $ret_value['data'] = array ( );
        
        //
        // Field "Item name"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('items_name'), 
        							  'name', 
        							  array ('class'=>'wide required'));
        							  
        $field['input'] = form_input (array ('name' => 'name', 
        							  		 'id'   => 'name', 
        							  		 'value' => $item->name));
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Item barcode"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('items_item_number'),
        							  'barcode', 
        							  array ('class' => 'wide required'));
        							  
        $field['input'] = form_input (array ('name' => 'barcode', 
        							  		 'id'   => 'barcode', 
        							  		 'value' => $item->barcode));
        
        array_push ($ret_value['data'], $field);
        
        //
        // Field "Item Categories"
        //
        $field = array ( );
        
        //
		// Build an array for all categories, containing only id and category name
		//
		$categories = array ( );
		
		foreach ($this->Category->get_all ( ) as $category)
		{
			//
			// If the category has a parent, display its name pushed towards the right
			//
			if ($category->parent_id > 0)
			{
				$category->name = "=> " . $category->name;
			}
			
			$categories["$category->id"] = $category->name;
		}
        
        
        $field['label'] = form_label ($this->lang->line ('items_category'),
        							  'category', 
        							  array ('class' => 'wide required'));
        							  
        $field ['input'] = form_dropdown ('category',
                                          $categories,
                                          $item->category_id,
                                          array ('id' => 'category'));

        array_push ($ret_value['data'], $field);

        //
        // Field "Item sizes"
        //
        $field = array ( );
        
        //
		// Build an array for all size groups, containing only id and name
		//
		$size_groups = array ( );
		
		foreach ($this->Size_group->get_all ( ) as $size_group)
		{
			$size_groups["$size_group->id"] = $size_group->name;
		}
        
        $field ['label'] = form_label ($this->lang->line ('items_size_group'), 
        							   'size_group', 
        							   array ('class'=>'wide required'));
        							   
        $field ['input'] = form_dropdown ('size_group',
                                          $size_groups,
                                          $item->size_group_id,
                                          array ('id' => 'phone_number'));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Item price_cost"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('items_cost_price'), 
        							   'price_cost', 
        							   array ('class'=>'wide required'));
        							   
        $field ['input'] = form_input (array ('name' => 'price_cost',
        									  'id'   => 'price_cost',
        									  'value'=> $item->get_real_value ('price_cost')));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Item price_unit"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('items_unit_price'), 
        							   'price_unit', 
        							   array ('class'=>'wide required'));
        							   
        $field ['input'] = form_input (array ('name' => 'price_unit',
        									  'id'   => 'price_unit',
        									  'value'=> $item->get_real_value ('price_unit')));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Item quantity"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('items_quantity'), 
        							   'quantity', 
        							   array ('class'=>'wide required'));
        							   
        $field ['input'] = form_input (array ('name' => 'quantity',
        									  'id'   => 'quantity',
        									  'value'=> $item->get_real_value ('quantity', 0)));

        array_push ($ret_value['data'], $field);
        
        //
        // Field "Item reorder_level"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('items_reorder_level'), 
        							   'reorder_level', 
        							   array ('class'=>'wide required'));
        							   
        $field ['input'] = form_input (array ('name' => 'reorder_level',
        									  'id'   => 'reorder_level',
        									  'value'=> $item->get_real_value ('reorder_level', 0)));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Item description"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('items_description'), 
        							   'description', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'description',
        									  'id'   => 'description',
        									  'value'=> $item->description));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Fields "Item taxes"
        //
        $ret_value['tax_data'] = array ( );
        $taxes = $this->tax->get_by_item ($item->id);
        for ($i = 0; $i < count ($taxes); $i++)
        {
            $field = array ( );
            
            $field ['hidden_tax_id'] = form_hidden('tax_ids[]', $taxes[$i]->id);
            
            $field ['label_name'] = form_label (($i + 1) . '. ' . $this->lang->line ('sales_tax'), 
            							        'tax_name' . $i, 
            							        array ('class'=>'wide'));
            							   
            $field ['input_name'] = form_input (array ('name' => 'tax_names[]',
            									       'id'   => 'tax_name' . $i,
                                                       'size' => 7,
            									       'value'=> $taxes[$i]->name));
            
            $field ['input_percent'] = form_input (array ('name' => 'tax_percents[]',
            									          'id'   => 'tax_percent' . $i,
                                                          'size' => 7,
            									          'value'=> $taxes[$i]->get_real_value ('percent')));
            
            $field ['label_percent'] = form_label ('%', 
            							           'tax_percent' . $i, 
            							           array ('class'=>'wide'));
    
            array_push ($ret_value['tax_data'], $field);
        }
        
        //
        // Always add 2 empty tax fields
        //
        for ($i; $i < count ($taxes) + 2; $i++)
        {
            $field = array ( );
            
            $field ['hidden_tax_id'] = form_hidden('tax_ids[]', '');
            
            $field ['label_name'] = form_label (($i + 1) . '. ' . $this->lang->line ('items_tax'), 
            							        'tax_name' . $i, 
            							        array ('class'=>'wide'));
            							   
            $field ['input_name'] = form_input (array ('name' => 'tax_names[]',
            									       'id'   => 'tax_name' . $i,
                                                       'size' => 7,
            									       'value'=> ''));
            
            $field ['input_percent'] = form_input (array ('name' => 'tax_percents[]',
            									          'id'   => 'tax_percent' . $i,
                                                          'size' => 7,
            									          'value'=> ''));
            
            $field ['label_percent'] = form_label ('%', 
            							           'tax_percent' . $i, 
            							           array ('class'=>'wide'));
    
            array_push ($ret_value['tax_data'], $field);
        }
        
        
        //
        // Return the dynamic template built
        //
        return $ret_value;
    }

    
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_buttons_template ( )
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
        							   		array ('title' => $this->lang->line ('common_back')));

        //
    	// The SAVE (or Submit) button
    	//
    	$ret_value['submit_button'] = anchor ('#', ' ',
        							   	 	  array ('title'   => $this->lang->line ('common_submit'),
        							   	 	  //
        							   	 	  // This code connects this anchor with the Submit functionality
        							   	 	  //
        							   	 	  'onClick' => "return validate_form_data (event, document.forms[0]);"));
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }
    
	/**
     * Validates the data retrieved from the input.
     *
     * @return a string of errors, if it is an empty string, there were no validation errors
     */
    private function _validate_save ( )
    {
    	//
    	// Items-related validation rules
    	//
        $this->form_validation->set_rules ('name',          $this->lang->line ('items_name'), 		   'trim|required');
        $this->form_validation->set_rules ('barcode',       $this->lang->line ('items_item_number'),   'trim|required');
        $this->form_validation->set_rules ('category',      $this->lang->line ('items_category'),      'trim|required');
        $this->form_validation->set_rules ('size_group',    $this->lang->line ('items_size_group'),    'trim|required');
        $this->form_validation->set_rules ('price_cost',    $this->lang->line ('items_cost_price'),    'trim|required');
        $this->form_validation->set_rules ('price_unit',    $this->lang->line ('items_unit_price'),    'trim|required');
        $this->form_validation->set_rules ('quantity',      $this->lang->line ('items_quantity'), 	   'trim|required');
        $this->form_validation->set_rules ('reorder_level', $this->lang->line ('items_reorder_level'), 'trim|required');
        
        if ($this->form_validation->run ( ))
        {
            return '';
        }
        else
        {
            return validation_errors (' ',' ');
        }
    }
    
	
	/**
	 * Constructor
	 */
	function __construct ( )
	{
		parent::__construct  ('items');
		
		$this->load->model   ('items/item');
		$this->load->model   ('items/category');
		$this->load->model   ('items/size_group');
		$this->load->model   ('items/tax');
		
		$this->load->library ('parser');
        $this->load->library ('form_validation');
	}
	
	
	/**
     * The default entry point of this controller.-
     */
	function index ( )
	{
		//
        // Prepare the navigation stack to work inside this module
        //
        $this->navigation_stack->push ( );
    	
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['module_name'] = $this->lang->line ('module_items');
        
        //
        // Fetch the items
        //
        $items = $this->item->get_all ( );
        
        //
        // Fill the page templates with data
        //
        $page_content = $this->_build_table_content_template ($items);
        $page_buttons = $this->_build_table_buttons_template ( );
        
        $data['content'] = $this->parser->parse ('items/table_items', 
        										 $page_content,
        										 true);
        $data['buttons'] = $this->parser->parse ('table_buttons', 
        										 $page_buttons,
        										 true);
        //
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
	}
	
	/**
	 * Opens the pop-up window that displays all the data related to an item.-
	 */
	function edit ($item_id = NULL)
	{
		//
	    // Remember this address as a navigation node to come back later
	    //
	    $this->navigation_stack->push ( );
	    
	    //
	    // The data about the registered employee is held in the parent class
	    //
	    $data['registered_employee'] = $this->registered_employee;
	    $data['module_name'] = $this->lang->line ('module_items');
	
	    //
	    // Fetch the item being edited
	    //
	    $item = new Item ($item_id);
	
	    //
	    // Fill the page templates wih data
	    //
	    $page_content = $this->_build_edit_content_template ($item);
	    $page_buttons = $this->_build_edit_buttons_template ( );
	       
	    $data['content'] = $this->parser->parse ('items/edit_items', 
	      										 $page_content, 
	       										 true);
	        										 
	    $data['buttons'] = $this->parser->parse ('edit_common_buttons', 
	       										 $page_buttons,
	       										 true);
	    //
	    // Load and display the edit form
	    //
	    $this->load->view ('skeleton', $data);
	}
	
	/**
     * Inserts/updates an item
     */
	function save ($item_id = NULL)
	{
		//
	    // Form validation
	    //
        $errors = $this->_validate_save ( );
        
        if (!empty ($errors))
        {
            echo json_encode (array ('success'=>false, 'message'=>$errors));
            return;
        }
        
        $item = new Item ($item_id);
        
        $item->name          = $this->input->post ('name');
        $item->barcode       = $this->input->post ('barcode');
        $item->description   = $this->input->post ('description');
        $item->category_id   = $this->input->post ('category');
        $item->size_group_id = $this->input->post ('size_group');
        
        $item->set_real_value ('price_cost', 	$this->input->post ('price_cost'));
        $item->set_real_value ('price_unit', 	$this->input->post ('price_unit'));
        $item->set_real_value ('quantity',   	$this->input->post ('quantity'));
        $item->set_real_value ('reorder_level', $this->input->post ('reorder_level'));
        
		$taxes        = array ( );
		
		$tax_ids      = $this->input->post ('tax_ids');
		$tax_names    = $this->input->post ('tax_names');
		$tax_percents = $this->input->post ('tax_percents');
		
		for ($k = 0; $k < count ($tax_percents); $k ++)
		{
			if (strlen ($tax_names[$k]) > 0)
			{
			    if ($tax_ids[$k] == '')
			    {
			        $tax = new Tax (NULL);
			    }
			    else
			    {
			        $tax = new Tax ($tax_ids[$k]);
			    }
			    
			    $tax->name = $tax_names[$k];
			    $tax->set_real_value ('percent', $tax_percents[$k]);
			    
			    array_push ($taxes, $tax);
			    
				continue;
			}
			else if ($tax_percents[$k] == '' && $tax_names[$k] == '')
			{
			    continue;
			}
			if ($tax_percents[$k] != '')
			{
			    //
	            // This cannot be done inside _validate save
	            //
	            if (is_numeric($tax_percents[$k]))
	            {
    	            echo json_encode (array ('success' => false, 
    	      						 		 'message' => $this->lang->line ('items_tax_name_required')));
	            }
	            else
	            {
	                echo json_encode (array ('success' => false, 
    	      						 		 'message' => $this->lang->line ('items_tax_percent_numeric')));
	            }
	            return;
			}
			if ($tax_names[$k] != '')
			{
			    //
	            // This cannot be done inside _validate save
	            //
	            echo json_encode (array ('success' => false, 
	      						 		 'message' => $this->lang->line ('items_tax_name_required')));
	            return;
			}
		}
		
		$this->db->trans_start ( );

        $item->update ( );
        
        //
        // Delete all taxes, that are obsolete
        //
        $current_taxes = $this->tax->get_by_item ($item->id);
        $obsolete_ids  = array ( );
        
        foreach ($current_taxes as $current_tax)
        {
            $obsolete = True;
            foreach ($taxes as $tax)
            {
                if ($current_tax->id == $tax->id)
                {
                    $obsolete = False;
                    break;
                }
            }
            
            if ($obsolete)
            {
                array_push ($obsolete_ids, $current_tax->id);
            }
        }
        $this->tax->delete_all ($obsolete_ids);
        
        //
        // Finally update the valid taxes
        //
        foreach ($taxes as $tax)
        {
            $tax->item_id = $item->id;
            $tax->update ( );
        }
		
		$this->db->trans_complete ( );
		
        //
	    // Return a JSON-encoded message about the successful update
	    //
	    echo json_encode (array ('success' => true, 
	      						 'message' => $this->lang->line ('common_change_successful')));        
	}
	
	/**
     * Deletes an item from the database.
     *
     * @param $id The item ID being deleted.-
     */
	function delete ($id = NULL)
	{
	    //
    	// Did we receive any valid ID?
    	//
    	if ($id != NULL)
    	{	
    	    //
    		// Delete the item with the given ID FIXME: delete is deprecated
    		//
	        if ($this->item->delete ($id))
	        {
	            echo json_encode (array ('success'=>true, 'message'=>$this->lang->line ('common_change_successful')));
	        }
	        else
	        {
	            echo json_encode (array ('success'=>false, 'message'=>$this->lang->line ('common_change_unsuccessful')));
	        }
    	}
	}
	
    /**
     * FIXME: Implement ...
     */
	function find_item_by_barcode ( )
	{
		// FIXME: implement
        echo 'Implement';
	}
	
	
	/**
     * FIXME: Implement ...
     */
    function search ( )
    {
        // FIXME: implement
        echo 'Implement';
    }


    /**
     * FIXME: Implement ...
     */
    function suggest ( )
    {
        // FIXME: implement
        echo 'Implement';
    }
	
	/**
     * FIXME: Implement ...
     */
	function suggest_category()
	{
		/**
     	* FIXME: Implement ...
     	*/
	    echo 'Implement';
	}
}
?>
<?php
/**
 * Controllers that are considered secure extend Secure_area.
 * Optionally a $module_name can be set to also check if a
 * user can access a particular module in the system.-
 */
class Secure_area extends Controller 
{
	var $registered_employee;
	
	
	/**
	 * Constructor
	 * 
	 * @param $module_name
	 */
	function __construct ($module_name = NULL)
	{
		parent::Controller ( );
		$this->load->model ("persons/Employee");
		
		//
		// Check if there is anyone logged in
		//
		if ($this->Employee->is_logged_in ( ))
		{
			//
			// Build a new employee object with th ID from the current session
			//
			$this->registered_employee = new Employee ($this->session->userdata ("employee_id"));
			
			//
			// Check if this employee has permission to access this module
			//
			if (! $this->registered_employee->has_permission ($module_name))
			{
				redirect ('no_access/' . $module_name);
			}
		}
		else
		{
			redirect ('login');
		}		
	}
}
?>
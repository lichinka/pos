<?php
require_once (APPPATH . '/controllers/secure_area.php');


/**
 * This is the default controller for editing the company data.
 *
 * @author luka
 *
 */
class Company_controller extends Secure_area
{
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $company An instance of the Company model.
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_content_template ($company)
    {
        $ret_value = array ( );

        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
        
        //
        // General page data
        //
        $ret_value['page_title'] 			  = $this->lang->line ('config_company_page_title');
        $ret_value['fields_required_message'] = $this->lang->line ('common_fields_required_message');
        $ret_value['page_info'] 	 		  = $this->lang->line ('config_company_info');

        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/save/' . $company->id, 
        								   	   array ('id' => 'company_form'));
        $ret_value['form_close'] = form_close ( );
        
        //
        // Data about the company parameter
        //
        $ret_value['data'] = array ( );

        //
        // Field "Company name"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('config_company_name'), 
        							  'company', 
        							  array ('class'=>'wide required'));
        							  
        $field['input'] = form_input (array ('name'  => 'company', 
        							  		 'id'    => 'company', 
        							  		 'value' => $company->name));
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Company address"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('config_company_address'),
        							  'address', 
        							  array ('class' => 'wide required'));
        							  
        $field['input'] = form_textarea (array ('name' => 'address', 
        										'id'   => 'address', 
        										'rows' => 4,
        									    'cols' => 23,
        										'value'=> $company->address));
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Company identification"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('config_company_identification'), 
        							   'identification', 
        							   array ('class'=>'wide required'));
        							   
        $field ['input'] = form_input (array ('name' => 'identification',
        									  'id'   => 'identification',
        									  'value'=> $company->identification));

        array_push ($ret_value['data'], $field);

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }

    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     *
     * @param $company An instance of the Company model.
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_buttons_template ($company)
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
        							   		array ('title' => $this->lang->line ('common_back')));
        //
        // The EDIT STORES button
        //
        $ret_value['edit_button'] = anchor ('company/store_controller/view/' . $company->id . '/', ' ',
        							  	    array ('title' => $this->lang->line ('config_store_edit_stores')));
    	//
    	// The SAVE (or Submit) button
    	//
    	$ret_value['submit_button'] = anchor ('#', ' ',
        							   	 	  array ('title'   => $this->lang->line ('common_submit'),
        							   	 	  //
        							   	 	  // This code connects this anchor with the Submit functionality
        							   	 	  //
        							   	 	  'onClick' => "return validate_form_data (event, document.forms[0]);"));
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }    
    
    
    /**
     * Validates the entered in the form.-
     *
     * @return A string of error description if any validation rule fails.
     * 		   An empty string if there were no validation errors.-
     */
    private function _validate_save ( )
    {
    	//
    	// Set the rules that have to be validated
    	//
        $this->form_validation->set_rules ('company', 
        								   $this->lang->line ('config_company_name'), 
        								   'trim|required');
        $this->form_validation->set_rules ('address', 
        								   $this->lang->line ('config_company_address'), 
        								   'trim|required');
        $this->form_validation->set_rules ('identification', 
        								   $this->lang->line ('config_company_identification'),
        								   'trim|required');

        //
        // Start the data validation based on the rules just added
        //
        if ($this->form_validation->run ( ))
        {
        	//
        	// Data is valid, no errors
        	//
        	return '';
        }
        else
        {
        	//
        	// Data is invalid, return an error message with 
        	// a given prefix (' ') and suffix (' ')
        	//
            return validation_errors (' ', ' ');
        }
    }

    
    
    /**
     * Constructor.-
     */
    function __construct ( )
    {
        parent::__construct ('config');
        
        $this->load->model 	 ('company/company');
        $this->load->library ('parser');
        $this->load->library ('form_validation');
    }

    
    
    /**
     * The default entry point of this controller.-
     */
    function index ( )
    {
    	//
        // FIXME: Make the controller fully capable of editing multiple companies
        //
        $this->view (1);
    }

    
    /**
     * Displays a form for editing/adding a company.
     *
     * @param $id The ID of the company being displayed.
     */
    function view ($id = NULL)
    {
    	//
    	// Remember this address as a navigation node to come back later
    	//
    	$this->navigation_stack->push ( );
    	
    	//
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['module_name'] = $this->lang->line ('module_config');

        //
        // Fetch the company data
        //
        $company = new Company ($id);
        
        //
        // Fill the page templates wih data
        //
        $page_content 	 = $this->_build_content_template ($company);
        $page_buttons	 = $this->_build_buttons_template ($company);
        
        $data['content'] = $this->parser->parse ('edit_common', 
        										 $page_content, 
        										 true);
        $data['buttons'] = $this->parser->parse ('company/edit_buttons',
        										 $page_buttons,
        										 true);
    	//
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
    }

    
    
    /**
     * Saves the company into the database.-
     *
     * @param $id The ID of the company being saved.-
     */
    public function save ($id = NULL)
    {
    	//
    	// Validate all data in the form before saving it to the database
    	//
        $errors = $this->_validate_save ( );
        
        //
        // Are there any validation errors?
        //
        if (empty ($errors))
        {
			//
			// No errors. Create a new company object and
			// update its data in the database
			//
	        $company = new Company ($id);
	        
	        $company->name 			 = $this->input->post ('company');
	        $company->address 		 = $this->input->post ('address');
	        $company->identification = $this->input->post ('identification');
	
	        $company->update ( );

	        //
	        // Return a JSON-encoded message about the successful update
	        //
	        echo json_encode (array ('success' => true, 
	        						 'message' => $this->lang->line ('common_change_successful')));
        }
        else
        {
        	//
        	// Return a JSON-encoded message with the error description
        	//
        	echo json_encode (array ('success' => false, 
        							 'message' => $errors));
        }
    }
}

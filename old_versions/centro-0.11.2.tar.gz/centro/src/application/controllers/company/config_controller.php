<?php
require_once (APPPATH . '/controllers/secure_area.php');

/**
 * This class is the entry point of the items package.
 * 
 * @author Matjaz Cepar
 *
 */
class Config_controller extends Secure_area
{
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_link_content_template ( )
    {
        $ret_value = array ('links' => array ( ));
        
        //
        // General page data
        //
        $ret_value['page_title'] = $this->lang->line ('common_select_submodule');

        //
        // Company link
        //
        $link_data = array ( );
        
        $link_data['link'] = site_url ('company/company_controller');
        $link_data['text'] = $this->lang->line ('config_company_page_title');
        
        array_push ($ret_value['links'], $link_data);
        
        //
        // Export link
        //
        $link_data = array ( );
        
        $link_data['link'] = site_url ('export-import/export_controller');
        $link_data['text'] = $this->lang->line ('export');
        
        array_push ($ret_value['links'], $link_data);
        
        //
        // Import link
        //
        $link_data = array ( );
        
        $link_data['link'] = site_url ('export-import/import_controller');
        $link_data['text'] = $this->lang->line ('import');;
        
        array_push ($ret_value['links'], $link_data);
        
        return $ret_value;
    }

    
	/**
	 * Constructor
	 */
	function __construct ( )
	{
		parent::__construct  ('config');
		
		$this->load->library ('parser');
	}
	
	
	/**
     * The default entry point of this controller.-
     */
	public function index ( )
	{
	    //
        // Prepare the navigation stack to work inside this module
        //
        $this->navigation_stack->clear_stack ( );
        $this->navigation_stack->push ( );
    	
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['module_name']         = $this->lang->line ('module_config');
	    
        //
        // Fill the page templates with data
        //
	    $page_content = $this->_build_link_content_template ( );
	    
	    $data['content'] = $this->parser->parse ('entry_view', 
        										 $page_content,
        										 true);
        //
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
	}
}

?>
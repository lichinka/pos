<?php
require_once(APPPATH . '/controllers/test/Toast.php');

/**
 * This class tests the persons model.
 * @author Matjaz Cepar
 *
 */
class Persons_model extends Toast
{
    private function module_model_test ($module)
    {
        $success = true;

        $success = $success && $this->_assert_equals ($module->id, '2');
        $success = $success && $this->_assert_equals ($module->name, 'config');
        $success = $success && $this->_assert_equals ($module->name_lang_key, 'module_config');
        $success = $success && $this->_assert_equals ($module->desc_lang_key, 'module_config_desc');
        $success = $success && $this->_assert_equals ($module->sort, '7');

        return $success;
    }

    function __construct ( )
    {
        parent::Toast (__FILE__);
    }

    function test_customer ( )
    {
        $this->_assert_true(false);
        $this->message = 'Implement test case';
    }

    function test_employee ( )
    {
        $this->_assert_true(false);
        $this->message = 'Implement test case';
    }

    function test_module ( )
    {
        $this->load->model ('persons/module');

        // get a valid module
        $module = $this->module->get_by_id (2);
        if (!$this->module_model_test ($module))
        {
            $this->message = 'Get by id failed';
            return;
        }

        // get null
        $module = $this->module->get_by_id ( );
        if (!$this->_assert_equals ($module, NULL))
        {
            $this->message = 'Get by id failed';
            return;
        }

        // get null
        $module = $this->module->get_by_id (-1);
        if (!$this->_assert_equals ($module, NULL))
        {
            $this->message = 'Get by id failed';
            return;
        }


        // test get_all
        $modules = $this->module->get_all ( );
        if (!$this->_assert_equals (count ($modules), 6))
        {
            $this->message = 'Get all failed';
            return;
        }
        foreach ($modules as $module)
        {
            if ($module->id == '2')
            {
                if (!$this->module_model_test ($module))
                {
                    $this->message = 'Get all failed';
                    return;
                }
            }
        }


        // test exists
        $exists = $this->module->exists (2);
        if (!$this->_assert_true ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        $exists = $this->module->exists (-1);
        if (!$this->_assert_false ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }


        $instance = new Module (2);
        $exists = $instance->exists ( );
        if (!$this->_assert_true ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        $instance = new Module (-1);
        $exists = $instance->exists ( );
        if (!$this->_assert_false ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        // test get_active
        // the test case assumes, that the active terminal has all modules
        $modules = $this->module->get_active ( );
        if (!$this->_assert_equals (count ($modules), 6))
        {
            $this->message = ('Get distinct failed');
            return;
        }
    }
}
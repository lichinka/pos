<?php

/**
 * This class tests the items model.
 * @author Matjaz Cepar
 *
 */
class Test_items extends Controller
{
    function __construct ( )
    {
        parent::Controller ( );
    }

    function index ( )
    {
        echo ("Starting the items package test case\n");
        	
        echo ("\tTesting item model\n");
        $this->load->model ('items/item');
        	
        $a = $this->item->get_by_id (1);
        $b = $this->item->get_by_id ( );
        $c = $this->item->get_by_id (-1);
        	
        $d = $this->item->get_all ( );

        $e = $this->item->get_by_barcode ('0000-0001');
        $f = $this->item->get_by_barcode ('   0000-0001');
        $g = $this->item->get_by_barcode ('0000-0001   ');

        unset ($a, $b, $c, $d, $e, $f, $g);
        echo ("\tDone\n");

        echo ("\tTesting size group model\n");
        $this->load->model ('items/size_group');
        	
        $a = $this->size_group->get_by_id (1);
        $b = $this->size_group->get_by_id ( );
        $c = $this->size_group->get_by_id (-1);
        	
        $d = $this->size_group->get_all ( );

        unset ($a, $b, $c, $d);
        echo ("\tDone\n");

        echo ("\tTesting size model\n");
        $this->load->model ('items/size');
        	
        $a = $this->size->get_by_id (1);
        $b = $this->size->get_by_id ( );
        $c = $this->size->get_by_id (-1);
        	
        $d = $this->size->get_all ( );

        unset ($a, $b, $c, $d);
        echo ("\tDone\n");

        echo ("\tTesting category model\n");
        $this->load->model ('items/category');
        	
        $a = $this->category->get_by_id (1);
        $b = $this->category->get_by_id ( );
        $c = $this->category->get_by_id (-1);
        	
        $d = $this->category->get_all ( );

        $e = $this->category->get_by_name ('Majce');
        $f = $this->category->get_by_name ('mAjCe');
        $g = $this->category->get_by_name ('Majce      ');
        $h = $this->category->get_by_name ('  Majce');

        unset ($a, $b, $c, $d, $e, $f, $g, $h);
        echo ("\tDone\n");

        echo ("\tTesting tax model\n");
        $this->load->model ('items/tax');
        	
        $a = $this->tax->get_by_id (1);
        $b = $this->tax->get_by_id ( );
        $c = $this->tax->get_by_id (-1);
        	
        $d = $this->tax->get_all ( );

        unset ($a, $b, $c, $d);
        echo ("\tDone\n");
        	
        echo ("Done\n");
    }
}
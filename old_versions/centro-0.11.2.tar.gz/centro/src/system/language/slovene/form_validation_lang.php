<?php

$lang['required'] 			= "Polje `%s` je obvezno.";
$lang['isset']				= "Polje `%s` ne sme bit prazno.";
$lang['valid_email']		= "Polje `%s` ne vsebuje pravilnega e-mail naslova.";
$lang['valid_emails'] 		= "Vsi podatki v polju `%s` morajo biti pravilen e-mail naslov.";
$lang['valid_url'] 			= "Oblika naslova v polju `%s` ni pravilna.";
$lang['valid_ip'] 			= "Oblika naslova v polju `%s` ni pravilna.";
$lang['min_length']			= "Polje `%s` ne sme biti krajše od %s znakov.";
$lang['max_length']			= "Polje `%s` ne sme biti daljše od %s znakov.";
$lang['exact_length']		= "Polje `%s` mora biti dolgo natanko %s znakov.";
$lang['alpha']				= "Polje `%s` lahko vsebuje le črke.";
$lang['alpha_numeric']		= "Polje `%s` lahko vsebuje le črke in številke.";
$lang['alpha_dash']			= "Polje `%s` lahko vsebuje le črke, številke, podčrtaje in pomišljaje.";
$lang['numeric']			= "Polje `%s` lahko vsebuje le številke.";
$lang['is_numeric']			= "Polje `%s` lahko vsebuje le cifre.";
$lang['integer']			= "Polje `%s` mora biti celo število.";
$lang['matches']			= "Polji `%s` in `%s` se ne ujemata.";
$lang['is_natural']			= "Polje `%s` lahko vsebuje le pozitivna števila.";
$lang['is_natural_no_zero']	= "Polje `%s` lahko vsebuje le števila večja od 0.";


/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */
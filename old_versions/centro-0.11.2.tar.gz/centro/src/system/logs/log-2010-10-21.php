<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-21 11:45:30 --> Query error: Table 'centro.centro_1' doesn't exist
ERROR - 2010-10-21 11:46:26 --> Query error: Table 'centro.centro_1' doesn't exist
ERROR - 2010-10-21 13:01:33 --> Query error: Duplicate entry '1-2' for key 'PRIMARY'
ERROR - 2010-10-21 13:17:08 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 365
ERROR - 2010-10-21 13:17:10 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 365
ERROR - 2010-10-21 13:17:47 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:49 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:49 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:49 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:50 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:50 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:50 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:50 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:50 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:50 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:50 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:51 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:51 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:51 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:53 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:53 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:53 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:53 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:17:54 --> Severity: Notice  --> Undefined variable: site_url /home/luka/etc/saion/centro/application/controllers/sales_controller.php 366
ERROR - 2010-10-21 13:19:25 --> 404 Page Not Found --> add_item_to_sale
ERROR - 2010-10-21 13:21:31 --> 404 Page Not Found --> add_item_to_sale
ERROR - 2010-10-21 13:27:12 --> Query error: Duplicate entry '1-1' for key 'PRIMARY'

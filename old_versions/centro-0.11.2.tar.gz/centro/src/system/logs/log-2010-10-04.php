<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-04 10:10:57 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to local MySQL server through socket '/var/run/mysqld/mysqld.sock' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-10-04 10:10:57 --> Unable to connect to the database
ERROR - 2010-10-04 10:14:07 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'garufa'@'localhost' (using password: YES) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-10-04 10:14:07 --> Unable to connect to the database
ERROR - 2010-10-04 10:14:09 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'garufa'@'localhost' (using password: YES) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-10-04 10:14:09 --> Unable to connect to the database
ERROR - 2010-10-04 10:14:10 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'garufa'@'localhost' (using password: YES) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-10-04 10:14:10 --> Unable to connect to the database
ERROR - 2010-10-04 11:31:35 --> Severity: Notice  --> Undefined variable: store /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 24
ERROR - 2010-10-04 19:05:47 --> 404 Page Not Found --> items_controller
ERROR - 2010-10-04 19:05:47 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-26 16:50:35 --> Config Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Hooks Class Initialized
DEBUG - 2010-07-26 16:50:35 --> URI Class Initialized
DEBUG - 2010-07-26 16:50:35 --> No URI present. Default controller set.
DEBUG - 2010-07-26 16:50:35 --> Router Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Output Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Input Class Initialized
DEBUG - 2010-07-26 16:50:35 --> XSS Filtering completed
DEBUG - 2010-07-26 16:50:35 --> XSS Filtering completed
DEBUG - 2010-07-26 16:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-26 16:50:35 --> Language Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Loader Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Helper loaded: form_helper
DEBUG - 2010-07-26 16:50:35 --> Helper loaded: url_helper
DEBUG - 2010-07-26 16:50:35 --> Helper loaded: table_helper
DEBUG - 2010-07-26 16:50:35 --> Helper loaded: text_helper
DEBUG - 2010-07-26 16:50:35 --> Helper loaded: currency_helper
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-07-26 16:50:35 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-07-26 16:50:35 --> Database Driver Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Session Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Helper loaded: string_helper
DEBUG - 2010-07-26 16:50:35 --> Encrypt Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Session routines successfully run
DEBUG - 2010-07-26 16:50:35 --> User Agent Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Controller Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Form Validation Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:35 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:35 --> File loaded: application/views/login.php
DEBUG - 2010-07-26 16:50:35 --> Final output sent to browser
DEBUG - 2010-07-26 16:50:35 --> Total execution time: 0.0199
DEBUG - 2010-07-26 16:50:40 --> Config Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Hooks Class Initialized
DEBUG - 2010-07-26 16:50:40 --> URI Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Router Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Output Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Input Class Initialized
DEBUG - 2010-07-26 16:50:40 --> XSS Filtering completed
DEBUG - 2010-07-26 16:50:40 --> XSS Filtering completed
DEBUG - 2010-07-26 16:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-26 16:50:40 --> Language Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Loader Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Helper loaded: form_helper
DEBUG - 2010-07-26 16:50:40 --> Helper loaded: url_helper
DEBUG - 2010-07-26 16:50:40 --> Helper loaded: table_helper
DEBUG - 2010-07-26 16:50:40 --> Helper loaded: text_helper
DEBUG - 2010-07-26 16:50:40 --> Helper loaded: currency_helper
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-07-26 16:50:40 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-07-26 16:50:40 --> Database Driver Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Session Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Helper loaded: string_helper
DEBUG - 2010-07-26 16:50:40 --> Encrypt Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Session routines successfully run
DEBUG - 2010-07-26 16:50:40 --> User Agent Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Controller Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Form Validation Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:40 --> File loaded: application/views/touch_login.php
DEBUG - 2010-07-26 16:50:40 --> Final output sent to browser
DEBUG - 2010-07-26 16:50:40 --> Total execution time: 0.0251
DEBUG - 2010-07-26 16:50:55 --> Config Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Hooks Class Initialized
DEBUG - 2010-07-26 16:50:55 --> URI Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Router Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Output Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Input Class Initialized
DEBUG - 2010-07-26 16:50:55 --> XSS Filtering completed
DEBUG - 2010-07-26 16:50:55 --> XSS Filtering completed
DEBUG - 2010-07-26 16:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-26 16:50:55 --> Language Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Loader Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Helper loaded: form_helper
DEBUG - 2010-07-26 16:50:55 --> Helper loaded: url_helper
DEBUG - 2010-07-26 16:50:55 --> Helper loaded: table_helper
DEBUG - 2010-07-26 16:50:55 --> Helper loaded: text_helper
DEBUG - 2010-07-26 16:50:55 --> Helper loaded: currency_helper
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-07-26 16:50:55 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-07-26 16:50:55 --> Database Driver Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Session Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Helper loaded: string_helper
DEBUG - 2010-07-26 16:50:55 --> Encrypt Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Session routines successfully run
DEBUG - 2010-07-26 16:50:55 --> User Agent Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Controller Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Form Validation Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> Model Class Initialized
DEBUG - 2010-07-26 16:50:55 --> File loaded: application/views/touch_login.php
DEBUG - 2010-07-26 16:50:55 --> Final output sent to browser
DEBUG - 2010-07-26 16:50:55 --> Total execution time: 0.0276
DEBUG - 2010-07-26 16:51:11 --> Config Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Hooks Class Initialized
DEBUG - 2010-07-26 16:51:11 --> URI Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Router Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Output Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Input Class Initialized
DEBUG - 2010-07-26 16:51:11 --> XSS Filtering completed
DEBUG - 2010-07-26 16:51:11 --> XSS Filtering completed
DEBUG - 2010-07-26 16:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-26 16:51:11 --> Language Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Loader Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Helper loaded: form_helper
DEBUG - 2010-07-26 16:51:11 --> Helper loaded: url_helper
DEBUG - 2010-07-26 16:51:11 --> Helper loaded: table_helper
DEBUG - 2010-07-26 16:51:11 --> Helper loaded: text_helper
DEBUG - 2010-07-26 16:51:11 --> Helper loaded: currency_helper
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-07-26 16:51:11 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-07-26 16:51:11 --> Database Driver Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Session Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Helper loaded: string_helper
DEBUG - 2010-07-26 16:51:11 --> Encrypt Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Session routines successfully run
DEBUG - 2010-07-26 16:51:11 --> User Agent Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Controller Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Form Validation Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> Model Class Initialized
DEBUG - 2010-07-26 16:51:11 --> File loaded: application/views/touch_login.php
DEBUG - 2010-07-26 16:51:11 --> Final output sent to browser
DEBUG - 2010-07-26 16:51:11 --> Total execution time: 0.0782
ERROR - 2010-07-26 16:52:28 --> index ( )
ERROR - 2010-07-26 16:52:32 --> index ( )
ERROR - 2010-07-26 16:53:02 --> Employee NOT logged in!
ERROR - 2010-07-26 17:06:33 --> I am here!
ERROR - 2010-07-26 17:09:23 --> I am here!
ERROR - 2010-07-26 17:09:26 --> I am here!
ERROR - 2010-07-26 17:09:47 --> USR admin
ERROR - 2010-07-26 17:10:04 --> USR admin
ERROR - 2010-07-26 17:10:04 --> PAS 
ERROR - 2010-07-26 17:10:18 --> USR admin
ERROR - 2010-07-26 17:10:18 --> PAS 
ERROR - 2010-07-26 17:10:43 --> USR admin
ERROR - 2010-07-26 17:10:43 --> PAS 2
ERROR - 2010-07-26 17:10:45 --> USR admin
ERROR - 2010-07-26 17:10:45 --> PAS 3
ERROR - 2010-07-26 17:10:48 --> USR admin
ERROR - 2010-07-26 17:10:48 --> PAS 5
ERROR - 2010-07-26 17:17:07 --> 404 Page Not Found --> login/index
ERROR - 2010-07-26 17:17:19 --> 404 Page Not Found --> login/index
ERROR - 2010-07-26 17:20:58 --> 404 Page Not Found --> categories

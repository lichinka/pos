<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-03 17:56:55 --> Severity: Notice  --> Undefined variable: content /home/luka/etc/saion/centro/application/views/config.php 22
ERROR - 2010-10-03 17:56:55 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/modules.php 12
ERROR - 2010-10-03 17:57:16 --> Severity: Notice  --> Undefined variable: content /home/luka/etc/saion/centro/application/views/config.php 22
ERROR - 2010-10-03 17:57:16 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/modules.php 12
ERROR - 2010-10-03 17:57:19 --> Severity: Notice  --> Undefined variable: content /home/luka/etc/saion/centro/application/views/config.php 22
ERROR - 2010-10-03 17:57:19 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/modules.php 12

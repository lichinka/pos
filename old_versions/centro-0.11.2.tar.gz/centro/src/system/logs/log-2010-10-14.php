<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-14 09:38:09 --> Severity: Notice  --> Undefined offset: 10 /home/luka/etc/saion/centro/application/libraries/navigation_stack.php 238
ERROR - 2010-10-14 12:41:28 --> Severity: Notice  --> Undefined variable: buttons /home/luka/etc/saion/centro/application/views/partial/footer.php 4
ERROR - 2010-10-14 17:32:47 --> 404 Page Not Found --> javascript:void &#40; &#41;

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-18 09:38:49 --> Query error: Table 'centro.centro_terminal' doesn't exist
ERROR - 2010-10-18 10:43:00 --> Severity: Warning  --> array_push() [<a href='function.array-push'>function.array-push</a>]: First argument should be an array /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 75
ERROR - 2010-10-18 10:43:00 --> Severity: Warning  --> array_push() [<a href='function.array-push'>function.array-push</a>]: First argument should be an array /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 75
ERROR - 2010-10-18 10:43:00 --> Severity: Warning  --> array_push() [<a href='function.array-push'>function.array-push</a>]: First argument should be an array /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 75
ERROR - 2010-10-18 10:43:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/system/libraries/Parser.php 131
ERROR - 2010-10-18 10:43:22 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:43:22 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:43:22 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:52:21 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:52:21 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:52:21 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:55:53 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:55:53 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:55:53 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:55:55 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:55:55 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 10:55:55 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Compilation failed: nothing to repeat at offset 2 /home/luka/etc/saion/centro/system/libraries/Parser.php 161
ERROR - 2010-10-18 11:07:28 --> Severity: Notice  --> Undefined offset:  0 /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 34
ERROR - 2010-10-18 11:12:55 --> Severity: Notice  --> Undefined offset:  0 /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 35
ERROR - 2010-10-18 11:39:42 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminal` (`terminal_id`))
ERROR - 2010-10-18 11:39:46 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminal` (`terminal_id`))
ERROR - 2010-10-18 11:39:59 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminal` (`terminal_id`))
ERROR - 2010-10-18 11:41:31 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminal` (`terminal_id`))
ERROR - 2010-10-18 11:51:10 --> Severity: Warning  --> Missing argument 2 for Terminal_controller::_build_edit_content_template(), called in /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php on line 406 and defined /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 143
ERROR - 2010-10-18 11:51:10 --> Severity: Notice  --> Undefined variable: store /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 208
ERROR - 2010-10-18 11:51:10 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 208
ERROR - 2010-10-18 12:54:50 --> 404 Page Not Found --> config
ERROR - 2010-10-18 12:55:25 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminal`, CONSTRAINT `centro_terminal_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_store` (`store_id`))
ERROR - 2010-10-18 12:55:35 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminal`, CONSTRAINT `centro_terminal_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_store` (`store_id`))
ERROR - 2010-10-18 12:55:53 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminal`, CONSTRAINT `centro_terminal_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_store` (`store_id`))
ERROR - 2010-10-18 12:55:54 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminal`, CONSTRAINT `centro_terminal_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_store` (`store_id`))
ERROR - 2010-10-18 12:56:44 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 210
ERROR - 2010-10-18 13:00:41 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 210
ERROR - 2010-10-18 13:01:26 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 210
ERROR - 2010-10-18 13:07:11 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminal`, CONSTRAINT `centro_terminal_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_store` (`store_id`))
ERROR - 2010-10-18 13:08:20 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminal`, CONSTRAINT `centro_terminal_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_store` (`store_id`))
ERROR - 2010-10-18 13:08:21 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminal`, CONSTRAINT `centro_terminal_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_store` (`store_id`))
ERROR - 2010-10-18 14:37:50 --> Severity: Notice  --> Undefined variable: content /home/luka/etc/saion/centro/application/views/company/table_terminals.php 23
ERROR - 2010-10-18 14:37:55 --> Severity: Notice  --> Undefined variable: content /home/luka/etc/saion/centro/application/views/company/table_terminals.php 23
ERROR - 2010-10-18 14:38:07 --> Severity: Notice  --> Undefined variable: content /home/luka/etc/saion/centro/application/views/company/table_terminals.php 23
ERROR - 2010-10-18 14:50:55 --> 404 Page Not Found --> reports_controller
ERROR - 2010-10-18 14:50:55 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-10-18 15:05:09 --> Severity: Warning  --> array_push() expects parameter 1 to be array, null given /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 95
ERROR - 2010-10-18 15:05:28 --> Severity: Warning  --> array_push() expects parameter 1 to be array, null given /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 94
ERROR - 2010-10-18 15:05:38 --> Severity: Warning  --> array_push() expects parameter 1 to be array, null given /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 94
ERROR - 2010-10-18 15:07:18 --> Severity: Notice  --> Undefined variable: field_data /home/luka/etc/saion/centro/application/controllers/company/terminal_controller.php 95
ERROR - 2010-10-18 15:26:14 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 244
ERROR - 2010-10-18 15:44:27 --> 404 Page Not Found --> sales_controller
ERROR - 2010-10-18 15:44:27 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-10-18 20:35:03 --> 404 Page Not Found --> sales_controller
ERROR - 2010-10-18 20:35:03 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-10-18 20:49:35 --> 404 Page Not Found --> sales
ERROR - 2010-10-18 20:49:35 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-10-18 20:49:45 --> 404 Page Not Found --> sales
ERROR - 2010-10-18 20:49:45 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-17 11:37:59 --> 404 Page Not Found --> items_controller
ERROR - 2010-10-17 11:38:24 --> 404 Page Not Found --> reports_controller
ERROR - 2010-10-17 11:38:29 --> 404 Page Not Found --> sales_controller
ERROR - 2010-10-17 14:59:05 --> Severity: Notice  --> Undefined variable: company /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 158
ERROR - 2010-10-17 14:59:05 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 158
ERROR - 2010-10-17 14:59:05 --> Severity: Notice  --> Undefined variable: template /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 423
ERROR - 2010-10-17 14:59:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/system/libraries/Parser.php 55
ERROR - 2010-10-17 14:59:05 --> Severity: Notice  --> Undefined variable: template /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 427
ERROR - 2010-10-17 15:02:17 --> Severity: Notice  --> Undefined variable: company /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 158
ERROR - 2010-10-17 15:02:17 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 158
ERROR - 2010-10-17 15:02:17 --> Severity: Notice  --> Undefined variable: template /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 423
ERROR - 2010-10-17 15:02:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/system/libraries/Parser.php 55
ERROR - 2010-10-17 15:02:17 --> Severity: Notice  --> Undefined variable: template /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 427
ERROR - 2010-10-17 15:02:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/system/libraries/Parser.php 55
ERROR - 2010-10-17 15:03:25 --> Severity: Notice  --> Undefined variable: template /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 423
ERROR - 2010-10-17 15:03:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/system/libraries/Parser.php 55
ERROR - 2010-10-17 15:03:25 --> Severity: Notice  --> Undefined variable: template /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 427
ERROR - 2010-10-17 15:03:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/system/libraries/Parser.php 55
ERROR - 2010-10-17 15:04:13 --> Severity: Notice  --> Undefined variable: template /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 423
ERROR - 2010-10-17 15:04:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/system/libraries/Parser.php 55
ERROR - 2010-10-17 15:04:13 --> Severity: Notice  --> Undefined variable: template /home/luka/etc/saion/centro/application/controllers/company/store_controller.php 427
ERROR - 2010-10-17 15:04:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/system/libraries/Parser.php 55

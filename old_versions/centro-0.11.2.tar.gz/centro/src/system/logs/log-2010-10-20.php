<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-20 10:45:05 --> 404 Page Not Found --> sales
ERROR - 2010-10-20 13:16:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales`, CONSTRAINT `centro_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `centro_customers` (`person_id`))
ERROR - 2010-10-20 13:17:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS item_price
FROM (`centro_sales_items`)
WHERE `sale_id` =' at line 1
ERROR - 2010-10-20 13:18:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '\
 item_unit_price AS item_price
FROM (centro_sales_items)
WHERE `sale_id` =' at line 1
ERROR - 2010-10-20 13:19:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-10-20 13:20:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-10-20 13:20:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-10-20 13:23:09 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/sale.php 49
ERROR - 2010-10-20 13:23:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-10-20 13:23:35 --> Severity: Notice  --> Undefined index:  quantity /home/luka/etc/saion/centro/application/controllers/sales_controller.php 72
ERROR - 2010-10-20 13:23:35 --> Severity: Notice  --> Undefined index:  item_price /home/luka/etc/saion/centro/application/controllers/sales_controller.php 73
ERROR - 2010-10-20 13:23:35 --> Severity: Notice  --> Undefined property: Sales_controller::$parser /home/luka/etc/saion/centro/application/controllers/sales_controller.php 215
ERROR - 2010-10-20 13:23:58 --> Severity: Notice  --> Undefined property: Sales_controller::$parser /home/luka/etc/saion/centro/application/controllers/sales_controller.php 215
ERROR - 2010-10-20 19:14:04 --> Severity: Notice  --> Undefined index:   /home/luka/etc/saion/centro/application/controllers/sales_controller.php 103
ERROR - 2010-10-20 19:17:25 --> Query error: Column 'sale_id' in where clause is ambiguous

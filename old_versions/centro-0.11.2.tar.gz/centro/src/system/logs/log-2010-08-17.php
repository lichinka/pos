<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-08-17 17:31:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/models/persons/employee.php 166
ERROR - 2010-08-17 17:31:59 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-08-17 17:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-08-17 17:31:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-08-17 17:31:59 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 53
ERROR - 2010-08-17 17:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/views/partial/header.php 53
ERROR - 2010-08-17 17:31:59 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 53
ERROR - 2010-08-17 17:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/views/partial/header.php 53
ERROR - 2010-08-17 17:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/models/persons/employee.php 166
ERROR - 2010-08-17 17:32:00 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-08-17 17:32:00 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-08-17 17:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-08-17 17:32:00 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 53
ERROR - 2010-08-17 17:32:00 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/views/partial/header.php 53
ERROR - 2010-08-17 17:32:00 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 53
ERROR - 2010-08-17 17:32:00 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/views/partial/header.php 53
ERROR - 2010-08-17 17:32:00 --> 404 Page Not Found --> images
ERROR - 2010-08-17 17:36:54 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-08-17 17:37:40 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-08-17 17:43:35 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-08-17 18:04:59 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21

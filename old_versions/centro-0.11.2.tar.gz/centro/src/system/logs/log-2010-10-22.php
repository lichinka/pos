<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-22 11:52:23 --> 404 Page Not Found --> test_pdf
ERROR - 2010-10-22 17:35:55 --> Severity: Notice  --> Undefined property: Sale::$sale_detail /home/luka/etc/saion/centro/application/models/sales/sale.php 269
ERROR - 2010-10-22 18:25:30 --> Severity: Notice  --> Undefined property: Sale::$sale_detail /home/luka/etc/saion/centro/application/models/sales/sale.php 282
ERROR - 2010-10-22 18:27:50 --> Severity: Notice  --> Undefined property: Sale::$sale_detail /home/luka/etc/saion/centro/application/models/sales/sale.php 282
ERROR - 2010-10-22 18:28:21 --> Severity: Notice  --> Undefined property: Sale::$foo /home/luka/etc/saion/centro/application/models/sales/sale.php 282
ERROR - 2010-10-22 18:29:18 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale_detail.php 186
ERROR - 2010-10-22 18:29:18 --> Severity: Notice  --> Undefined property: Sale_detail::$sale_detail_tax /home/luka/etc/saion/centro/application/models/sales/sale_detail.php 191
ERROR - 2010-10-22 18:30:21 --> Severity: Notice  --> Undefined property: Sale::$foo /home/luka/etc/saion/centro/application/models/sales/sale.php 282
ERROR - 2010-10-22 18:30:38 --> Severity: Notice  --> Undefined property: Sale::$sale_detail /home/luka/etc/saion/centro/application/models/sales/sale.php 282
ERROR - 2010-10-22 18:34:37 --> Severity: Notice  --> Undefined property: Sale::$sale_detail /home/luka/etc/saion/centro/application/models/sales/sale.php 282
ERROR - 2010-10-22 18:35:56 --> Severity: Notice  --> Undefined property: Sale::$sale_detail /home/luka/etc/saion/centro/application/models/sales/sale.php 282
ERROR - 2010-10-22 18:37:34 --> Severity: Notice  --> Undefined property: Sale::$fubar /home/luka/etc/saion/centro/application/models/sales/sale.php 280
ERROR - 2010-10-22 18:40:39 --> 404 Page Not Found --> index.php
ERROR - 2010-10-22 18:40:49 --> 404 Page Not Found --> index.php
ERROR - 2010-10-22 18:40:53 --> 404 Page Not Found --> index.php
ERROR - 2010-10-22 18:40:53 --> 404 Page Not Found --> index.php
ERROR - 2010-10-22 18:41:01 --> 404 Page Not Found --> index.php
ERROR - 2010-10-22 18:42:37 --> Severity: Notice  --> Undefined property: Sale::$fubar /home/luka/etc/saion/centro/application/models/sales/sale.php 280
ERROR - 2010-10-22 19:00:21 --> Severity: Notice  --> Undefined property: Sale::$fubar /home/luka/etc/saion/centro/application/models/sales/sale.php 280
ERROR - 2010-10-22 19:00:52 --> Severity: Notice  --> Undefined property: Sale::$fubar /home/luka/etc/saion/centro/application/models/sales/sale.php 280
ERROR - 2010-10-22 19:00:53 --> Severity: Notice  --> Undefined property: Sale::$fubar /home/luka/etc/saion/centro/application/models/sales/sale.php 280
ERROR - 2010-10-22 19:02:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 73
ERROR - 2010-10-22 19:02:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 73
ERROR - 2010-10-22 19:02:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 73
ERROR - 2010-10-22 21:12:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 73
ERROR - 2010-10-22 21:12:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 73
ERROR - 2010-10-22 21:12:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 73
ERROR - 2010-10-22 21:12:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 73
ERROR - 2010-10-22 21:12:41 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale_detail.php 186
ERROR - 2010-10-22 21:12:41 --> Severity: Notice  --> Undefined property: Sale_detail::$sale_detail_tax /home/luka/etc/saion/centro/application/models/sales/sale_detail.php 191
ERROR - 2010-10-22 21:17:11 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale_detail.php 187
ERROR - 2010-10-22 21:17:11 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale_detail.php 192
ERROR - 2010-10-22 21:17:11 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 75
ERROR - 2010-10-22 21:18:12 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale_detail.php 187
ERROR - 2010-10-22 21:18:12 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale_detail.php 192
ERROR - 2010-10-22 21:18:12 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 75
ERROR - 2010-10-22 21:19:44 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale_detail_tax.php 163
ERROR - 2010-10-22 21:25:12 --> Query error: Table 'centro.centro_sales_items' doesn't exist
ERROR - 2010-10-22 22:03:18 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:03:18 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:09:47 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:09:47 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:10:10 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:10:10 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:10:14 --> 404 Page Not Found --> sales_controller/save
ERROR - 2010-10-22 22:10:22 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:10:22 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:10:28 --> 404 Page Not Found --> sales_controller/save
ERROR - 2010-10-22 22:11:03 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:11:03 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:11:06 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:11:06 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:19:48 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:19:48 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:19:50 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:19:50 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:19:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:20:12 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:20:12 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:20:18 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:20:23 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:20:23 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:21:03 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:21:03 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:21:04 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:21:04 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:21:55 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:22:50 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:24:04 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:24:04 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:28:08 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:28:08 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:28:19 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:30:49 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:30:49 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:31:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:31:27 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:31:27 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:31:36 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:33:17 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:33:17 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:33:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:34:11 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:34:11 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:34:39 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:38:18 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 22:39:40 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:39:40 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:42:38 --> Severity: Notice  --> Undefined variable: errors /home/luka/etc/saion/centro/application/controllers/sales_controller.php 342
ERROR - 2010-10-22 22:45:25 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:45:25 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:46:41 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:46:41 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:49:58 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:49:58 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:51:17 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:51:17 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:52:43 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 22:52:43 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 22:52:49 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 23:06:23 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:06:23 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:06:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 23:06:42 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:06:42 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:07:47 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `centro_sales` (`sale_id`))
ERROR - 2010-10-22 23:11:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details`, CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`))
ERROR - 2010-10-22 23:12:41 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:12:41 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:16:57 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:16:57 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:17:56 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:17:56 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:18:12 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:18:12 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:18:48 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:18:48 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:19:39 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:19:39 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:21:20 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:21:20 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:21:37 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:21:37 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:23:03 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:23:03 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:23:44 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:23:44 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-22 23:24:11 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-22 23:24:11 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20

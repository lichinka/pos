<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-11-08 15:05:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-11-08 15:10:29 --> Severity: Notice  --> Undefined variable: module_name /home/luka/etc/saion/centro/application/views/skeleton.php 13
ERROR - 2010-11-08 15:24:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-11-08 15:26:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-11-08 15:27:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-11-08 15:38:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
ERROR - 2010-11-08 16:13:00 --> Query error: Duplicate entry '-1' for key 'PRIMARY'
ERROR - 2010-11-08 16:17:48 --> Query error: Duplicate entry '-1' for key 'PRIMARY'
ERROR - 2010-11-08 16:19:00 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminals`, CONSTRAINT `centro_terminals_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_stores` (`store_id`))
ERROR - 2010-11-08 16:19:05 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminals`, CONSTRAINT `centro_terminals_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_stores` (`store_id`))
ERROR - 2010-11-08 16:19:08 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminals`, CONSTRAINT `centro_terminals_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_stores` (`store_id`))
ERROR - 2010-11-08 16:19:12 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminals`, CONSTRAINT `centro_terminals_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_stores` (`store_id`))
ERROR - 2010-11-08 16:20:29 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminals`, CONSTRAINT `centro_terminals_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_stores` (`store_id`))
ERROR - 2010-11-08 16:24:07 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_terminals`, CONSTRAINT `centro_terminals_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_stores` (`store_id`))
ERROR - 2010-11-08 16:32:59 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 16:33:01 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 16:33:03 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 16:33:04 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 17:51:37 --> Query error: Table 'centro.centro_terminals' doesn't exist
ERROR - 2010-11-08 17:51:38 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:19:12 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:19:12 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:19:15 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:19:15 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:19:15 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:19:15 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:19:16 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:19:16 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:19:16 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:19:16 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:19:46 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:19:46 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:19:47 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:19:47 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:22:27 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:22:27 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-11-08 18:22:29 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_app_config`, CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`))
ERROR - 2010-11-08 18:22:29 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111

/**
 * Listener function, if a user was selected.-
 * 
 * @param event		The event DOM object.-
 * @param user_name	The username that should be appended as form data.-
 * @param form  	A form DOM object that will be appended the username.-
 */
function user_selected (event, user_name, form)
{
	//
	// This is the object that triggered the event
	//
	source_object = event.target;
	
	//
	// Check that this object has an ID
	//
	if (!source_object.id)
	{
		//
		// No ID. This means that the user clicked
		// on the IMG element instead of the A one.
		//
		source_object = source_object.parentNode;
	}

	//
	// Check (again) that this object has an ID
	//
	if (source_object.id)
	{
		//
		// Hide all A elements that didn't trigger the event
		// (i.e. hide all non-selected users)
		//
		var selector = "a:not('#" + source_object.id + "')";
		$(selector).css ("opacity", "0");

		//
		// Hide the welcome message and show the keypad
		//
		$('#welcome_panel').css ('z-index', '-1');
		$('#passwd_panel').css  ('z-index', '1');
		
		//
		// Append the username as a hidden input field
		//
		js_form = jQuery (form);
		
		js_form.append ('<input type="hidden" name="username" value="' + user_name + '"/>');
	}
		
	//
	// Don't let the browser redirect
	//
	return (false);
}



/**
 * Listener function, if a virtual key was pressed.-
 * 
 * @param event  The event DOM object.-
 * @param target A DOM object where the numbers (or actions) should
 * 				 be applied. It is usually an INPUT element.- 
 */
function keypad_pressed (event, target_element)
{
	//
	// This is the object that triggered the event
	//
	source_object = event.target;
	
	//
	// This is the element where the action should be applied
	//
	js_target = jQuery (target_element);

	
	//
	// Check if there is an action to be applied.
	// Else we will just change the content of the target_element.
	//
	switch (source_object.id)
	{
		case 'clear':
			//
			// Clear the content of the target element
			//
			js_target.val ('');
			break;
			
		default:
			//
			// Append the source_object's ID to the content
			//
			js_target.val (jQuery.trim (js_target.val ( )) + source_object.id);
	}
}


/**
 * Variables, that are currently hard-coded.
 * These are good candidates to be exported into a CSS file.
 *
var DIMENSION_UNIT = "px";
var KEYBOARD_WIDTH = "70";
var KEYBOARD_HEIGHT = "70";
var USERS_TOOLBAR_HEIGHT = "70";

/**
 * This the jQuery's fadeIn/Out speed
 *
var FADE_SPEED = "fast";

/**
 * This functions sets the starting state of the web page.
 * @return null
 *
$(document).ready(function()
{
	// initialize the users toolbar
	init_users_toolbar ( );

	// initialize the virutal keyboard
	init_virtual_keyboard ( );		
});

/**
 * Initializes the users toolbar.
 * @return null
 *
function init_users_toolbar ( )
{
	buttons = $(".user_button");
	scroll_buttons = $(".scroller");

	//start with no selected user, so disable the keyboard and password fields
	$('#selected_user').hide();
	
	//set all the same max length
	set_width(buttons);

	//add the event listeners to all users
	buttons.click (user_selected);
	
	
	// make scrollable and put all users into a single line
	// buttons are kept in the correct order, this is why it is done back to forth
	// it always keeps at least one button displayed
	for(i = buttons.length - 1; i > 0; i--)
	{	
		if (scroll_buttons[0].offsetTop != scroll_buttons[1].offsetTop)
		{
			$(buttons[i]).removeClass("visible").addClass("invisible");
		}
		else
		{
			break;
		}
	}
	
	//check, if the scroll buttons are needed and remove them otherwise
	if ($(".user_button.invisible").length == 0)
	{
		scroll_buttons.remove ( );
	}
	//set the correct dimensions
	else
	{
		scroll_buttons.height (USERS_TOOLBAR_HEIGHT + DIMENSION_UNIT);
	}
}

/**
 * Initializes the virtual keyboard.
 * @return null
 *
function init_virtual_keyboard ( )
{
	var keys = $('.key');

	//add the event listeners to the keys
	keys.click (key_pressed);

	//set the key sizes
	keys.width(KEYBOARD_WIDTH + DIMENSION_UNIT);
	keys.height(KEYBOARD_HEIGHT + DIMENSION_UNIT);

	//init the cancel button
	cancel_button = $('#cancel_button');
	cancel_button.click(cancel_user_selection);
	cancel_button.height(KEYBOARD_HEIGHT + DIMENSION_UNIT);
	cancel_button.width((2 * KEYBOARD_WIDTH) + DIMENSION_UNIT);

	//init the login button
	login_button = $('#login_button');
	login_button.click(login_button_pressed);
	login_button.height(KEYBOARD_HEIGHT + DIMENSION_UNIT);
	login_button.width((2 * KEYBOARD_WIDTH) + DIMENSION_UNIT);
}

/**
 * Scrolls the users toolbar left.
 * @return null
 *
function scroll_left ( )
{
	button = $(".invisible + .visible:first").prev ( );
	if (button.length != 0)
	{
		// hide the right-most visible button
		$(".user_button.visible:last").removeClass("visible").addClass("invisible");
		
		// show the previous button
		button.removeClass("invisible").addClass("visible");
	}
}



/**
 * Scrolls the users toolbar right.
 * @return null
 *
function scroll_right ( )
{
	button = $(".visible + .invisible:first");
	if (button.length != 0)
	{
		//hide the left-most visible button
		$(".user_button.visible:first").removeClass("visible").addClass("invisible");
		
		//show the next button
		button.removeClass("invisible").addClass("visible");
	}
}

/**
 * Sets all the users buttons to the width of the widest button.
 * @param buttons is a jQuery selection
 * @return null
 *
function set_width(buttons)
{
	buttons.height (USERS_TOOLBAR_HEIGHT + DIMENSION_UNIT);
	buttons.width (max_width(buttons));
}

/**
 * Returns the width of the widest button.
 * @param buttons is a jQuery selection.
 * @return the length (in pixels) of the longest button.
 *
function max_width(buttons)
{
	width = -1;
	buttons.each(function(i, button)
	{
		if ($(button).outerWidth() > width)
		{
			width = $(button).outerWidth ( );
		}
	});
	return width + DIMENSION_UNIT;
}

/**
 * Listener function, if a user was selected.
 * @param e is the event
 * @return null
 *
function user_selected (e)
{
	// hide the user
	$('#selected_user').fadeOut(FADE_SPEED, function () {
		// clear the password field
		$('#password')[0].value = "";
		
		// change the user label and id
		$('#user_label')[0].innerHTML = e.target.innerHTML;
		$('#user_id')[0].innerHTML    = e.target.id;
		$('#username')[0].value       = $('#user_label')[0].innerHTML;

		// show the user specific stuff
		$('#selected_user').fadeIn (FADE_SPEED);
	});
	
	
}



/**
 * Listener function, if the cancel button was pressed.
 * @param e is the event
 * @return null 
 *
function cancel_user_selection (e)
{
	//clear the password field
	$('#password')[0].value = "";
	
	// hide the virtual keyboard
	$('#selected_user').fadeOut(FADE_SPEED);
}

/**
 * Listener function, it the login button was pressed.
 * @param e is the event
 * @return null
 *
function login_button_pressed (e)
{
	//TODO
}


*/
/**
 * This function searches the received input by forwarding it
 * to the HREF specified by the source object.
 * If many elements are found, they are displayed in a list 
 * over a DIV specified as part of the JSON-encoded results
 * of the search. 
 * This function is called through the onClick event of anchors.-
 * 
 * @param event		The event DOM object.-
 * @param input	  	The input DOM object containing the searched string.-
 */
function search_element (event, input)
{
	//
	// This is the object that triggered the event
	//
	source_object = event.target;

	//
	// This is the string we have to look for ...
	//
	searched_text = input.value;
	
	//
	// Check that we received a valid target address
	//
	if (source_object.href)
	{
		//
		// Set up the request address
		//
		request_address = source_object.href + '/' + searched_text;
		
		//
		// Ask the controller to search the elements containing the requested string
		//
		$.get  (request_address,			// Target address to read from 
				'', 						// Data added to the requested address
				function (response)			// A callback function executed on success
				{
				   //
			       // How many elements did we find?
			       //
				   if (response.elements_found > 0)
				   {
					   //
					   // Display the success message (with fading)
					   //
				       set_feedback (response.message, false, true);

					   //
					   // If one exact match has been found, we must
				       // set the element found to the current sale
					   //
					   if (response.follow_address)
					   {
						   //
						   // Go there ...
						   //
 						   window.location = response.follow_address;
					   }
					   else
					   {
						   //
						   // Display the all matches found in the correct panel 
						   //
						   if (response.element_list)
						   {
							   $(response.element_list_panel).html (response.element_list);
						   }
						   else
						   {
							   //
							   // FIXME: What to do when we get here?
							   //
							   alert ("No elements received?");
						   }
					   }
				   }
				   else
				   {
					   //
					   // Display the non-success message (with fading)
					   //
				       set_feedback (response.message, true, true);
				   }
			    },
			    'json');					// The expected server response data type from the server		
	}
	
	//
	// Do not allow the anchor to redirect
	//
	return false;	
}

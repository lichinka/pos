/**
 * Displays a message on the lower part of the current 
 * page (i.e. the feedback bar). If the text parameter
 * is empty, any message that was previously displayed
 * is hidden.-
 * 
 * @param text				The text to be displayed.
 * @param is_error			Whether the text is an error message.
 * @param is_fading			Whether to display a fading animation of the message.
 */
function set_feedback (text, is_error, is_fading)
{
	//
	// The number of milliseconds a message should be displayed
	//
	var message_delay = 1000;
	
	//
	// Do we have anything to show?
	//
	if (text != '')
	{
		//
		// Are we goind to display an error message?
		//
		if (is_error)
		{
			//
			// Change the style to that of an error message
			//
			$('#feedback_bar').removeClass ( ).addClass ('error_message');
			message_delay = 3000;
		}
		else
		{
			//
			// Change the style to that of an information
			//
			$('#feedback_bar').removeClass ( ).addClass ('success_message');
			message_delay = 800;
		}
		
		//
		// Set the corresponding text to be displayed inside the <p> element
		//
		$("#feedback_bar p:first").text (text);
		
		//
		// Display the message on top of all other DIV elements
		//
		$('#feedback_bar').css ('z-index', '1');
		
		//
		// Leave the message displayed or make it slowly fade?
		//
		if (is_fading)
		{
			//
			// Make the message fade after 800 ms. We must make it
			// fade in (i.e. appear) again, otherwise it will stay
			// invisible for future calls.
			//
			$('#feedback_bar').delay (message_delay).fadeOut (400).delay (message_delay).fadeIn (100);
			
			//
			// Hide the message after 1.5s to let the previous animation finish.
			// We shall place the message on the back of all other DIVs.
			//			
			setTimeout ("$('#feedback_bar').css ('z-index', '-1')", message_delay * 2);
		}
	}
	else
	{
		//
		// Hide the message by placing it on the back of all other DIVs
		//
		$('#feedback_bar').css ('z-index', '-1');
	}
}


/**
 * This function handles validation and submit of data 
 * in forms across the application. It is usually called 
 * through the onClick event of anchors and buttons.-
 * 
 * @param event		The event DOM object.
 * @param form		The form DOM object that should be validated 
 * 					and submitted (e.g. document.forms[0]).-
 */
function validate_form_data (event, form)
{
	//
	// This is the object that triggered the event
	//
	source_object = event.target;

	//
	// First, we will hide the object to prevent consequent clicks
	//
	source_object.style.opacity = "0";
	
	//
	// Create a JQuery object from the form 
	// element received as parameter
	//
	jq_form = jQuery (form);
	
	//
	// Try to submit the form, displaying 
	// info and error messages accordingly
	//
	jq_form.ajaxSubmit (
		{
			dataType: 'json',
			
			success:function (response)
			{
				//
				// If the success flag is set, there were no errors
			    //
				if (response.success)
				{
					set_feedback (response.message, false, true);
					
					//
					// Did we get any address to go to?
					//
					if (response.follow_address)
					{
						//
						// Go there ...
						//
						window.location = response.follow_address;
					}
				}
				else
				{
					set_feedback (response.message, true, true);
				}

				//
				// Show the object back again (i.e. make it visible)
				//
				source_object.style.opacity = "1";
			}
		});
	
	//
	// Do not allow the anchor to redirect
	//
	return false;	
}



/**
 * This function handles deleting an element (i.e. record) displayed in 
 * a table (usually) containing all table rows.-
 * This function is usually called through the onClick event of anchors and buttons.-
 * 
 * @param event		The event DOM object.
 */
function delete_table_row (event)
{
	//
	// This is the object that triggered the event
	//
	source_object = event.target;

	//
	// Check that we received a valid target address
	//
	if (source_object.href)
	{
		//
		// Call the target address and capture its response
		//
		$.get (source_object.href,		// Target address to read from 
			   '',						// Data added to the requested address
			   function (response)		// A callback function executed on success
			   {
				   if (response.success)
				   {
					   //
					   // Display the success message (without fading)
					   //
				       set_feedback (response.message, false, true);
				       
				       //
				       // Wait 1 second before reloading the whole table
				       //
				       setTimeout ("window.location.reload ( )", 1000);
				   }
				   else
				   {
				      set_feedback (response.message, true, true);
				   }
			   },
			   'json');					// The expected data type from the server		
	}

	//
	// Do not allow the anchor to redirect
	//
	return false;	
}

-- phpMyAdmin SQL Dump
-- version 2.8.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost:8889
-- Server version: 5.1.39
-- PHP Version: 5.3.0
-- 
-- Database: `centro`
-- 

--
-- To create an everyday user for this database, use the
-- following commands AFTER the creating the database:
--
-- shell> mysql --user=root mysql -p
-- mysql> CREATE USER 'garufa'@'localhost' IDENTIFIED BY 'clave';
-- mysql> GRANT SELECT,INSERT,UPDATE,DELETE
--    ->     ON centro.*
--    ->     TO 'garufa'@'localhost';
--

CREATE DATABASE IF NOT EXISTS centro CHARACTER SET = utf8 COLLATE = utf8_bin;
USE centro;


-- --------------------------------------------------------
--
-- Table structure for table `centro_company`
--
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `centro_company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(255) COLLATE utf8_bin NOT NULL,
  `address` char(255) COLLATE utf8_bin NOT NULL,
  `identification` char(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='This table represents the whole company.' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `centro_company`
--

INSERT INTO `centro_company` (`company_id`, `name`, `address`, `identification`) 
VALUES
(1, 'Centro, Inc.', 'Cesta na hrib 123', 'ID for DDV');


-- --------------------------------------------------------
--
-- Table structure for table `centro_stores`
--
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `centro_stores` (
  `store_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(255) COLLATE utf8_bin NOT NULL,
  `address` char(255) COLLATE utf8_bin NOT NULL,
  `telephone` char(255) COLLATE utf8_bin NOT NULL,
  `company_id` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`store_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='The data for a single store.' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `centro_stores`
--

INSERT INTO `centro_stores` (`store_id`, `name`, `address`, `telephone`, `company_id`) 
VALUES
(1, 'Virtual store', 'Virtual street 1911', '040 666 777', 1);



-- --------------------------------------------------------
--
-- Table structure for table `centro_terminals`
--
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `centro_terminals` (
  `terminal_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(255) COLLATE utf8_bin NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`terminal_id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='A single terminal (registry) in a store.' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `centro_terminals`
--

INSERT INTO `centro_terminals` (`terminal_id`, `name`, `store_id`) 
VALUES
(1, '555-444-333-222', 1),
(2, '222-333-444-555', 1);


-- --------------------------------------------------------
--
-- Table structure for table `centro_app_config`
--
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `centro_app_config` (
  `app_config_id` int(11) NOT NULL AUTO_INCREMENT,
  `key` char(255) COLLATE utf8_bin NOT NULL,
  `value` char(255) COLLATE utf8_bin NOT NULL,
  `terminal_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`app_config_id`),
  KEY `terminal_id` (`terminal_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=11 ;

--
-- Dumping data for table `centro_app_config`
--

INSERT INTO `centro_app_config` (`app_config_id`, `key`, `value`, `terminal_id`) 
VALUES
(1, 'address', 'Cesta na PM 123', 1),
(2, 'company', 'Centro, Inc', 1),
(3, 'default_tax_rate', '8', 1),
(4, 'email', 'info@centro.si', 1),
(5, 'fax', '', 1),
(6, 'phone', '031 555 555', 1),
(7, 'return_policy', 'Test', 1),
(8, 'version', '1.0', 1),
(9, 'website', '', 1),
(10, 'this_terminal', '1', NULL);



-- --------------------------------------------------------
-- 
-- Table structure for table `centro_languages`
-- 
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `centro_languages` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(20) COLLATE utf8_bin NOT NULL,
  `short_name` char(10) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `short_name` (`short_name`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;


-- 
-- Dumping data for table `centro_languages`
-- 
INSERT INTO `centro_languages` (`language_id`, `name`, `short_name`) 
VALUES
(1, 'english', 'EN'),
(2, 'slovene', 'SI');


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_categories`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `parent_category_id` int NULL,
  PRIMARY KEY `category_id` (`category_id`),
  KEY `parent_category_id` (`parent_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=4;


-- 
-- Dumping data for table `centro_categories`
-- 
INSERT INTO `centro_categories` (`category_id`, `parent_category_id`) VALUES (1, NULL);
INSERT INTO `centro_categories` (`category_id`, `parent_category_id`) VALUES (2, 1);
INSERT INTO `centro_categories` (`category_id`, `parent_category_id`) VALUES (3, 1);


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_categories_lang`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_categories_lang` (
  `category_id` int NOT NULL,
  `language_id` int NOT NULL,
  `name` char(255) NOT NULL,
  `description` char(255) NULL,
  PRIMARY KEY `cat_lang_id` (`category_id`, `language_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_categories_lang`
-- 
INSERT INTO `centro_categories_lang` (`category_id`, `language_id`, `name`, `description`) VALUES (1, 1, 'Shirts', 'High quality shirts. 100% cotton');
INSERT INTO `centro_categories_lang` (`category_id`, `language_id`, `name`, `description`) VALUES (1, 2, 'Majce', 'Majce prvega razreda. 100% bombaž');
INSERT INTO `centro_categories_lang` (`category_id`, `language_id`, `name`, `description`) VALUES (2, 1, 'T-shirts', 'Spring oriented t-shirts.');
INSERT INTO `centro_categories_lang` (`category_id`, `language_id`, `name`, `description`) VALUES (2, 2, 'S kratkimi rokavami', 'Prava izbira za spomlad.');
INSERT INTO `centro_categories_lang` (`category_id`, `language_id`, `name`, `description`) VALUES (3, 1, 'Long-sleeved shirts', 'Autumm oriented shirts.');
INSERT INTO `centro_categories_lang` (`category_id`, `language_id`, `name`, `description`) VALUES (3, 2, 'Z dolgimi rokavami', 'Za zimo ali jesen.');



-- --------------------------------------------------------
-- 
-- Table structure for table `centro_size_groups`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_size_groups` (
  `size_group_id` int NOT NULL AUTO_INCREMENT,
  `name` char(255) NOT NULL,
  PRIMARY KEY `size_group_id` (`size_group_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;


-- 
-- Dumping data for table `centro_size_groups`
-- 
INSERT INTO `centro_size_groups` (`size_group_id`, `name`) VALUES (1, 'XS, S, M, L, XL');
INSERT INTO `centro_size_groups` (`size_group_id`, `name`) VALUES (2, '36, 38, 40, 42, ...');


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_sizes`
-- 
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `centro_sizes` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `size_group_id` int(11) NOT NULL,
  `name` char(20) COLLATE utf8_bin NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`size_id`),
  KEY `size_group_id` (`size_group_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=13 ;


-- 
-- Dumping data for table `centro_sizes`
--
 
INSERT INTO `centro_sizes` (`size_id`, `size_group_id`, `name`, `order`) 
VALUES
(1, 1, 'XS', 1),
(2, 1, 'S', 2),
(3, 1, 'M', 3),
(4, 1, 'L', 4),
(5, 1, 'XL', 5),
(6, 2, '36', 36),
(7, 2, '38', 38),
(8, 2, '40', 40),
(9, 2, '42', 42),
(10, 2, '44', 44),
(11, 2, '46', 46),
(12, 2, '48', 48);



-- --------------------------------------------------------
-- 
-- Table structure for table `centro_items`
--
-- -------------------------------------------------------- 
CREATE TABLE `centro_items` (
  `item_id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `size_group_id` int NOT NULL,
  `barcode` char(255) NOT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `reorder_level` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_id`),
  KEY `category_id` (`category_id`),
  UNIQUE KEY `barcode` (`barcode`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_items`
-- 
INSERT INTO `centro_items` (`item_id`, `category_id`, `size_group_id`, `barcode`, `quantity`, `reorder_level`) VALUES
	(1, 1, 1, '0000-0001', 1000, 000),
	(2, 1, 2, '0000-0002', 1100, 100),
	(3, 2, 1, '0000-0003', 1200, 200),
	(4, 2, 2, '0000-0004', 1300, 300),
	(5, 2, 1, '0000-0005', 1400, 400);
	


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_items_lang`
--
-- -------------------------------------------------------- 
CREATE TABLE `centro_items_lang` (
  `item_id` int NOT NULL,
  `language_id` int NOT NULL,
  `name` char(255) NOT NULL,
  `description` char(255) NULL,
  `price_unit` int NOT NULL DEFAULT '0',
  `price_cost` int NOT NULL DEFAULT '0',
  PRIMARY KEY `item_lang_id` (`item_id`, `language_id`),
  KEY `name` 	    (`name`),
  KEY `description` (`description`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_items_lang`
-- 
INSERT INTO `centro_items_lang` (`item_id`, `language_id`, `name`, `description`, `price_unit`, `price_cost`)
VALUES
	(1, 1, 'First item', 'Our first item description', 1000, 100),
	(1, 2, 'Prvi artikel', 'Naš prvi opis artikla', 1000, 100),
	(2, 1, 'Second item', 'Our second item description', 2000, 200),
	(2, 2, 'Drugi artikel', 'Naš drugi opis artikla', 2000, 200),
	(3, 1, 'Third item', 'Our third item description', 3000, 300),
	(3, 2, 'Tretji artikel', 'Naš tretji opis artikla', 3000, 300),
	(4, 1, 'Fourth item', 'Our fourth item description', 4000, 400),
	(4, 2, 'Cetrti artikel', 'Naš četrti opis artikla', 4000, 400),
	(5, 1, 'Fifth item', 'Our fifth item description', 5000, 500),
	(5, 2, 'Peti artikel', 'Naš peti opis artikla', 5000, 500);

	
-- --------------------------------------------------------
-- 
-- Table structure for table `centro_items_taxes`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_items_taxes` (
  `tax_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `name` char(255) NOT NULL,
  `percent` int NOT NULL,
  PRIMARY KEY (`tax_id`),
  KEY `centro_items_taxes_ibfk_1` (`item_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_items_taxes`
-- 
INSERT INTO `centro_items_taxes` VALUES 
	(1, 1, 'DDV', 2000),
	(2, 2, 'DDV', 2000),
	(3, 3, 'DDV', 2000),
	(4, 4, 'DDV', 2000),
	(5, 5, 'DDV', 2000);


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_modules`
-- 
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `centro_modules` (
  `name_lang_key` char(255) COLLATE utf8_bin NOT NULL,
  `desc_lang_key` char(255) COLLATE utf8_bin NOT NULL,
  `sort` int(11) NOT NULL,
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `package` char(255) COLLATE utf8_bin NOT NULL,
  `name` char(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `centro_modules`
-- 

INSERT INTO `centro_modules` (`module_id`, `name_lang_key`, `desc_lang_key`, `sort`, `package`, `name`) 
VALUES
(2, 'module_config',   'module_config_desc',   7, 'company', 'config'),
(3, 'module_customer', 'module_customer_desc', 1, 'people',  'customer'),
(4, 'module_employee', 'module_employee_desc', 6, 'people',  'employee'),
(5, 'module_items',    'module_items_desc',    3, 'items', 	 'items'),
(6, 'module_reports',  'module_reports_desc',  4, '', 		 'reports'),
(7, 'module_sales',    'module_sales_desc',    5, '', 		 'sales');


-- --------------------------------------------------------
--
-- Table structure for table `centro_terminals_modules_employees`
--
-- --------------------------------------------------------
CREATE TABLE `centro_terminals_modules_employees` (
  `terminal_id` int(11) NOT NULL,
  `module_id`   int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  UNIQUE KEY `unique` (`terminal_id`,`module_id`,`employee_id`),
  KEY `centro_terminals_modules_employees_ibfk_3` (`employee_id`),
  KEY `centro_terminals_modules_employees_ibfk_2` (`module_id`),
  KEY `centro_terminals_modules_employees_ibfk_1` (`terminal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;


--
-- Dumping data for table `centro_terminals_modules_employees`
--

INSERT INTO `centro_terminals_modules_employees` (`terminal_id`, `module_id`, `employee_id`) 
VALUES
--
-- Admin modules
--
(1, 2, 1),
(1, 3, 1),
(1, 4, 1),
(1, 5, 1),
(1, 6, 1),
(1, 7, 1), 
--
-- Alenka modules
--
(1, 7, 2),
--
-- Pepe modules
-- 
(1, 7, 3);


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_customers`
-- 
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `centro_customers` (
  `first_name` char(255) COLLATE utf8_bin NOT NULL,
  `last_name` char(255) COLLATE utf8_bin NOT NULL,
  `phone_number` char(255) COLLATE utf8_bin DEFAULT NULL,
  `email` char(255) COLLATE utf8_bin DEFAULT NULL,
  `address_1` char(255) COLLATE utf8_bin DEFAULT NULL,
  `address_2` char(255) COLLATE utf8_bin DEFAULT NULL,
  `city` char(255) COLLATE utf8_bin DEFAULT NULL,
  `state` char(255) COLLATE utf8_bin DEFAULT NULL,
  `zip_code` char(255) COLLATE utf8_bin DEFAULT NULL,
  `country` char(255) COLLATE utf8_bin DEFAULT NULL,
  `comments` text COLLATE utf8_bin,
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_number` char(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `name` (`first_name`,`last_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=7 ;

--
-- Dumping data for table `centro_customers`
--

INSERT INTO `centro_customers` (`first_name`, `last_name`, `phone_number`, `email`, `address_1`, `address_2`, `city`, `state`, `zip_code`, `country`, `comments`, `customer_id`, `account_number`) VALUES
('Sašo', 'Hribar', '040 879 987', 'saso.hribar@gmail.com', 'Jadranska cesta 87', '', '', '', '', '', 'Izmišljena oseba', 1, '0001'),
('Končni', 'Kupec', '', '', '', '', '', '', '', '', '', 2, '0002');



--
-- Table structure for table `centro_employees`
--

CREATE TABLE IF NOT EXISTS `centro_employees` (
  `first_name` char(255) COLLATE utf8_bin NOT NULL,
  `last_name` char(255) COLLATE utf8_bin NOT NULL,
  `phone_number` char(255) COLLATE utf8_bin DEFAULT NULL,
  `email` char(255) COLLATE utf8_bin DEFAULT NULL,
  `address` char(255) COLLATE utf8_bin DEFAULT NULL,
  `city` char(255) COLLATE utf8_bin DEFAULT NULL,
  `state` char(255) COLLATE utf8_bin DEFAULT NULL,
  `zip_code` char(255) COLLATE utf8_bin DEFAULT NULL,
  `country` char(255) COLLATE utf8_bin DEFAULT NULL,
  `comments` text COLLATE utf8_bin,
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` char(255) COLLATE utf8_bin NOT NULL,
  `password` char(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`employee_id`),
  UNIQUE KEY `username` (`username`),
  KEY `name` (`first_name`,`last_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=6 ;

--
-- Dumping data for table `centro_employees`
--

INSERT INTO `centro_employees` (`first_name`, `last_name`, `phone_number`, `email`, `address`, `city`, `state`, `zip_code`, `country`, `comments`, `employee_id`, `username`, `password`) 
VALUES
('John', 'Doe', '05 555 5555', 'admin@centro.si', 'Address', '', '', '', '', '', 1, 'admin', MD5 ('5')),
('Alenka', 'Blagajna', '-', 'alenka@email.si', '-', 'Nova Gorica', 'GO', '4000', 'Slovenija', 'Blagajničarka', 2, 'alenka', MD5 ('444')),
('Pepe', 'Vendesi', '040 222 111', 'pepe@telekom.it', '-', 'Trieste', 'TR', '9000', 'Italia', 'Prodajalec', 3, 'pepe', MD5 ('555'));


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_sales`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_sales` (
  `sale_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `customer_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `comment` text NOT NULL,
  `sale_id` int NOT NULL AUTO_INCREMENT,
  `is_active` bool NOT NULL DEFAULT TRUE,
  `terminal_id` int(11) NOT NULL,
  PRIMARY KEY (`sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_sales`
-- 
INSERT INTO `centro_sales` 
VALUES 
('2010-07-14 13:42:59', 2, 1, 'Komentar', 1, TRUE, 1);


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_sales_details`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_sales_details` (
  `sale_detail_id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `item_id` int NOT NULL,
  `quantity_purchased` int NOT NULL,
  `item_cost_price` int NOT NULL,
  `item_unit_price` int NOT NULL,
  PRIMARY KEY 	(`sale_detail_id`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id_item_id` (`sale_id`,`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_sales_details`
-- 
INSERT INTO `centro_sales_details` VALUES (1, 1, 1, 500, 400, 2000);


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_sales_details_taxes`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_sales_details_taxes` (
  `sale_detail_tax_id` int NOT NULL AUTO_INCREMENT,
  `sale_detail_id` int NOT NULL,
  `name` char(255) NOT NULL,
  `percent` int NOT NULL,
  PRIMARY KEY 	(`sale_detail_tax_id`),
  KEY `sale_id` (`sale_detail_id`),
  KEY `name` 	(`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_sales_details_taxes`
-- 
INSERT INTO `centro_sales_details_taxes` VALUES (1, 1, 'DDV', 805);


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_payments`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_payments` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_payments`
-- 
INSERT INTO `centro_payments` VALUES (1), (2), (3), (4), (5);


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_payments_lang`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_payments_lang` (
  `payment_id` int NOT NULL,
  `language_id` int NOT NULL,
  `name` char(255) NOT NULL,
  PRIMARY KEY (`payment_id`, `language_id`),
  KEY (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_payments_lang`
-- 
INSERT INTO `centro_payments_lang` 
VALUES (1, 1, 'Cash'),
       (1, 2, 'Gotovina'),
       (2, 1, 'Debit card'),
       (2, 2, 'Plačilna kartica'),
       (3, 1, 'Credit card'),
       (3, 2, 'Kreditna kartica'),
       (4, 1, 'Bond / Certificate'),
       (4, 2, 'Darilni bon'),
       (5, 1, 'Free'),
       (5, 2, 'Zastonj');


-- --------------------------------------------------------
-- 
-- Table structure for table `centro_sales_payments`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_sales_payments` (
  `sale_payment_id` int NOT NULL AUTO_INCREMENT,
  `payment_id` int NOT NULL,
  `sale_id` int NOT NULL,
  `amount` int NOT NULL,
  PRIMARY KEY (`sale_payment_id`),
  KEY (`payment_id`),
  KEY (`sale_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_sales_payments`
-- 

INSERT INTO `centro_sales_payments` (`sale_payment_id`, `payment_id`, `sale_id`, `amount`)
VALUES
(1, 1, 1, 0),
(2, 2, 1, 0),
(3, 3, 1, 10805),
(4, 4, 1, 0),
(5, 5, 1, 0);



-- --------------------------------------------------------
-- 
-- Table structure for table `centro_sessions`
-- 
-- --------------------------------------------------------
CREATE TABLE `centro_sessions` (
  `session_id` char(40) NOT NULL,
  `ip_address` char(16) NOT NULL,
  `user_agent` char(50) NOT NULL,
  `last_activity` int unsigned NOT NULL,
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10;

-- 
-- Dumping data for table `centro_sessions`
-- 





-- --------------------------------------------------------
-- 
-- Constraints for dumped tables
-- 
-- --------------------------------------------------------

--
-- Constraints for table `centro_app_config`
--
ALTER TABLE `centro_app_config`
  ADD CONSTRAINT `centro_app_config_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`);

--
-- Constraints for table `centro_stores`
--
ALTER TABLE `centro_stores`
  ADD CONSTRAINT `_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `centro_company` (`company_id`);

--
-- Constraints for table `centro_terminals`
--
ALTER TABLE `centro_terminals`
  ADD CONSTRAINT `centro_terminals_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `centro_stores` (`store_id`);
  
--
-- Constraints for table `centro_terminals_modules_employees`
--
ALTER TABLE `centro_terminals_modules_employees`
  ADD CONSTRAINT `centro_terminals_modules_employees_ibfk_3` FOREIGN KEY (`employee_id`) REFERENCES `centro_employees` (`employee_id`),
  ADD CONSTRAINT `centro_terminals_modules_employees_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals` (`terminal_id`),
  ADD CONSTRAINT `centro_terminals_modules_employees_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `centro_modules` (`module_id`);

-- 
-- Constraints for table `centro_categories`
-- 
ALTER TABLE `centro_categories`
  ADD CONSTRAINT `centro_categories_ibfk_1` FOREIGN KEY (`parent_category_id`) REFERENCES `centro_categories` (`category_id`);
  
-- 
-- Constraints for table `centro_categories_lang`
-- 
ALTER TABLE `centro_categories_lang`
  ADD CONSTRAINT `centro_categories_lang_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `centro_categories` (`category_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `centro_categories_lang_ibfk_2` FOREIGN KEY (`language_id`) REFERENCES `centro_languages` (`language_id`);


-- 
-- Constraints for table `centro_sizes`
-- 
ALTER TABLE `centro_sizes`
  ADD CONSTRAINT `centro_sizes_ibfk_1` FOREIGN KEY (`size_group_id`) REFERENCES `centro_size_groups` (`size_group_id`);

-- 
-- Constraints for table `centro_items`
-- 
ALTER TABLE `centro_items`
  ADD CONSTRAINT `centro_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `centro_categories` (`category_id`),
  ADD CONSTRAINT `centro_items_ibfk_2` FOREIGN KEY (`size_group_id`) REFERENCES `centro_size_groups` (`size_group_id`);

-- 
-- Constraints for table `centro_items_lang`
-- 
ALTER TABLE `centro_items_lang`
  ADD CONSTRAINT `centro_items_lang_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `centro_items_lang_ibfk_2` FOREIGN KEY (`language_id`) REFERENCES `centro_languages` (`language_id`);

-- 
-- Constraints for table `centro_items_taxes`
-- 
ALTER TABLE `centro_items_taxes`
  ADD CONSTRAINT `centro_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`) ON DELETE CASCADE;


-- 
-- Constraints for table `centro_sales`
-- 
ALTER TABLE `centro_sales`
  ADD CONSTRAINT `centro_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `centro_employees` (`employee_id`),
  ADD CONSTRAINT `centro_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `centro_customers` (`customer_id`),
  ADD CONSTRAINT `centro_sales_ibfk_3` FOREIGN KEY (`terminal_id`) REFERENCES `centro_terminals`  (`terminal_id`);

-- 
-- Constraints for table `centro_sales_details`
-- 
ALTER TABLE `centro_sales_details`
  ADD CONSTRAINT `centro_sales_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `centro_items` (`item_id`),
  ADD CONSTRAINT `centro_sales_details_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `centro_sales` (`sale_id`) ON DELETE CASCADE;

-- 
-- Constraints for table `centro_sales_details_taxes`
-- 
ALTER TABLE `centro_sales_details_taxes`
  ADD CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`) ON DELETE CASCADE;

-- 
-- Constraints for table `centro_payments_lang`
-- 
ALTER TABLE `centro_payments_lang`
  ADD CONSTRAINT `centro_payments_lang_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `centro_payments` (`payment_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `centro_payments_lang_ibfk_2` FOREIGN KEY (`language_id`) REFERENCES `centro_languages` (`language_id`);

-- 
-- Constraints for table `centro_sales_payments`
-- 
ALTER TABLE `centro_sales_payments`
  ADD CONSTRAINT `centro_sales_payments_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `centro_payments` (`payment_id`),
  ADD CONSTRAINT `centro_sales_payments_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `centro_sales` (`sale_id`) ON DELETE CASCADE;

ER model created with Mogwai ER Designer NG v2.5.0 (http://mogwai.sourceforge.net/?Welcome:ERDesigner_NG).

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-02 12:19:24 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-10-02 12:20:09 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-10-02 19:21:46 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/modules.php 12

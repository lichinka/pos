<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-11-15 16:51:46 --> Severity: Notice  --> Undefined variable: restrict_module /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-11-15 16:51:46 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-11-15 16:52:10 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/no_access.php 22

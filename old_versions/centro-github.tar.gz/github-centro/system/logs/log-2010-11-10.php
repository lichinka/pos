<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '/var/run/mysqld/mysqld.sock' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:21 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:21 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:21 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:21 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306:3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:21 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:21 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '/var/run/mysqld/mysqld.sock' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:23 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:23 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:23 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:23 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306:3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:23 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:23 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '/var/run/mysqld/mysqld.sock' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306:3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:47:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:47:35 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '/var/run/mysqld/mysqld.sock' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:48:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:48:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:48:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:48:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_connect(): Can't connect to local MySQL server through socket '3306:3306:3306:3306' (2) /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 70
ERROR - 2010-11-10 17:48:35 --> Unable to connect to the database
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_driver.php 163
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 17:48:35 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/luka/etc/saion/centro/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2010-11-10 18:11:51 --> Severity: 4096  --> Object of class Store could not be converted to string /home/luka/etc/saion/centro/application/controllers/test/terminal_model.php 19
ERROR - 2010-11-10 18:11:51 --> Severity: 4096  --> Object of class Store could not be converted to string /home/luka/etc/saion/centro/application/controllers/test/terminal_model.php 19
DEBUG - 2010-11-10 18:14:21 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:21 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:21 --> No URI present. Default controller set.
DEBUG - 2010-11-10 18:14:21 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:21 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:21 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:21 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:21 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:21 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:21 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:21 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:21 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:21 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:21 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:21 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:21 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:21 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:21 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:21 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:21 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> File loaded: application/views/partial/header.php
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:21 --> File loaded: application/views/partial/modules.php
DEBUG - 2010-11-10 18:14:21 --> File loaded: application/views/partial/footer.php
DEBUG - 2010-11-10 18:14:21 --> File loaded: application/views/home.php
DEBUG - 2010-11-10 18:14:21 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:21 --> Total execution time: 0.0218
DEBUG - 2010-11-10 18:14:29 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:29 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:29 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:29 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:29 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:29 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:29 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:29 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:29 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:29 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:29 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:29 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:29 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:29 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:29 --> File loaded: application/views/sales/table_sales.php
DEBUG - 2010-11-10 18:14:29 --> File loaded: application/views/sales/table_sales_buttons.php
DEBUG - 2010-11-10 18:14:29 --> File loaded: application/views/sales/partial/header.php
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:29 --> File loaded: application/views/partial/modules.php
DEBUG - 2010-11-10 18:14:29 --> File loaded: application/views/partial/footer.php
DEBUG - 2010-11-10 18:14:29 --> File loaded: application/views/sales/skeleton.php
DEBUG - 2010-11-10 18:14:29 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:29 --> Total execution time: 0.1487
DEBUG - 2010-11-10 18:14:38 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:38 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:38 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:38 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:38 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:38 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:38 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:38 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:38 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:38 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:38 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:38 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:38 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:38 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:38 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:39 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:39 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:39 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:39 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:39 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:39 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:39 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:39 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:39 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:39 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:39 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:39 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:39 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> File loaded: application/views/sales/table_details.php
DEBUG - 2010-11-10 18:14:39 --> File loaded: application/views/sales/table_details_buttons.php
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:39 --> File loaded: application/views/sales/partial/header.php
DEBUG - 2010-11-10 18:14:39 --> File loaded: application/views/sales/partial/right_column.php
DEBUG - 2010-11-10 18:14:39 --> File loaded: application/views/partial/footer.php
DEBUG - 2010-11-10 18:14:39 --> File loaded: application/views/sales/skeleton.php
DEBUG - 2010-11-10 18:14:39 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:39 --> Total execution time: 0.1286
DEBUG - 2010-11-10 18:14:44 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:44 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:44 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:44 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:44 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:44 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:44 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:44 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:44 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:44 --> Total execution time: 0.0349
DEBUG - 2010-11-10 18:14:44 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:44 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:44 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:44 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:44 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:44 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:44 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:44 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:44 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:44 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:44 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:45 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:45 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:45 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:45 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:45 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:45 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:45 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:45 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:45 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:45 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:45 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:45 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:45 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> File loaded: application/views/sales/table_details.php
DEBUG - 2010-11-10 18:14:45 --> File loaded: application/views/sales/table_details_buttons.php
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:45 --> File loaded: application/views/sales/partial/header.php
DEBUG - 2010-11-10 18:14:45 --> File loaded: application/views/sales/partial/right_column.php
DEBUG - 2010-11-10 18:14:45 --> File loaded: application/views/partial/footer.php
DEBUG - 2010-11-10 18:14:45 --> File loaded: application/views/sales/skeleton.php
DEBUG - 2010-11-10 18:14:45 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:45 --> Total execution time: 0.0450
DEBUG - 2010-11-10 18:14:51 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:51 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:51 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:51 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:51 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:51 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:51 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:51 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:51 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:51 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:51 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:51 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:51 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:51 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> File loaded: application/views/sales/edit_payment.php
DEBUG - 2010-11-10 18:14:51 --> File loaded: application/views/sales/edit_buttons.php
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:51 --> File loaded: application/views/sales/partial/header.php
DEBUG - 2010-11-10 18:14:51 --> File loaded: application/views/sales/partial/right_column.php
DEBUG - 2010-11-10 18:14:51 --> File loaded: application/views/partial/footer.php
DEBUG - 2010-11-10 18:14:51 --> File loaded: application/views/sales/skeleton.php
DEBUG - 2010-11-10 18:14:51 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:51 --> Total execution time: 0.0988
DEBUG - 2010-11-10 18:14:55 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:55 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:55 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:55 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:55 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:55 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/form_validation_lang.php
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:55 --> Total execution time: 0.1120
DEBUG - 2010-11-10 18:14:55 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:55 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:55 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:55 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:55 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:55 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:55 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> File loaded: application/views/sales/edit_payment.php
DEBUG - 2010-11-10 18:14:55 --> File loaded: application/views/sales/edit_buttons.php
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:55 --> File loaded: application/views/sales/partial/header.php
DEBUG - 2010-11-10 18:14:55 --> File loaded: application/views/sales/partial/right_column.php
DEBUG - 2010-11-10 18:14:55 --> File loaded: application/views/partial/footer.php
DEBUG - 2010-11-10 18:14:55 --> File loaded: application/views/sales/skeleton.php
DEBUG - 2010-11-10 18:14:55 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:55 --> Total execution time: 0.0570
DEBUG - 2010-11-10 18:14:57 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:57 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:57 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:57 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:57 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:57 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:57 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:57 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:57 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Config Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:14:57 --> URI Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Router Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Output Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Input Class Initialized
DEBUG - 2010-11-10 18:14:57 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:57 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:57 --> XSS Filtering completed
DEBUG - 2010-11-10 18:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:14:57 --> Language Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Loader Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:14:57 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:14:57 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Session Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:14:57 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Session routines successfully run
DEBUG - 2010-11-10 18:14:57 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Controller Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> File loaded: application/views/sales/table_details.php
DEBUG - 2010-11-10 18:14:57 --> File loaded: application/views/sales/table_details_buttons.php
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> Model Class Initialized
DEBUG - 2010-11-10 18:14:57 --> File loaded: application/views/sales/partial/header.php
DEBUG - 2010-11-10 18:14:57 --> File loaded: application/views/sales/partial/right_column.php
DEBUG - 2010-11-10 18:14:57 --> File loaded: application/views/partial/footer.php
DEBUG - 2010-11-10 18:14:57 --> File loaded: application/views/sales/skeleton.php
DEBUG - 2010-11-10 18:14:57 --> Final output sent to browser
DEBUG - 2010-11-10 18:14:57 --> Total execution time: 0.0459
DEBUG - 2010-11-10 18:15:00 --> Config Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:15:00 --> URI Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Router Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Output Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Input Class Initialized
DEBUG - 2010-11-10 18:15:00 --> XSS Filtering completed
DEBUG - 2010-11-10 18:15:00 --> XSS Filtering completed
DEBUG - 2010-11-10 18:15:00 --> XSS Filtering completed
DEBUG - 2010-11-10 18:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:15:00 --> Language Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Loader Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:15:00 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Session Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:15:00 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Session routines successfully run
DEBUG - 2010-11-10 18:15:00 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Controller Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Final output sent to browser
DEBUG - 2010-11-10 18:15:00 --> Total execution time: 0.0954
DEBUG - 2010-11-10 18:15:00 --> Config Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Hooks Class Initialized
DEBUG - 2010-11-10 18:15:00 --> URI Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Router Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Output Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Input Class Initialized
DEBUG - 2010-11-10 18:15:00 --> XSS Filtering completed
DEBUG - 2010-11-10 18:15:00 --> XSS Filtering completed
DEBUG - 2010-11-10 18:15:00 --> XSS Filtering completed
DEBUG - 2010-11-10 18:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-11-10 18:15:00 --> Language Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Loader Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: form_helper
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: url_helper
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: table_helper
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: text_helper
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: currency_helper
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/categories_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/common_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/config_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/customers_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/employees_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/error_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/export-import_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/invoice_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/items_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/login_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/module_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/reports_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/sales_lang.php
DEBUG - 2010-11-10 18:15:00 --> Language file loaded: language/slovene/sizes_lang.php
DEBUG - 2010-11-10 18:15:00 --> Database Driver Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Session Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Helper loaded: string_helper
DEBUG - 2010-11-10 18:15:00 --> Encrypt Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Session routines successfully run
DEBUG - 2010-11-10 18:15:00 --> User Agent Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Controller Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Form Validation Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized
DEBUG - 2010-11-10 18:15:00 --> Model Class Initialized

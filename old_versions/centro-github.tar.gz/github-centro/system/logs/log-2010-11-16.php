<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-11-16 18:04:58 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:04:58 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:04:58 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:04:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:05:58 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:05:58 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:05:58 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:06:59 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:06:59 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:06:59 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:07:59 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:07:59 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:07:59 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:08:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:09:00 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:09:00 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:09:00 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:10:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:10:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:10:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:11:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:11:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:11:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:12:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:12:01 --> Severity: Notice  --> Undefined property: stdClass::$employee_id /home/luka/etc/saion/centro/application/models/entity.php 213
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images
ERROR - 2010-11-16 18:12:01 --> 404 Page Not Found --> images

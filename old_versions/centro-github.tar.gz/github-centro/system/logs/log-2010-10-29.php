<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-29 11:50:00 --> Severity: Warning  --> trim() expects parameter 1 to be string, array given /home/luka/etc/saion/centro/system/libraries/Form_validation.php 615
ERROR - 2010-10-29 12:01:00 --> Severity: Notice  --> Use of undefined constant price_cost - assumed 'price_cost' /home/luka/etc/saion/centro/application/controllers/items/item_controller.php 302
ERROR - 2010-10-29 12:01:00 --> Severity: Notice  --> Use of undefined constant price_unit - assumed 'price_unit' /home/luka/etc/saion/centro/application/controllers/items/item_controller.php 318
ERROR - 2010-10-29 12:01:00 --> Severity: Notice  --> Use of undefined constant quantity - assumed 'quantity' /home/luka/etc/saion/centro/application/controllers/items/item_controller.php 334
ERROR - 2010-10-29 12:01:00 --> Severity: Notice  --> Use of undefined constant reorder_level - assumed 'reorder_level' /home/luka/etc/saion/centro/application/controllers/items/item_controller.php 349
ERROR - 2010-10-29 14:23:08 --> Severity: Notice  --> Undefined variable: line_price /home/luka/etc/saion/centro/application/models/sales/sale.php 371
ERROR - 2010-10-29 14:23:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/luka/etc/saion/centro/application/controllers/sales_controller.php 69
ERROR - 2010-10-29 14:23:42 --> Severity: Notice  --> A non well formed numeric value encountered /home/luka/etc/saion/centro/application/controllers/sales_controller.php 69
ERROR - 2010-10-29 14:29:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '2, `item_cost_price` = '500', `item_unit_price` = 5034,2 WHERE `sale_detail_id` ' at line 1
ERROR - 2010-10-29 14:30:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '5, `item_cost_price` = '500', `item_unit_price` = 5034,5 WHERE `sale_detail_id` ' at line 1
ERROR - 2010-10-29 14:37:01 --> Severity: Notice  --> Undefined index: $amount_due /home/luka/etc/saion/centro/application/controllers/sales_controller.php 474

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-28 10:47:02 --> Query error: Table 'centro.centro_payments' doesn't exist
ERROR - 2010-10-28 10:48:01 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 10:48:01 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 10:48:01 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:00:55 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 11:00:55 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 11:00:55 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:03:10 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 11:03:10 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 11:03:10 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:18:03 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 11:18:03 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 11:18:03 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:25:35 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 11:25:35 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 11:25:35 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:25:50 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 11:25:50 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 11:25:50 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:26:25 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 11:26:25 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 11:26:25 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:30:03 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 11:30:03 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 11:30:03 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:30:45 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 11:30:45 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 11:30:45 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 11:45:49 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:45:49 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:45:49 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:45:49 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:45:49 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:45:49 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:46:03 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:46:03 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:46:03 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:46:03 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:46:03 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:46:03 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/models/sales/sale.php 333
ERROR - 2010-10-28 11:46:49 --> Severity: Notice  --> Undefined property: Sale::$get_details /home/luka/etc/saion/centro/application/models/sales/sale.php 328
ERROR - 2010-10-28 12:05:42 --> Severity: Notice  --> Undefined index: detail_tax /home/luka/etc/saion/centro/application/models/sales/sale.php 338
ERROR - 2010-10-28 12:05:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/models/sales/sale.php 338
ERROR - 2010-10-28 12:05:42 --> Severity: Notice  --> Undefined index: detail_tax /home/luka/etc/saion/centro/application/models/sales/sale.php 338
ERROR - 2010-10-28 12:05:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/models/sales/sale.php 338
ERROR - 2010-10-28 15:16:07 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 15:16:07 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 15:16:07 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 15:23:36 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 15:32:15 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 15:32:15 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 15:32:15 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 15:40:30 --> Severity: Warning  --> array_push() expects parameter 1 to be array, string given /home/luka/etc/saion/centro/application/controllers/sales_controller.php 694
ERROR - 2010-10-28 15:40:30 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 15:40:30 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 15:40:30 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 15:40:31 --> Severity: Warning  --> array_push() expects parameter 1 to be array, string given /home/luka/etc/saion/centro/application/controllers/sales_controller.php 694
ERROR - 2010-10-28 15:40:31 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 15:40:31 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 15:40:31 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 15:40:33 --> Severity: Warning  --> array_push() expects parameter 1 to be array, string given /home/luka/etc/saion/centro/application/controllers/sales_controller.php 694
ERROR - 2010-10-28 15:40:33 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 15:40:33 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 15:40:33 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 15:40:36 --> Severity: Warning  --> array_push() expects parameter 1 to be array, string given /home/luka/etc/saion/centro/application/controllers/sales_controller.php 694
ERROR - 2010-10-28 15:40:36 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 15:40:36 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 15:40:36 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 15:40:59 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 15:40:59 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 15:40:59 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-28 15:45:25 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-28 15:45:25 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-28 18:47:32 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:47:32 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:47:32 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:47:32 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:47:32 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:48:05 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:48:05 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:48:05 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:48:05 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 18:48:05 --> Severity: Notice  --> Undefined property: Sale_payment::$quantity /home/luka/etc/saion/centro/application/models/sales/sale_payment.php 237
ERROR - 2010-10-28 19:09:16 --> Severity: Notice  --> Undefined property: Sale_payment::$name /home/luka/etc/saion/centro/application/controllers/sales_controller.php 408
ERROR - 2010-10-28 19:09:16 --> Severity: Notice  --> Undefined property: Sale_payment::$name /home/luka/etc/saion/centro/application/controllers/sales_controller.php 408
ERROR - 2010-10-28 19:09:16 --> Severity: Notice  --> Undefined property: Sale_payment::$name /home/luka/etc/saion/centro/application/controllers/sales_controller.php 408
ERROR - 2010-10-28 19:09:16 --> Severity: Notice  --> Undefined property: Sale_payment::$name /home/luka/etc/saion/centro/application/controllers/sales_controller.php 408
ERROR - 2010-10-28 19:09:16 --> Severity: Notice  --> Undefined property: Sale_payment::$name /home/luka/etc/saion/centro/application/controllers/sales_controller.php 408

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-19 16:52:09 --> 404 Page Not Found --> sales
ERROR - 2010-10-19 16:52:16 --> 404 Page Not Found --> customers

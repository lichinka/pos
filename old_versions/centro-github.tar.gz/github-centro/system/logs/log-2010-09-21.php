<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> Severity: Notice  --> Undefined property: stdClass::$terminal_id /home/luka/etc/saion/centro/application/models/persons/module.php 52
ERROR - 2010-09-21 11:46:40 --> 404 Page Not Found --> images
ERROR - 2010-09-21 12:01:15 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:01:23 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:02:48 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:07:23 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:07:31 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:07:35 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:07:36 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:07:55 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:08:52 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:08:57 --> Severity: Notice  --> Undefined property: Customers::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:09:06 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:10:09 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 12:13:07 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-09-21 12:13:22 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-09-21 12:14:17 --> Query error: Unknown column 'category' in 'field list'
ERROR - 2010-09-21 12:15:48 --> Severity: Notice  --> Undefined variable: registered_employee /home/luka/etc/saion/centro/application/views/partial/header.php 39
ERROR - 2010-09-21 17:38:30 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 18:00:51 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 18:28:51 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21
ERROR - 2010-09-21 18:29:03 --> Severity: Notice  --> Undefined variable: restrict_module /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-09-21 18:29:03 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-09-21 18:29:03 --> Severity: Notice  --> Undefined variable: restrict_module /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-09-21 18:29:03 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-09-21 18:29:04 --> Severity: Notice  --> Undefined variable: restrict_module /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-09-21 18:29:04 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-09-21 18:29:08 --> Severity: Notice  --> Undefined variable: restrict_module /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-09-21 18:29:08 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-09-21 18:33:45 --> Severity: Notice  --> Undefined property: Employees::$Person /home/luka/etc/saion/centro/application/controllers/person_controller.php 21

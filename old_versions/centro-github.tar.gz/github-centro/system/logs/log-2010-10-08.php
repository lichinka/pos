<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-08 10:36:43 --> 404 Page Not Found --> employees
ERROR - 2010-10-08 10:36:53 --> Severity: Notice  --> Undefined property: stdClass::$package /home/luka/etc/saion/centro/application/models/persons/module.php 49
ERROR - 2010-10-08 10:36:53 --> Severity: Notice  --> Undefined property: stdClass::$package /home/luka/etc/saion/centro/application/models/persons/module.php 49
ERROR - 2010-10-08 10:36:53 --> Severity: Notice  --> Undefined property: stdClass::$package /home/luka/etc/saion/centro/application/models/persons/module.php 49
ERROR - 2010-10-08 10:36:53 --> Severity: Notice  --> Undefined property: stdClass::$package /home/luka/etc/saion/centro/application/models/persons/module.php 49
ERROR - 2010-10-08 10:36:53 --> Severity: Notice  --> Undefined property: stdClass::$package /home/luka/etc/saion/centro/application/models/persons/module.php 49
ERROR - 2010-10-08 10:36:53 --> Severity: Notice  --> Undefined property: stdClass::$package /home/luka/etc/saion/centro/application/models/persons/module.php 49
ERROR - 2010-10-08 12:24:39 --> Severity: Warning  --> assert() [<a href='function.assert'>function.assert</a>]: Assertion &quot;$this-&gt;module != NULL&quot; failed /home/luka/etc/saion/centro/application/controllers/secure_area.php 44
ERROR - 2010-10-08 12:24:42 --> Severity: Warning  --> assert() [<a href='function.assert'>function.assert</a>]: Assertion &quot;$this-&gt;module != NULL&quot; failed /home/luka/etc/saion/centro/application/controllers/secure_area.php 44
ERROR - 2010-10-08 12:28:00 --> 404 Page Not Found --> config_controller/view
ERROR - 2010-10-08 12:51:20 --> 404 Page Not Found --> config_controller/view
ERROR - 2010-10-08 16:33:26 --> 404 Page Not Found --> config_controller/view
ERROR - 2010-10-08 16:34:46 --> Severity: Notice  --> Undefined variable: restrict_module /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-10-08 16:34:46 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/no_access.php 22
ERROR - 2010-10-08 16:36:17 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/no_access.php 22

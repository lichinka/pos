<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-26 13:35:35 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 13:35:35 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 13:35:35 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 13:39:43 --> Query error: Unknown column 'centro_items.item_id' in 'field list'
ERROR - 2010-10-26 13:39:50 --> Query error: Unknown column 'centro_items.item_id' in 'field list'
ERROR - 2010-10-26 13:41:26 --> Query error: Unknown column 'centro_items.item_id' in 'field list'
ERROR - 2010-10-26 13:42:03 --> Query error: Column 'name' in where clause is ambiguous
ERROR - 2010-10-26 13:42:46 --> Query error: Column 'name' in where clause is ambiguous
ERROR - 2010-10-26 13:49:47 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 13:49:47 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 13:49:47 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 13:50:03 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 13:50:03 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 13:50:03 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 14:00:36 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 14:00:36 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 14:00:36 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 14:05:34 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 14:05:34 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 14:05:34 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 17:25:28 --> Query error: Unknown column 'is_active' in 'field list'
ERROR - 2010-10-26 17:25:28 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-10-26 17:27:49 --> Severity: Notice  --> Undefined variable: detail /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1006
ERROR - 2010-10-26 17:27:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1006
ERROR - 2010-10-26 17:43:16 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 17:43:16 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 17:43:16 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 17:43:29 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 17:43:29 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 17:43:29 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 17:43:36 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 17:43:36 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 17:43:36 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 17:45:38 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 17:45:38 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 17:45:38 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 17:46:09 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 17:46:09 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 17:46:09 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 17:46:47 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 17:46:47 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 17:46:47 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 17:54:38 --> Severity: Notice  --> Undefined variable: detail /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1006
ERROR - 2010-10-26 17:54:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1006
ERROR - 2010-10-26 17:55:31 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 17:55:31 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1013
ERROR - 2010-10-26 17:55:31 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 17:55:31 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1013
ERROR - 2010-10-26 17:55:31 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 17:55:31 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1013
ERROR - 2010-10-26 17:56:09 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 17:56:18 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1013
ERROR - 2010-10-26 17:56:29 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 17:56:30 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1013
ERROR - 2010-10-26 17:56:31 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 17:56:31 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1013
ERROR - 2010-10-26 18:14:12 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 18:14:12 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1013
ERROR - 2010-10-26 18:14:12 --> Query error: Column 'category_id' cannot be null
ERROR - 2010-10-26 18:14:12 --> Severity: Warning  --> chmod(): Operation not permitted /home/luka/etc/saion/centro/system/libraries/Log.php 111
ERROR - 2010-10-26 18:15:56 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 18:16:00 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1013
ERROR - 2010-10-26 18:22:39 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 1012
ERROR - 2010-10-26 18:30:28 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 18:30:28 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 18:30:28 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-26 18:30:55 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-26 18:30:55 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-26 18:30:55 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-11-12 17:07:08 --> Severity: Notice  --> Undefined offset:  0 /home/luka/etc/saion/centro/application/libraries/pdf.php 291

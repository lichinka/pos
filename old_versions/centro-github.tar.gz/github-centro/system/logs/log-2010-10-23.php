<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-23 11:10:00 --> Severity: Notice  --> Undefined variable: id /home/luka/etc/saion/centro/application/controllers/sales_controller.php 593
ERROR - 2010-10-23 11:10:03 --> Severity: Notice  --> Undefined variable: id /home/luka/etc/saion/centro/application/controllers/sales_controller.php 593
ERROR - 2010-10-23 11:10:11 --> Severity: Notice  --> Undefined variable: id /home/luka/etc/saion/centro/application/controllers/sales_controller.php 593
ERROR - 2010-10-23 11:11:54 --> Severity: Notice  --> Undefined variable: id /home/luka/etc/saion/centro/application/controllers/sales_controller.php 593
ERROR - 2010-10-23 11:13:22 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 11:13:26 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 11:13:33 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 11:13:37 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 12:20:47 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 12:40:19 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-23 12:40:19 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-23 12:40:34 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-23 12:40:34 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-23 12:40:44 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-23 12:40:44 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-23 12:44:17 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 12:44:19 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 12:44:19 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 12:58:04 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`))
ERROR - 2010-10-23 13:03:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`centro`.`centro_sales_details_taxes`, CONSTRAINT `centro_sales_details_taxes_ibfk_1` FOREIGN KEY (`sale_detail_id`) REFERENCES `centro_sales_details` (`sale_detail_id`) ON DELETE CASCADE)
ERROR - 2010-10-23 13:56:50 --> Severity: Notice  --> Undefined index: sale_id /home/luka/etc/saion/centro/application/models/entity.php 93
ERROR - 2010-10-23 13:56:50 --> Severity: Notice  --> Undefined index: item_id /home/luka/etc/saion/centro/application/models/entity.php 93
ERROR - 2010-10-23 13:56:50 --> Query error: Column 'sale_id' cannot be null
ERROR - 2010-10-23 14:04:16 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-23 14:04:16 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-23 14:05:04 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-23 14:05:04 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20
ERROR - 2010-10-23 14:06:07 --> Severity: Notice  --> Undefined variable: subtotal /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 17
ERROR - 2010-10-23 14:06:07 --> Severity: Notice  --> Undefined variable: total /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 20

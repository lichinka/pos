<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-10-25 10:03:12 --> Query error: Table 'centro.centro_sales_details' doesn't exist
ERROR - 2010-10-25 10:26:41 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 163
ERROR - 2010-10-25 10:26:41 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 177
ERROR - 2010-10-25 12:45:31 --> 404 Page Not Found --> sales_controller/viewsearch_item_by_barcode
ERROR - 2010-10-25 12:47:01 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 10
ERROR - 2010-10-25 12:47:01 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 18
ERROR - 2010-10-25 12:47:01 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 24
ERROR - 2010-10-25 12:47:52 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 10
ERROR - 2010-10-25 12:47:52 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 18
ERROR - 2010-10-25 12:47:52 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 24
ERROR - 2010-10-25 12:51:18 --> 404 Page Not Found --> sales_controller/viewsearch_item_by_barcode
ERROR - 2010-10-25 12:51:24 --> 404 Page Not Found --> sales_controller/viewsearch_item_by_barcode
ERROR - 2010-10-25 12:51:28 --> 404 Page Not Found --> sales_controller/viewsearch_item_by_barcode
ERROR - 2010-10-25 12:52:19 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 12:52:19 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 12:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 12:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 12:53:33 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 12:53:33 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 12:53:42 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 12:53:42 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 12:54:15 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 12:54:15 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 12:54:22 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 12:54:22 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 12:55:34 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 14
ERROR - 2010-10-25 12:55:34 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 22
ERROR - 2010-10-25 12:55:34 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 28
ERROR - 2010-10-25 12:55:46 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 12:55:46 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 13:00:52 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 13:00:52 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 13:06:08 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 13:06:08 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 13:06:17 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 170
ERROR - 2010-10-25 13:06:17 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 181
ERROR - 2010-10-25 13:09:08 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 14
ERROR - 2010-10-25 13:09:08 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 22
ERROR - 2010-10-25 13:09:08 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 28
ERROR - 2010-10-25 14:32:52 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 14
ERROR - 2010-10-25 14:32:52 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 22
ERROR - 2010-10-25 14:32:52 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 28
ERROR - 2010-10-25 16:05:28 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 14
ERROR - 2010-10-25 16:05:28 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 22
ERROR - 2010-10-25 16:05:28 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 28
ERROR - 2010-10-25 17:30:44 --> Severity: Notice  --> Undefined variable: sale /home/luka/etc/saion/centro/application/controllers/sales_controller.php 358
ERROR - 2010-10-25 17:30:44 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 358
ERROR - 2010-10-25 17:30:44 --> Severity: Notice  --> Undefined variable: sale /home/luka/etc/saion/centro/application/controllers/sales_controller.php 358
ERROR - 2010-10-25 17:30:44 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 358
ERROR - 2010-10-25 17:30:46 --> Severity: Notice  --> Undefined variable: sale /home/luka/etc/saion/centro/application/controllers/sales_controller.php 358
ERROR - 2010-10-25 17:30:46 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 358
ERROR - 2010-10-25 17:30:46 --> Severity: Notice  --> Undefined variable: sale /home/luka/etc/saion/centro/application/controllers/sales_controller.php 358
ERROR - 2010-10-25 17:30:46 --> Severity: Notice  --> Trying to get property of non-object /home/luka/etc/saion/centro/application/controllers/sales_controller.php 358
ERROR - 2010-10-25 17:32:29 --> 404 Page Not Found --> sales_controller/set_customer
ERROR - 2010-10-25 17:42:04 --> Severity: Notice  --> Undefined variable: id /home/luka/etc/saion/centro/application/models/sales/sale.php 202
ERROR - 2010-10-25 17:42:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2010-10-25 17:46:12 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 14
ERROR - 2010-10-25 17:46:12 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 22
ERROR - 2010-10-25 17:46:12 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 28
ERROR - 2010-10-25 19:12:49 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-25 19:12:49 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-25 19:12:49 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30
ERROR - 2010-10-25 21:02:21 --> Severity: Notice  --> Undefined variable: item_search_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 15
ERROR - 2010-10-25 21:02:21 --> Severity: Notice  --> Undefined variable: customer_button /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 23
ERROR - 2010-10-25 21:02:21 --> Severity: Notice  --> Undefined variable: customer_name /home/luka/etc/saion/centro/application/views/sales/partial/right_column.php 30

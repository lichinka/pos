<?php
    //
    // Do we have to display the BACK button?
    //
    if (isset ($back_button))
    {
    	echo "<div id='back_button'>{back_button}</div>";
    }
    else
    {
    	echo "<div id='back_button' style='opacity: 0;'></div>";
    }
?>

<!-- DO NOT DISPLAY THE EDIT BUTTON -->
<div id="edit_button" style="opacity: 0;"><a></a></div>

<div id="new_button">{new_button}</div>

<!-- DO NOT DISPLAY THE SAVE BUTTON -->
<div id="submit_button" style="opacity: 0;"><a></a></div>

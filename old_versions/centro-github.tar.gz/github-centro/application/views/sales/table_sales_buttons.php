<!-- DO NOT DISPLAY THE BACK BUTTON -->
<div id="back_button" style="opacity: 0;"><a></a></div>

<!-- DO NOT DISPLAY THE PAYMENT BUTTON -->
<div id="payment_button" style="opacity: 0;"><a></a></div>

<div id="new_button">{new_button}</div>

<!-- DO NOT DISPLAY THE SAVE BUTTON -->
<div id="submit_button" style="opacity: 0;"><a></a></div>


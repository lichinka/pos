<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<?php $this->load->view ("sales/partial/header"); ?>

<body>
	<!-- MAIN CONTAINER -->
	<div id="container">

		<!-- CONTENT PANEL -->
		<div id="content-panel">
		    <h1><?php echo $this->lang->line ('sales_register'); ?></h1>
		    
		    <br />

			<?php
				//
				// This HTML is dinamically generated in the controller
				// by using the built-in template engine.
				//
				echo $content;
			?>			
		</div>
        
		<!-- THE RIGHT COLUMN CONTAINS SALES INFORMATION -->
		<?php
		  //
		  // Display the right column?
		  //
		  if (isset ($disable_right_column))
		  {
		      $this->load->view ("partial/modules");
		  }
		  else
		  {
		      $this->load->view ("sales/partial/right_column");
		  }
	   ?>

	   <!-- STATUS PANEL and PAGE FOOTER -->
	   <?php $this->load->view ("partial/footer"); ?>
	</div>

    <!-- PROGRAM NAME, VERSION AND TERMINAL SERIAL NUMBER -->
    <p>
    <?php 
    echo '.:'    . $this->lang->line ('common_you_are_using_phppos') .
         ' '     . $this->config->item ('version')                   . 
         ':.  #' . $active_terminal->name;
    ?>
    </p>
</body>

</html>

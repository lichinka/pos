<div id="title_bar">
 <div id="page_title" class="float_left">{page_title}</div>
</div>

{form_open}
 <div id="payment_panel">
    <fieldset id="payment_options">
        <legend>{page_info}</legend>
        
        {data}
        <div id="payment_row">
	        <div id="payment_icon_{payment_id}"></div>
	        <div id="payment_name">
               <p>{name}</p> 
	        </div>
	        <div id="payment_amount">
	           <input onfocus="this.select ( )" type="text" 
	           		  id="amount_{payment_id}" name="amount_{payment_id}" 
	           		  value="{amount}"  size='15'/>
	        </div>
        </div>
        {/data}

	 </fieldset>
 </div>
{form_close}

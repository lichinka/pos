<!-- MODULE PANEL -->
<div id="module-panel">

	<!-- MODULE HOME -->
	<div id="module-button">
		<a href="<?php echo site_url ('home');?>" >
			<?php echo $this->lang->line ('module_home'); ?>
		</a>		
	</div>

	<?php
	foreach ($registered_employee->get_active_modules ( ) as $module)
	{
	?>
		<!-- MODULE BUTTON -->
		<div id="module-button">
			<a href="<?php echo $module->get_site_URL ( );?>" >
			  <?php echo $this->lang->line ("module_".$module->name); ?>
			</a>
		</div>
	<?php
	}
	?>
</div>

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<base href="<?php echo base_url();?>" />

	<title>
		<?php 
		echo $this->config->item ('company') . ' -- ' . $this->lang->line ('common_powered_by') . ' CenTRO '
		?>
	</title>

	<!-- THE STYLE FOR THE WHOLE PAGE-->
	<link rel="stylesheet" rev="stylesheet" href="<?php echo base_url ( );?>css/style_green.css"/>

	<!-- STYLE FOR FORM EDITION (WITHIN THE CONTENT AREA OF THE PAGE) -->
	<link rel="stylesheet" rev="stylesheet" href="<?php echo base_url ( );?>css/style_green_edit_form.css"/>
	
	<!-- JQUERY LIBRARY -->
	<script src="<?php echo base_url ( );?>js/jquery-1.4.2.min.js" type="text/javascript" language="javascript" charset="UTF-8"></script>

	<!-- COMMON.JS MAKES USE OF THIS LIBRARY -->
	<script src="<?php echo base_url ( );?>js/jquery.form.js" type="text/javascript" language="javascript" charset="UTF-8"></script>

	<!-- SOME COMMON JS FUNCTIONS USED THROUGHOUT THE APPLICATION -->
	<script src="<?php echo base_url ( );?>js/common.js" type="text/javascript" language="javascript" charset="UTF-8"></script>	
</head>

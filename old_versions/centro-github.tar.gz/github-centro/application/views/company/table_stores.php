<div id="title_bar">
	<div id="page_title" class="float_left">{page_title}</div>
</div>

<div id="table_holder">
	<table id="sortable_table">
		<thead>
			<tr>
				{column_titles}
				 <th>{title}</th>
				{/column_titles}
			</tr>
		</thead>
		<tbody>
			<tr><td colspan='5'><div class='warning_message' style='padding:7px;{display_status}'>{empty_table}</div></td></tr>
			
			{table_data}
			<tr>
				<td>{name}</td>
				<td>{address}</td>
				<td>{telephone}</td>
				<td><div id="action_on_record">{edit_link}</div></td>
				<td><div id="action_on_record">{delete_link}</div></td>
			</tr>
			{/table_data}
			
		</tbody>
	</table>
</div>

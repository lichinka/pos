<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
	<meta http-equiv="refresh" content="60"/>
	
	<base href="<?php echo base_url ( );?>" />

	<title>
		<?php 
		echo $this->config->item ('company') . ' -- ' . $this->lang->line ('common_powered_by') . ' CenTRO '
		?>
	</title>

	<!-- THE STYLE FOR THE LOGIN PAGE-->
	<link rel="stylesheet" rev="stylesheet" href="<?php echo base_url ( );?>css/style_green_login.css"/>

	<!-- JQUERY LIBRARY -->
	<script src="<?php echo base_url ( );?>js/jquery-1.4.2.min.js" type="text/javascript" language="javascript" charset="UTF-8"></script>

	<!-- SOME JS FUNCTIONS USED FOR THE LOGIN PAGE -->
	<script src="<?php echo base_url ( );?>js/login.js" type="text/javascript" language="javascript" charset="UTF-8"></script>	
</head>

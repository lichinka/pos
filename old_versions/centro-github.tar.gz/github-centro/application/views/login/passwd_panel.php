<!-- A WELCOME MESSAGE -->
<div id='welcome_panel'>
    <img src='images/login/welcome_logo.png'/>
    <?php
        //
        // Display the date
        // 
        echo '<p>' . ucfirst (strftime ('%a,%e. %b %Y', time ( ))) . '<br/>';
        
        //
        // Display the time
        //
        echo ucfirst (strftime ('%H:%M', time ( ))) . '</p>';
    ?>
</div>    

<!-- THE PASS PANEL -->
<div id='passwd_panel'>
    <!-- OPEN THE FORM -->
    <?php
        //
        // Opens a form, which target is the login controller.-
        //
        echo form_open ('login/login_check');
    ?>

    <div id='passwd_element'>
        <input type='password' id='geslo' name='geslo' value='       '/>
    </div>
               
    <div id='number_pad'>
        <div id='number'>
            <img id='1'
                 src='images/login/style_green_number_1_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='2'
                 src='images/login/style_green_number_2_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='3' 
                 src='images/login/style_green_number_3_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='4' 
                 src='images/login/style_green_number_4_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='5' 
                 src='images/login/style_green_number_5_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='6' 
                 src='images/login/style_green_number_6_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='7' 
                 src='images/login/style_green_number_7_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='8' 
                 src='images/login/style_green_number_8_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='9' 
                 src='images/login/style_green_number_9_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='clear'
                 src='images/login/style_green_x_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='0'
                 src='images/login/style_green_number_0_small.png'
                 onclick="return keypad_pressed (event, document.getElementById ('geslo'));"/>
        </div>
        <div id='number'>
            <img id='login'
                 src='images/login/style_green_save_small.png'
                 onclick='return document.forms[0].submit ( );'/>
        </div>
    </div>

    <!-- CLOSE THE FORM -->
    <?php
        //
        // Closes the form opened before.-
        //
        echo form_close ( );
    ?>
</div>

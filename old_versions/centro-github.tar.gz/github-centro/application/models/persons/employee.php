<?php
require_once 'application/models/entity.php';

/**
 * This class represents an employee.
 *
 * @author Matjaz Cepar
 *
 */
class Employee extends Entity
{
    var $id;
    var $first_name;
    var $last_name;
    var $phone_number;
    var $email;
    var $address;
    var $city;
    var $state;
    var $zip_code;
    var $country;
    var $comments;
    var $username;
    var $password;
    var $module_ids;
    var $terminal_ids;
    
	/**
     * Returns an array of headers for the export function. The column order is the same as
     * in the exported data.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     *
     * @return an array of strings
     */
    private function construct_headers ($languages)
    {
        $headers = array (
        				  'headers'=>array ($this->lang->line ('common_id'),
                                            $this->lang->line ('common_first_name'),
                                            $this->lang->line ('common_last_name'),
                                            $this->lang->line ('common_phone_number'),
                                            $this->lang->line ('common_email'),
                                            $this->lang->line ('common_address'),
                                            $this->lang->line ('common_city'),
                                            $this->lang->line ('common_state'),
                                            $this->lang->line ('common_zip'),
                                            $this->lang->line ('common_country'),
                                            $this->lang->line ('common_comments'),
                                            $this->lang->line ('employees_username'),
                                            $this->lang->line ('employees_password')
                         ),
        				  'language_dependant'=>array ( )
        );

        return $headers['headers'];
    }
    
	/**
     * Returns an array of module ids for a single employee.
     *
     * @param $id is the employee's database id
     * @return an array of module ids. If there aro no modules associated with
     * 			the employee, the array is empty.
     */
    private function __get_module_ids ($id)
    {
        $return_value = array ( );

        //
        // Retrieve the modules that this employee may access
        //
        $this->db->select   ('terminals_modules_employees.module_id');
        $this->db->distinct ( );
        $this->db->from     ('terminals_modules_employees');
        $this->db->where    ('terminals_modules_employees.employee_id =', $id);

        $query = $this->db->get ( );

        if ($query->num_rows ( ) > 0)
        {
            foreach ($query->result ( ) as $row)
            {
                array_push ($return_value, $row->module_id);
            }
        }

        return $return_value;
    }

    /**
     * Returns an array of terminal ids for a single employee.
     *
     * @param $id is the employee's database id
     * @return an array of terminal ids. If there aro no terminals associated with
     * 			the employee, the array is empty.
     */
    private function __get_terminal_ids ($id)
    {
        $return_value = array ( );

        //
        // Retrieve the modules that this employee may access
        //
        $this->db->select   ('terminals_modules_employees.terminal_id');
        $this->db->distinct ( );
        $this->db->from     ('terminals_modules_employees');
        $this->db->where    ('terminals_modules_employees.employee_id =', $id);

        $query = $this->db->get ( );

        if ($query->num_rows ( ) > 0)
        {
            foreach ($query->result ( ) as $row)
            {
                array_push ($return_value, $row->terminal_id);
            }
        }

        return $return_value;
    }
    
	/**
     * This function maps the results from the database table's row
     * into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        parent::_load ($row);
         
        $this->module_ids   = $this->__get_module_ids   ($row->employee_id);
        $this->terminal_ids = $this->__get_terminal_ids ($row->employee_id);
    }

    /**
     * This is the default constructor
     *
     * @param $id:
     * 	If this parameter is supplied, the object will represent an actual database entry.
     * 	Else it will be an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ( );
        
        //
        // Set the table name and define
        // the attribute <=> column relation.
        //
        $this->table_name        = 'employees';
        $this->column_definition = array ('id'           => 'employee_id',
                                          'first_name'   => 'first_name',
                                          'last_name'    => 'last_name',
                                          'phone_number' => 'phone_number',
                                          'email'        => 'email',
                                          'address'      => 'address',
                                          'city'         => 'city',
                                          'state'        => 'state',
                                          'zip_code'     => 'zip_code',
                                          'country'      => 'country',
                                          'comments'     => 'comments',
                                          'username'     => 'username',
                                          'password'     => 'password');
        

        //
        // Did we receive a parameter?
        //
        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }
    
	/**
     * Deletes all elements and any relation that has foreign keys to this model.
     */
    public function purge ( )
    {
        //
        // delete the sales data first
        //
        $this->db->empty_table ('sales_payments');
        $this->db->empty_table ('sales_details_taxes');
        $this->db->empty_table ('sales_details');
        $this->db->empty_table ('sales');
        
        $ids = array ( );
        foreach ($this->get_all ( ) as $employee)
        {
            array_push ($ids, $employee->id);
        }
        
        $this->delete_all ($ids);
    }    
    
    
	/**
     * This function exports the model into a matrix.
     *
     * @param $mode is the exporting mode (only the number 1 is allowed)
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Employee intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    public function export ($mode, $languages, $entities = NULL)
    {
        if ($mode != '1')
        {
            throw new Exception ('The exporting mode ' . $mode . ' is not supported.');
        }
        
        if ($entities === NULL)
        {
            $employees = array ($this);
        }
        else
        {
            $employees = $entities;
        }
        
        $employees_rows = array ($this->construct_headers ($languages));
        
        foreach ($employees as $employee)
        {
            $employee_row = array ( );

            array_push ($employee_row, $employee->id);
            array_push ($employee_row, $employee->first_name);
            array_push ($employee_row, $employee->last_name);
            array_push ($employee_row, $employee->phone_number);
            array_push ($employee_row, $employee->email);
            array_push ($employee_row, $employee->address);
            array_push ($employee_row, $employee->city);
            array_push ($employee_row, $employee->state);
            array_push ($employee_row, $employee->zip_code);
            array_push ($employee_row, $employee->country);
            array_push ($employee_row, $employee->comments);
            array_push ($employee_row, $employee->username);
            
            //TODO: export hashed passwords?
            array_push ($employee_row, '');
            
            array_push ($employees_rows, $employee_row);
        }
        
        return $employees_rows;
    }
    
	/**
     * Imports the flat data into the database.
     *
     * @param $mode is the importing mode
     * @param $data a matrix (array of array), where the outer index represents rows and the
     * 		  inner index represents columns. This paramater is without headers.
     * @param $languages is an array of languages, sorted in the same way as are the columns
     * 		  int the data parameter
     */
    public function import_flat ($mode, $data, $languages)
    {
        if ($mode == 1)
        {
            $this->purge ( );
        }
        
        foreach ($data as $row)
        {
            $employee = new Employee ($row[0]);
            //
            // FIXME: Issue #36
            //
            $employee->id             = $row[0];
            $employee->first_name     = $row[1];
            $employee->last_name      = $row[2];
            $employee->phone_number   = $row[3];
            $employee->email          = $row[4];
            $employee->address        = $row[5];
            $employee->city           = $row[6];
            $employee->state          = $row[7];
            $employee->zip_code       = $row[8];
            $employee->country        = $row[9];
            $employee->comments       = $row[10];
            
            $employee->username = $row[11];
            if (strlen ($row[12]) > 0)
            {
                $employee->password = md5 ($row[12]);
            }
            else
            {
                //
                // TODO: define a default password
                //
                $employee->password = md5 ('87654321');
            }
            
            
            if ($employee->exists ( ))
            {
                if ($mode == 1 || $mode == 2)
                {
                    $employee->update ( );
                }
            }
            else
            {
                $employee->update ( );
            }
        }
    }

    /**
     * Synchronizes the database with this object.
     */
    public function update ( )
    {
        $ret_value = parent::update ( );

        //
        // First clear all the permission and set the new or reset the old
        // ones. There is no other way to delete permissions.
        // TODO: Change this, if we want to have the proper return value.
        //       NOW WE DON'T
        //
        $this->db->delete('terminals_modules_employees', array('employee_id' => $this->id));
        foreach ($this->get_modules ( ) as $module)
        {
            foreach ($this->get_terminals ( ) as $terminal)
            {
                $this->db->set    ('module_id',   $module->id);
                $this->db->set    ('employee_id', $this->id);
                $this->db->set    ('terminal_id', $terminal->id);
                
                $this->db->insert ('terminals_modules_employees');
            }
        }
        
        //
        // Return value
        //
        return ($ret_value);
    }


    /**
     * Attempts to login employee and set session.
     * Returns boolean based on outcome.
     */
    function login ($username, $password)
    {
        $this->load->model ('company/terminal',   'terminal');
        $this->load->model ('company/appconfig' , 'appconfig');
        $this->_assign_libraries ( );
        
        $this_terminal = new Terminal ($this->appconfig->get ('this_terminal'));
        $password = md5($password);
        $employees = $this->get_all ( );

        foreach ($employees as $employee)
        {
            if ($employee->username == $username && $employee->password == $password)
            {
                foreach ($employee->get_modules ( ) as $module)
                {
                    foreach ($employee->get_terminals ( ) as $terminal)
                    {
                        if ($terminal->id == $this_terminal->id)
                        {
                            //
                            // Save the ID of the logged in employee in a cookie during the session
                            //
                            $this->session->set_userdata ('employee_id', $employee->id);

                            return (TRUE);
                        }
                    }
                }
            }
        }


        $this->logout ( );
        return (FALSE);
    }


    /**
     * Logs out the current employee by deleting
     * all session data and redirect to login.-
     */
    function logout ( )
    {
        //
        // Clean the session data that holds the logged in employee
        //
        $this->session->sess_destroy ( );
    }


    /**
     * Returns TRUE if this employee is currently logged in.-
     */
    function is_logged_in ( )
    {
        return ($this->session->userdata ('employee_id') != FALSE);
    }


    /**
     * Checks if this employee has access the specific module.
     *
     * @param $module_name: is the name of the module
     * @return true, if the employee can acces the specific module, false otherwise
     */
    function has_permission ($module_name)
    {
        //
        // If module name is empty, allow access
        //
        if ($module_name == NULL)
        {
            return (TRUE);
        }
        else if ($this->module_ids != NULL)
        {
            $found = FALSE;

            //
            // Look for the matching module name
            //
            foreach ($this->get_modules ( ) as $module)
            {
                if ($module->name == $module_name)
                {
                    $found = TRUE;
                    break;
                }
            }

            return ($found);
        }
        else
        {
            return (FALSE);
        }
    }

    /**
     * Returns an array of modules, that the employee can access in this terminal
     *
     * @return an array, it may be empty
     */
    function get_active_modules ( )
    {
        $this->load->model ('company/terminal',  'terminal');
        $this->load->model ('company/appconfig', 'appconfig');
        $this->load->model ('persons/module',    'module');
        $this->_assign_libraries ( );
        
        $ret_value = array ( );
        $this_terminal = new Terminal ($this->appconfig->get('this_terminal'));

        $this->db->select   ('mo.module_id');
        $this->db->distinct ( );
        $this->db->from     ('modules AS mo');
        $this->db->join     ('terminals_modules_employees AS per', 'mo.module_id = per.module_id');
        $this->db->where    ('per.terminal_id =', $this_terminal->id);
        $this->db->where    ('per.employee_id =', $this->id);
        $this->db->order_by ('mo.sort', 'ASC');

        $query = $this->db->get ( );

        foreach ($query->result ( ) as $row)
        {
            array_push ($ret_value, new Module ($row->module_id));
        }



        return $ret_value;
    }

    /**
     * Returns an array of module instances, as defined in the module_ids attribute.
     *
     * @return an array of module instances. It can be empty.
     */
    public function get_modules ( )
    {
        $this->load->model ('persons/module', 'module');
        $this->_assign_libraries ( );
        
        $ret_value = array ( );

        if (!($this->module_ids === NULL))
        {
            foreach ($this->module_ids as $module_id)
            {
                array_push ($ret_value, new Module($module_id));
            }
        }

        return $ret_value;
    }

    /**
     * Returns an array of terminal instances, as defined in the terminal_ids attribute.
     *
     * @return an array of Terminal instances. It can be empty.
     */
    public function get_terminals ( )
    {
        $this->load->model ('company/terminal', 'terminal');
        $this->_assign_libraries ( );
        
        $ret_value = array ( );

        if (!($this->terminal_ids === NULL))
        {
            foreach ($this->terminal_ids as $terminal_id)
            {
                array_push ($ret_value, new Terminal($terminal_id));
            }
        }

        return $ret_value;
    }
}
?>

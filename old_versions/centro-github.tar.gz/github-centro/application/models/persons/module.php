<?php
require_once 'application/models/entity.php';


/**
 * This class represents each of the functionality
 * modules of the application.-
 *
 * @author luka
 *
 */
class Module extends Entity
{
    var $id;
    var $package;
    var $name;
    var $name_lang_key;
    var $desc_lang_key;
    var $sort;
    var $terminal_ids;

    
    /**
     * This is the default constructor
     *
     * @param $id:
     * 	If this parameter is supplied, the object will represent an actual database entry.
     * 	Else it will be an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ( );
        $this->load->model ('company/terminal');
        $this->load->model ('company/appconfig');

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        $this->id 			 = $row->module_id;
        $this->package       = $row->package;
        $this->name 		 = $row->name;
        $this->name_lang_key = $row->name_lang_key;
        $this->desc_lang_key = $row->desc_lang_key;
        $this->sort 		 = $row->sort;
        $this->terminal_ids  = $this->__get_terminal_ids ($this->id);
    }


    /**
     * This function returns a single object, that mathces the specified id.
     *
     * @param $id: is the value of the primary key in the database. Default value is -1.
     * @return An instance of this class if the id exists, null otherwise.
     */
    public function get_by_id ($id = -1)
    {
        if ($id == NULL)
        {
            return NULL;
        }

        $query = $this->db->get_where ('modules', array ('module_id' => $id), 1);

        if ($query->num_rows ( ) > 0)
        {
            $this->_load($query->row ( ));
            return $this;
        }
        else
        {
            return (NULL);
        }
    }

    /**
     * Returns an array containing all existing items.
     *
     * @return Always returns an array. If there are no items the array is empty.
     */
    public function get_all ( )
    {
        $ret_value = array ( );

        $this->db->order_by ('sort', 'ASC');
        $query = $this->db->get ('modules');

        if ($query->num_rows ( ) > 1)
        {
            foreach ($query->result ( ) as $row)
            {
                $new_module = new Module ( );
                $new_module->_load ($row);
                array_push ($ret_value, $new_module);
            }
        }

        return ($ret_value);
    }

    /**
     * Returns all modules, that can be accessed from this terminal
     *
     *  @return an array of modules. It can be empty
     */
    public function get_active ( )
    {
        $ret_value = array ( );
        $this_terminal = new Terminal ($this->appconfig->get('this_terminal'));

        foreach ($this->get_all ( ) as $module)
        {
            foreach ($module->get_terminals ( ) as $terminal)
            {
                if ($terminal->id == $this_terminal->id)
                {
                    array_push ($ret_value, $module);
                    break;
                }
            }
        }

        return $ret_value;
    }


    /**
     * Checks if the object exists in the database.
     *
     * @param $id is the database id. If no id is given, the function will check the
     * 	database for the instance of this object.
     *
     * @return true, it exists, false otherwise
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Module ($this->id);
        }
        else
        {
            $o = new Module ($id);
        }

        return $o->get_by_id($o->id) != NULL;
    }

    /**
     * Synchronizes the database with this object.
     */
    public function update ( )
    {
        //FIXME: implement
    }

    /**
     * Creates an empty bag.
     *
     * @return the database id of the empty bag
     */
    protected function _insert ( )
    {
        // FIXME: implement
    }

    /**
     * Return this module's site URL.
     *
     * @return an URL string
     */
    public function get_site_URL ( )
    {
        return site_url (array ($this->package, $this->name . '_controller'));
    }

    /**
     * Returns an array of Terminal objects, that are allowed to use this module.
     *
     * @return an array of Terminal objects. It may be empty.
     */
    public function get_terminals ( )
    {
        $ret_value = array ( );

        foreach ($this->terminal_ids as $id)
        {
            array_push ($ret_value, new Terminal ($id));
        }

        return $ret_value;
    }

    /**
     * Return an array of ids for all terminals, that can use this module.
     *
     * @param $module_id is the module's id
     * @return an array of terminal ids. It may be empty.
     */
    private function __get_terminal_ids ($module_id)
    {
        $ret_value = array ( );

        $this->db->distinct ('terminal_id');
        $this->db->from     ('terminals_modules_employees');
        $this->db->where    ('module_id =', $module_id);

        $query = $this->db->get ( );

        foreach ($query->result ( ) as $row)
        {
            array_push ($ret_value, $row->terminal_id);
        }

        return $ret_value;
    }
}
?>

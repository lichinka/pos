<?php
require_once 'application/models/entity.php';

/**
 * This class represents a customer.
 *
 * @author Matjaz Cepar
 *
 */
class Customer extends Entity
{
    var $id;
    var $first_name;
    var $last_name;
    var $phone_number;
    var $email;
    var $address_1;
    var $address_2;
    var $city;
    var $state;
    var $zip_code;
    var $country;
    var $comments;
    var $account_number;
    
    /**
     * Returns an array of headers for the export function. The column order is the same as
     * in the exported data.
     *
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     *
     * @return an array of strings
     */
    private function construct_headers ($languages)
    {
        $headers = array (
        				  'headers'=>array ($this->lang->line ('common_id'),
                                            $this->lang->line ('common_first_name'),
                                            $this->lang->line ('common_last_name'),
                                            $this->lang->line ('common_phone_number'),
                                            $this->lang->line ('common_email'),
                                            $this->lang->line ('common_address_1'),
                                            $this->lang->line ('common_address_2'),
                                            $this->lang->line ('common_city'),
                                            $this->lang->line ('common_state'),
                                            $this->lang->line ('common_zip'),
                                            $this->lang->line ('common_country'),
                                            $this->lang->line ('common_comments'),
                                            $this->lang->line ('customers_account_number')
                                           ),
        				  'language_dependant'=>array ( )
        );

        return $headers['headers'];
    }

    /**
     * Constructor.-
     *
     * @param $id The ID of the object being constructed, which data 
     *            is to be loaded from the database. Defaults to an 
     *            empty instance.-
     */
    function __construct ($id = NULL)
    {
        parent::__construct ($id);

        //
        // Set the table name and define
        // the attribute <=> column relation.
        //
        $this->table_name        = 'customers';
        $this->column_definition = array ('id'             => 'customer_id',
                                          'first_name'     => 'first_name',
                                          'last_name'      => 'last_name',
                                          'phone_number'   => 'phone_number',
                                          'email'          => 'email',
                                          'address_1'      => 'address_1',
                                          'address_2'      => 'address_2',
                                          'city'           => 'city',
                                          'state'          => 'state',
                                          'zip_code'       => 'zip_code',
                                          'country'        => 'country',
                                          'comments'       => 'comments',
                                          'account_number' => 'account_number');
        
        //
        // Try to load an object instance if an ID was given
        //
        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }

    
    /**
     * Returns an array of objects that CONTAIN any of the given parameters.-
     * 
     * @param $first_name   A string contained in the first name of the 
     *                      searched customer. Defaults to NULL.-
     * @param $last_name    A string contained in the last name of the 
     *                      searched customer. Defaults to NULL.-
     * @return              An array of objects that CONTAIN any of the given
     *                      parameters or an empty array if nothing has been
     *                      found.-
     */
    function get_by_name ($first_name = NULL, $last_name = NULL)
    {
        $ret_value = array ( );

        //
        // Did we get any valid parameters?
        //
        if ($first_name != NULL)
        {
	        $this->db->select ('customers.customer_id');
	        $this->db->from   ('customers');
	        $this->db->like   ('LOWER (first_name)', strtolower ($first_name));
	        
	        //
	        // Is the second parameter also valid?
	        //
	        if ($last_name != NULL)
	        {
	           $this->db->or_like ('LOWER (last_name)', strtolower ($last_name));
	        }
	
	        $query = $this->db->get ( );
	
	        foreach ($query->result ( ) as $row)
	        {
	            $customer = new Customer ($row->customer_id);
	            array_push ($ret_value, $customer);
	        }
        }

        return ($ret_value);
    }
    
    /**
     * Deletes all elements and any relation that has foregin keys to this model.
     */
    public function purge ( )
    {
        //
        // delete the sales data first
        //
        $this->db->empty_table ('sales_payments');
        $this->db->empty_table ('sales_details_taxes');
        $this->db->empty_table ('sales_details');
        $this->db->empty_table ('sales');
        
        $ids = array ( );
        foreach ($this->get_all ( ) as $customer)
        {
            array_push ($ids, $customer->id);
        }
        
        $this->delete_all ($ids);
    }
    
	/**
     * This function exports the model into a matrix.
     *
     * @param $mode is the exporting mode (only the number 1 is allowed)
     * @param $languages is an array of the Langugage class instances, that will be
     * 		  contained within the exported data.
     * @param $entities is an optional paramater. If it is given it must be an array of
     * 		  Customer intances, that will all be exported. If it is not given, this
     *        instance will be exported.
     *
     * @return: a matrix (array of arrays). It is logically structured as rows (outer
     * 			arrays) an columns (inner arrays). The first row always contains the
     * 			headers.
     */
    public function export ($mode, $languages, $entities = NULL)
    {
        if ($mode != '1')
        {
            throw new Exception ('The exporting mode ' . $mode . ' is not supported.');
        }
        
        if ($entities === NULL)
        {
            $customers = array ($this);
        }
        else
        {
            $customers = $entities;
        }
        
        $customers_rows = array ($this->construct_headers ($languages));
        
        foreach ($customers as $customer)
        {
            $customer_row = array ( );
            
            array_push ($customer_row, $customer->id);
            array_push ($customer_row, $customer->first_name);
            array_push ($customer_row, $customer->last_name);
            array_push ($customer_row, $customer->phone_number);
            array_push ($customer_row, $customer->email);
            array_push ($customer_row, $customer->address_1);
            array_push ($customer_row, $customer->address_2);
            array_push ($customer_row, $customer->city);
            array_push ($customer_row, $customer->state);
            array_push ($customer_row, $customer->zip_code);
            array_push ($customer_row, $customer->country);
            array_push ($customer_row, $customer->comments);
            array_push ($customer_row, $customer->account_number);
            
            array_push ($customers_rows, $customer_row);
        }
        
        return $customers_rows;
    }
    
    /**
     * Imports the flat data into the database.
     *
     * @param $mode is the importing mode
     * @param $data a matrix (array of array), where the outer index represents rows and the
     * 		  inner index represents columns. This paramater is without headers.
     * @param $languages is an array of languages, sorted in the same way as are the columns
     * 		  int the data parameter
     */
    public function import_flat ($mode, $data, $languages)
    {
        if ($mode == 1)
        {
            $this->purge ( );
        }
        
        foreach ($data as $row)
        {
            $customer = new Customer ($row[0]);
            //
            // FIXME: Issue #36
            //
            $customer->id             = $row[0];
            $customer->first_name     = $row[1];
            $customer->last_name      = $row[2];
            $customer->phone_number   = $row[3];
            $customer->email          = $row[4];
            $customer->address_1      = $row[5];
            $customer->address_2      = $row[6];
            $customer->city           = $row[7];
            $customer->state          = $row[8];
            $customer->zip_code       = $row[9];
            $customer->country        = $row[10];
            $customer->comments       = $row[11];
            
            $customer->account_number = $row[12];
            
            
            if ($customer->exists ( ))
            {
                if ($mode == 1 || $mode == 2)
                {
                    $customer->update ( );
                }
            }
            else
            {
                $customer->update ( );
            }
        }
    }
}
?>

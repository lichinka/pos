<?php
require_once 'application/models/entity.php';


/**
 * This class represents a sale in the application.-
 * 
 * @author luka
 *
 */
class Sale extends Entity
{
    var $id;
    var $time;
    var $comment;
    var $customer_id;
    var $employee_id;
    var $is_active;
    var $terminal_id;


    /**
     * This is the default constructor
     *
     * @param $id The ID of the sale being constructed, which data is to be
     *            loaded from the database. Defaults to an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct ($id);
        
        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        $this->id          = $row->sale_id;
        $this->time        = $row->sale_time;
        $this->comment     = $row->comment;
        $this->customer_id = $row->customer_id;
        $this->employee_id = $row->employee_id;
        $this->is_active   = $row->is_active;
        $this->terminal_id = $row->terminal_id;
    }


    /**
     * Creates an empty bag.
     *
     * @return The row ID of the empty bag created.-
     */
    protected function _insert ( )
    {
    	//
    	// Load the Customer and Employee models
    	//
    	$this->load->model       ('persons/customer', 'customer');
    	$this->load->model       ('persons/employee', 'employee');
    	$this->load->model       ('company/terminal', 'terminal');
    	$this->_assign_libraries ( );
    	
        if ($this->id != NULL)
        {
            $this->db->set ('sale_id', $this->id);
        }
        
        //
        // Save some default values to the fields
        //
        $this->db->set ('sale_time',   '1970-01-01 00:00:00');
        $this->db->set ('comment',     '### NO VALUE ###');
        $this->db->set ('customer_id', $this->customer->get_valid_id ( ));
        $this->db->set ('employee_id', $this->employee->get_valid_id ( ));
        $this->db->set ('terminal_id', $this->terminal->get_valid_id ( ));

        $this->db->insert ('sales');

        return $this->db->insert_id ( );
    }

    
    /**
     * This function returns a single object, that matches the specified id.
     *
     * @param $id The value of the primary key in the database. Default is NULL.
     * 
     * @return An instance of this class if the id exists, null otherwise.
     */
    public function get_by_id ($id = NULL)
    {
        if ($id != NULL)
        {
	        $this->db->select ('sale_id, sale_time, comment, customer_id, employee_id, is_active, terminal_id');
	        $this->db->from   ('sales');
	        $this->db->where  ('sale_id =', $id);
	         
	        $query = $this->db->get ( );
	         
	        if ($query->num_rows ( ) > 0)
	        {
	            $this->_load ($query->row ( ));
	            return ($this);
	        }
	        else
	        {
	            return (NULL);
	        }
        }
        else
        {
        	return (NULL);
        }
    }

    
    /**
     * Returns an array containing all existing sales.
     *
     * @return Always returns an array. If there are no sales, the array is empty.
     */
    public function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('sales');

        //
        // FIXME: Issue #12: This way of creating insances may cause a huge ammount of queries.
        //
        foreach ($query->result ( ) as $row)
        {
            $sale = new Sale ($row->sale_id);
            array_push ($ret_value, $sale);
        }

        return ($ret_value);
    }

    
    /**
     * Returns an array containing all employee's active sales.-
     *
     * @param  $employee_id The ID of the employee whose sales
     *                      are to be returned.-
     *                      
     * @return Always returns an array. 
     *         If there are no active sales, the array is empty.
     */
    public function get_active_sales_by_employee ($employee_id = NULL)
    {
        $ret_value = array ( );

        //
        // Check that we got a valid ID
        //
        if ($employee_id != NULL)
        {
	        $this->db->select ('sale_id');
	        $this->db->from   ('sales');
	        $this->db->where  ('employee_id =', $employee_id);
	        $this->db->where  ('is_active', true);
	        
	        $query = $this->db->get ( );
	
	        if ($query->num_rows ( ) > 0)
	        {
		        foreach ($query->result ( ) as $row)
		        {
		            $sale = new Sale ($row->sale_id);
		            array_push ($ret_value, $sale);
		        }
	        }
        }

        return ($ret_value);
    }
    
    
    /**
     * Returns a valid ID from the table containing the objects.
     * This function is useful for creating empty buckets that need
     * valid IDs for foreign keys.-
     *
     * @return 	A valid ID from $table or NULL if nothing has been found.-
     */
    public function get_valid_id ( )
    {
    	return parent::get_valid_id ("sales", "sale_id");
    }
    

    /**
     * Checks if the object exists in the database.
     *
     * @param $id   The database id of this object. 
     *              If no id is given, the function will check the existance
     *              of the current instance in the database. 
     *
     * @return TRUE If it exists, false otherwise.-
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $id = $this->id;
        }

        $o = new Sale ($id);

        return ($o->get_by_id ($o->id) != NULL);
    }

    
    /**
     * Synchronizes the database with this object instance.-
     * 
     * @return TRUE on success, FALSE otherwise.-
     */
    public function update ( )
    {
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }
    	        
        //
        // Set the data as in the current instance
        //
        $this->db->set ('sale_time',   $this->time);
        $this->db->set ('comment',     $this->comment);
        $this->db->set ('is_active',   $this->is_active);
        $this->db->set ('customer_id', $this->get_parent_customer ( )->id);
        $this->db->set ('employee_id', $this->get_parent_employee ( )->id);
        $this->db->set ('terminal_id', $this->get_parent_terminal ( )->id);
        
        //
        // Only change this sale
        //
        $this->db->where  ('sale_id =', $this->id);
        $this->db->update ('sales');
        
        //
        // Return value
        //
        return ($this->db->affected_rows ( ) > 0);
    }

    
    /**
     * Returns the parent object (i.e. an object connected
     * to this one via a foreing key in the database).-
     *
     * @return an instance of the Customer model.-
     */
    public function get_parent_customer ( )
    {
    	//
    	// Load the Customer model
    	//
    	$this->load->model       ('persons/customer', 'customer');
    	$this->_assign_libraries ( );
    	
        return (new Customer ($this->customer_id));
    }


    /**
     * Returns the parent object (i.e. an object connected
     * to this one via a foreing key in the database).-
     *
     * @return an instance of the Employee model.-
     */
    public function get_parent_employee ( )
    {
    	//
    	// Load the Employee model
    	//
    	$this->load->model 		 ('persons/employee', 'employee');
    	$this->_assign_libraries ( );
    	
        return (new Employee ($this->employee_id));
    }
    
	/**
     * Returns the parent object (i.e. an object connected
     * to this one via a foreing key in the database).-
     *
     * @return an instance of the Terminal model.-
     */
    public function get_parent_terminal ( )
    {
    	//
    	// Load the Employee model
    	//
    	$this->load->model 		 ('company/terminal');
    	$this->_assign_libraries ( );
    	
        return (new Terminal ($this->terminal_id));
    }
    
    
    /**
     * Deletes all specified sales.
     *
     * @param $ids  An array containing the sale IDs to be deleted.-
     * 
     * @return TRUE If at least one sale was deleted, false otherwise.-
     */
    function delete_all ($ids)
    {
        $this->db->where_in ('sale_id', $ids);
        $this->db->delete   ('sales');

        return ($this->db->affected_rows ( ) > 0);
    }
    

    /**
     * Sets the time of the current sale. It defaults to now.-
     *
     * @param $time  The time of this sale, measured in the number
     *               of seconds since the Unix Epoch. We recommend
     *               using the PHP function time ( ).-
     */
    function set_time ($time = NULL)
    {
    	//
    	// Did we receive a time to save?
    	//
    	if ($time == NULL)
    	{
    		$time = time ( );
    	}
    	
    	$this->time = date ('Y-m-d H:i:d', $time);
    }
    

    /**
     * Returns an array containing Sale_detail objects in the current sale.
     * The array structure is as follows:
     *  
     *      ($row, $row, $row, ...)
     *      
     * where $row is:
     * 
     *      'detail' 	   => $sale_detail
     *      'detail_taxes' => ($tax, $tax, ...)
     * 
     * where $sale_detail is an object of type Sale_detail and $tax 
     * is an object of type Sale_detail_tax.-
     * 
     * @return An array containing the sale details in the current sale.-
     */
    function get_details ( )
    {
    	//
    	// Load the Sale_detail model
    	//
		$this->load->model 		 ('sales/sale_detail', 'sale_detail');
    	$this->_assign_libraries ( );

    	//
        // Ask for the array and return it
        //
        $ret_value = $this->sale_detail->get_by_sale ($this->id); 
        
        return $ret_value;
    }
    
    
    /**
     * Returns the subtotal (i.e. without taxes) of the 
     * current sale in valid units.- 
     * 
     * @return 	The subtotal of the current sale.-
     */
    function get_subtotal ( )
    {
    	$ret_value = 0.0;
    	
    	//
    	// Ask for the details of this sale
    	//
    	foreach ($this->get_details ( ) as $line)
    	{
    		//
    		// Accumulate the price at this detail line
    		// and don't forget to change the units
    		//
    		$ret_value += ($line['detail']->quantity   / 100) * 
    		              ($line['detail']->price_unit / 100);
    	}
    	
        //
        // Return the calculated subtotal
        //
        return $ret_value;
    }
    
    
    /**
     * Returns the total taxes (i.e. without prices) of the current sale.-
     * 
     * @return 	The taxes of the current sale formatted according
     * 			to the current locale settings.-
     */
    function get_taxes ( )
    {
    	$ret_value = 0.0;
    	
    	//
    	// Ask for the details of this sale
    	//
    	foreach ($this->get_details ( ) as $line)
    	{
    		//
    		// Calculate the price at this detail line
    		// and don't forget to change the units.
    		//
            $line_price = ($line['detail']->quantity   / 100) * 
                          ($line['detail']->price_unit / 100);
    		
    		//
    		// Calculate all taxes applied over this item
    		//
    		foreach ($line['detail_taxes'] as $tax)
    		{
    			//
    			// The first division changes the units, the second
    			// one transforms the percent into a valid coefficient.
    			//
    			$ret_value += $line_price * ($tax->percent / 100 / 100);
    		}
    	}
    	
        //
        // Return the calculated subtotal
        //
        return $ret_value;    	
    }
    
    
    /**
     * Adds the specified item to the current sale.
     * 
     * @param $item_id	The ID of the item being added.-
     * @param $quantity	The number of items to be added. It defaults to 1.-
     * 
     * @return			TRUE on success, FALSE otherwise.-
     */
    function add_item ($item_id = NULL, $quantity = 1)
	{
		$ret_value = true;

		//
		// Load the needed models
		//
		$this->load->model 		 ('items/item', 		   'item');
		$this->load->model 		 ('items/tax', 		   	   'tax');
		$this->load->model 		 ('sales/sale_detail', 	   'sale_detail');
		$this->load->model 		 ('sales/sale_detail_tax', 'sale_detail_tax');
		$this->_assign_libraries ( );
				
		//
		// Did we receive a valid item ID?
		//
		if ($item_id != NULL)
		{
			//
			// Get a reference to the item object
			//
			$item = new Item ($item_id);
			
			//
			// Check that the item exists
			//
			if ($item != NULL)
			{
				//
				// Create an empty Sale_detail object 
				// with data from the loaded item
				//
				$sale_detail = new Sale_detail ( );
				
				//
				// Set the values of all fields
				//
				$sale_detail->sale_id 	 = $this->id;
				$sale_detail->item_id 	 = $item->id;
				$sale_detail->price_cost = $item->price_cost;
				$sale_detail->price_unit = $item->price_unit;
				$sale_detail->quantity   = $quantity * 100;
				
	            //
	            // Save this sale detail to the database
	            //
		        $ret_value = $ret_value && $sale_detail->update ( );
				
		        //
		        // We should continue only if no errors occurred ...
		        //
		        if ($ret_value)
		        {
					//
					// Create an empty Sale_detail_tax object 
					// for every tax associated with the current item
					//
					foreach ($this->tax->get_by_item ($item->id) as $item_tax)
					{
						$sale_detail_tax = new Sale_detail_tax ( );
				        
						//
						// Set the values of all fields
						//
						$sale_detail_tax->sale_detail_id = $sale_detail->id;
						$sale_detail_tax->name			 = $item_tax->name;
						$sale_detail_tax->percent		 = $item_tax->percent;
						
			            //
			            // Save the tax of is sale detail to the database
			            //
				        $ret_value = $ret_value && $sale_detail_tax->update ( );
					}
		        }
			}
		}

		//
		// Return a success value
		//
		return $ret_value;
	}
    
    
    /**
     * Returns everything that is specefic to a sale.
     * @param $sale_id is the id in the centro_sales relation.
     * @param $language_id is the language id in the centro_items_lang relation.
     * @return an associative array, that has two keys:
     * 	key general_data: contains the values that are item-independant,
     * 		for detailed value info see the function get_general_sale_data;
     * 	key items: containes item-specific data,
     * 		for detailed value info see the function get_items_data
     */
    function get_bill_data($sale_id, $language_id)
    {
        $result = array('general_data' => array ( ), 'items' => array ( ));


        $result['general_data'] = $this->get_general_sale_data($sale_id);
        $result['items'] = $this->get_items_data($sale_id, $language_id);

        return $result;
    }

    /**
     * Returns the common (equal for all items) sale data.
     * @param $sale_id is the (database) id of the sale.
     * @return an associative array, composed out of two keys:
     * 	key time: is a timestamp of the sale time
     * 	key employee: contains the employee, who made the sale.
     * 		He is represented by two keys: first_name and last_name.
     */
    private function get_general_sale_data($sale_id)
    {
        $result = array('time' => '', 'employee' => array('first_name' =>'', 'last_name' => ''));

        // get the general data
        $this->db->select('cs.sale_id, cs.sale_time, cp.first_name, cp.last_name');
        $this->db->from('centro_sales AS cs');
        $this->db->join('centro_people AS cp', 'cs.employee_id = cp.person_id');
        $this->db->where('cs.sale_id =', $sale_id);

        $query_data = $this->db->get ( );

        // if it is different from 1 an error has occurred
        if ($query_data->num_rows ( ) == 1)
        {
            $result['time'] = strtotime($query_data->row ( )->sale_time);
            $result['id'] = $query_data->row ( )->sale_id;
            $result['employee']['first_name'] = $query_data->row ( )->first_name;
            $result['employee']['last_name'] = $query_data->row ( )->last_name;
        }
        else
        {
            // only for debugging
            sprintf("Error");
            $result['time'] = 0;
            $result['employee']['first_name'] = '';
            $result['employee']['last_name'] = '';
        }

        return $result;
    }

    /**
     * Returns everytitem info that is specefic to a sale.
     * @param $sale_id is the id in the centro_sales relation.
     * @param $language_id is the language id in the centro_items_lang relation.
     * @return indexed array of arrays
     * 	The outer array represents an item. The inner array are index based:
     * 		index 0: name of the item
     *  	index 1: quantity purchased
     *  	index 2: item unit price
     *  	index 3: tax name
     *  	index 4: tax percent
     */
    private function get_items_data($sale_id, $language_id)
    {
        $result = array ( );

        // get all the items data in one giant query
        $this->db->select('cil.name AS item_name, csi.quantity_purchased, csi.item_unit_price, csit.name AS tax_name,csit.percent');
        $this->db->from('centro_sales AS cs');
        $this->db->join('centro_sales_items AS csi', 'cs.sale_id = csi.sale_id');
        $this->db->join('centro_sales_items_taxes AS csit', 'cs.sale_id = csit.sale_id AND csit.item_id = csi.item_id');
        $this->db->join('centro_items_lang AS cil', 'cil.item_id = csi.item_id');
        $this->db->where('cil.language_id =',$language_id);
        $this->db->where('cs.sale_id =', $sale_id);

        $query_data = $this->db->get ( );


        foreach ($query_data->result ( ) as $row)
        {
            array_push($result, array($row->item_name, $row->quantity_purchased, $row->item_unit_price, $row->tax_name, $row->percent));
        }

        return $result;
    }
}
?>

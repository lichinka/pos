<?php
require_once 'application/models/entity.php';


/**
 * This class represents the way (or ways) a specific sale
 * has been payed.-
 * 
 * @author luka
 *
 */
class Sale_payment extends Entity
{
	var $id;
	var $payment_id;
    var $sale_id;
    var $amount;


    /**
     * Constructor.-
     *
     * @param $id The ID of the object being constructed, which data 
     * 			  is to be loaded from the database. Defaults to an 
     * 			  empty instance.-
     */
    function __construct ($id = NULL)
    {
        parent::__construct ($id);

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * This function maps the results from the database 
     * table's row into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
    	$this->id		  = $row->sale_payment_id;
    	$this->payment_id = $row->payment_id;
        $this->sale_id    = $row->sale_id;
        $this->amount     = $row->amount;
    }


    /**
     * Creates an empty bucket for this object.
     *
     * @return The row ID of the empty bucket created.-
     */
    protected function _insert ( )
    {
    	//
    	// Load the Sale model
    	//
    	$this->load->model 		 ('sales/payment', 'payment');
    	$this->load->model       ('sales/sale',    'sale');
    	$this->_assign_libraries ( );
    	
        if ($this->id != NULL)
        {
            $this->db->set ('sale_payment_id', $this->id);
        }
    	
        //
        // Save some default values to the fields
        //
        $this->db->set ('payment_id', $this->payment->get_valid_id ( ));
        $this->db->set ('sale_id',    $this->sale->get_valid_id ( ));
        $this->db->set ('amount',     -100);

        $this->db->insert ('sales_payments');

        return $this->db->insert_id ( );
    }

    
    /**
     * This function returns a single object, that matches the specified ID.-
     *
     * @param $id The value of the primary key in the database. Default is NULL.
     * 
     * @return An instance of this class if the ID exists, NULL otherwise.
     */
    public function get_by_id ($id = NULL)
    {
    	$ret_value = NULL;
    	
        if ($id != NULL)
        {
	        $this->db->select ('sale_payment_id, payment_id, sale_id, amount');
	        $this->db->from   ('sales_payments');
	        $this->db->where  ('sale_payment_id =', $id);
	         
	        $query = $this->db->get ( );
	         
	        if ($query->num_rows ( ) > 0)
	        {
	            $this->_load ($query->row ( ));
	            $ret_value = $this;
	        }
        }
        
        //
        // Return the object instance
        //
        return $ret_value;
    }

    
    /**
     * Returns an array containing all existing objects.-
     *
     * @return Always returns an array. If there are no rows,
     * 		   the array is empty.
     */
    public function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('sales_payments');

        foreach ($query->result ( ) as $row)
        {
            $sale_payment = new Sale_payment ($row->sale_payment_id);
            $ret_value[]  = $sale_payment;
        }

        return $ret_value;
    }
    
    
    /**
     * Returns an array containing all Sale_payment objects in the
     * sale with the given ID. The array structure is as follows:
     *  
     *      ($sale_payment, $sale_payment, ...)
     *      
     * where $sale_payment is an object of type Sale_payment.-
     * 
     * @return     An array containing all Sale_payment objects in 
     * 			   the sale with the given ID. If no details are 
     * 			   found, the returned array is empty.-
     */
    public function get_by_sale ($sale_id = NULL)
    {
    	$ret_value = array ( );
    	
    	//
    	// Did we receive a valid parameter?
    	//
    	if ($sale_id != NULL)
    	{
	    	//
	    	// Set the query parameters
	    	//
	        $this->db->select ('sale_payment_id');
	        $this->db->from   ('sales_payments');
	        $this->db->where  ('sale_id =', $sale_id);
	
	        $query = $this->db->get ( );
	                
	        //
	        // Found anything?
	        //
	        if ($query->num_rows ( ) > 0)
	        {
	        	//
	        	// Fill the resulting array
	        	//
	            foreach ($query->result ( ) as $result_row)
				{
                    //
                    // Create an object instance based on the ID
                    //
                    $ret_value[] = new Sale_payment ($result_row->sale_payment_id);
				} 
	        }
    	}
        
        //
        // Return the array just built
        //
        return $ret_value;
    }
    
    
    /**
     * Checks if this object exists in the database.
     *
     * @param $id   The database ID of the object to be searched for. 
     *              If no ID is given, the function will check the existance
     *              of the current object instance in the database.- 
     *
     * @return 		TRUE if the ID exists, FALSE otherwise.-
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $id = $this->id;
        }

        $o = new Sale_payment ($id);

        return ($o->get_by_id ($o->id) != NULL);
    }

    
    /**
     * Synchronizes the database with this object instance.-
     * 
     * @return TRUE on success, FALSE otherwise.-
     */
    public function update ( )
    {
        if (!$this->exists ( ))
        {
            $this->id = $this->_insert ( );
        }
        
        //
        // Set the table row data as in the current instance
        //
        $this->db->set ('payment_id', $this->get_parent_payment ( )->id);
        $this->db->set ('sale_id',    $this->get_parent_sale ( )->id);
        $this->db->set ('amount',     $this->amount);
        
        //
        // Change this row only
        //
        $this->db->where  ('sale_payment_id =', $this->id);
        $this->db->update ('sales_payments');
        
        //
        // Return value
        //
        return ($this->db->affected_rows ( ) > 0);
    }

    
    /**
     * Returns the parent object (i.e. an object connected
     * to this one via a foreing key in the database).-
     *
     * @return an instance of the Payment model.-
     */
    public function get_parent_payment ( )
    {
        //
        // Load the Payment model
        //
        $this->load->model       ('sales/payment', 'payment');
        $this->_assign_libraries ( );
        
        return (new Payment ($this->payment_id));
    }
    
    
    /**
     * Returns the parent object (i.e. an object connected
     * to this one via a foreing key in the database).-
     *
     * @return an instance of the Sale model.-
     */
    public function get_parent_sale ( )
    {
    	//
    	// Load the Sale model
    	//
    	$this->load->model 		 ('sales/sale', 'sale');
    	$this->_assign_libraries ( );
    	
        return (new Sale ($this->sale_id));
    }
    
    
    /**
     * Deletes all specified IDs from the corresponding database tables.-
     *
     * @param $ids  An array containing the IDs to be deleted.-
     * 
     * @return 		TRUE if at least one row has been deleted, FALSE otherwise.-
     */
    function delete_all ($ids)
    {
        $this->db->where_in ('sale_payment_id', $ids);
        $this->db->delete   ('sales_payments');

        return ($this->db->affected_rows ( ) > 0);
    }
}

?>

<?php
require_once 'application/models/entity.php';


/**
 * This class represents a host running the application.-
 *
 * @author luka
 *
 */
class Terminal extends Entity
{
    var $id;
    var $name;
    var $store_id;    
    
    
    /**
     * Constructor.-
     *
     * @param $id The ID of the object being constructed, which data 
     *            is to be loaded from the database. Defaults to an 
     *            empty instance.-
     */
    function __construct ($id = NULL)
    {
        parent::__construct ($id);

        //
        // Set the table name and define
        // the attribute <=> column relation.
        //
        $this->table_name        = 'terminals';
        $this->column_definition = array ('id'       => 'terminal_id',
                                          'name'     => 'name',
                                          'store_id' => 'store_id');
        //
        // Set the foreign keys
        //
        $this->foreign_keys = array ('Store' => 'store_id');
        
        //
        // Try to load an object instance if an ID was given
        //
        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }

    
    /**
     * Returns the parent object.
     *
     * @return an instance of the Company model
     */
    public function get_parent_store ( )
    {
        //
        // Load the Store model
        //
        $this->load->model       ('company/store', 'store');
        $this->_assign_libraries ( );
    	
        return parent::get_parent ('Store');
    }
}
?>

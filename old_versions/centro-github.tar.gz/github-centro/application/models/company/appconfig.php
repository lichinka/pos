<?php
require_once 'application/models/entity.php';

/**
 * This class represents the centro_app_config table.
 *
 * @author unknown, Matjaz Cepar
 *
 */
class Appconfig extends Entity
{

    var $id;
    var $name;
    var $value;
    var $terminal_id;

    /**
     * This is the default constructor
     *
     * @param $id:
     * 	If this parameter is supplied, the object will represent an actual database entry.
     * 	Else it will be an empty instance.
     */
    function __construct ($id = NULL)
    {
        parent::__construct($id);
        $this->load->model ('company/terminal', 'database_terminal');

        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }

    /**
     * This function maps the results from the database table's row
     * into this object's attributes.
     *
     * @param $row is a single database row
     */
    protected function _load ($row)
    {
        $this->id = $row->app_config_id;

        //
        // FIXME: rename the key column into the name column
        //
        $this->name = $row->key;
        $this->value = $row->value;
        $this->terminal_id = $row->terminal_id;
    }


    /**
     * This function returns a single object, that mathces the specified id.
     *
     * @param $id: is the value of the primary key in the database. Default value is -1.
     * @return An instance of this class if the id exists, null otherwise.
     */
    public function get_by_id ($id = -1)
    {
        if ($id == NULL)
        {
            return NULL;
        }

        $this->db->select ('app_config.app_config_id, app_config.key, app_config.value, app_config.terminal_id');
        $this->db->from   ('app_config');
        $this->db->where  ('app_config.app_config_id =', $id);
         
        $query = $this->db->get ( );
         
        if ($query->num_rows ( ) > 0)
        {
            $this->_load ($query->row ( ));
            return ($this);
        }
        else
        {
            return (NULL);
        }
    }

    /**
     * Returns an array containing all existing items.
     *
     * @return Always returns an array. If there are no items the array is empty.
     */
    public function get_all ( )
    {
        $ret_value = array ( );

        $query = $this->db->get ('app_config');

        //
        // FIXME: Issue #12: This way of creating insances may cause a huge ammount of queries.
        //
        foreach ($query->result ( ) as $row)
        {
            $app_config = new Appconfig ($row->app_config_id);
            array_push ($ret_value, $app_config);
        }

        return ($ret_value);
    }

    /**
     * Checks if the object exists in the database.
     *
     * @param $id is the database id. If no id is given, the function will check the
     * 	database for the instance of this object.
     *
     * @return true, it exists, false otherwise
     */
    public function exists ($id = NULL)
    {
        if ($id == NULL)
        {
            $o = new Appconfig ($this->id);
        }
        else
        {
            $o = new AppConfig ($id);
        }

        return $o->get_by_id($o->id) != NULL;
    }

    /**
     * Synchronizes the database with this object.
     */
    public function update ( )
    {
        $id = $this->id;
        if (!$this->exists ( ))
        {
            $id = $this->_insert ( );
        }

        $this->db->set    ('key', $this->name);
        $this->db->set    ('value', $this->value);
        $this->db->set    ('terminal_id', $this->terminal->id);
        $this->db->where  ('app_config_id =', $id);
        $this->db->update ('app_config');
    }

    /**
     * Creates an empty bag.
     *
     * @return the database id of the empty bag
     */
    protected function _insert ( )
    {
        if ($this->id != NULL)
        {
            $this->db->set ('app_config_id', $this->id);
        }
        $this->db->set ('key', '### NO VALUE ###');
        $this->db->set ('value', '### NO VALUE ###');
        $this->db->set ('terminal_id', 1);
        // FIXME: revisit whe updating the database

        $this->db->insert ('app_config');

        return $this->db->insert_id ( );
    }

    /**
     * Returns the parent object.
     *
     * @return an instance of the Terminal model
     */
    public function get_parent_terminal ( )
    {
        return new Terminal ($this->terminal_id);
    }


    ////////////////////////////////////////////////////////////////////////
    /////////////////// Only deprecated fields bellow //////////////////////
    ////////////////////////////////////////////////////////////////////////


    /**
     * This constant represents the table name.
     * @var string
     */
    const TABLE_NAME = 'app_config';

    /**
     * Returns all keys
     * @return a database object
     * @deprecated
     */
    function get_all_deprecated ( )
    {
        //
        // FIXME: this method is used in the hooks package, which is currently disabled
        //
        $this->db->from (self::TABLE_NAME);
        $this->db->order_by ("key", "asc");
        return $this->db->get ( );
    }

    /**
     * Gets the values for multiple keys in a single query.
     * @param $keys is an array of keys
     * @return an associative array, that maps keys to values
     * @deprecated
     */
    function get_multiple ($keys)
    {
        $this->db->from (self::TABLE_NAME);
        $this->db->where_in ('key', $keys);
        $query = $this->db->get ( );

        $result = array ( );
        if ($query->num_rows ( ) > 0)
        {
            foreach ($query->result ( ) as $row)
            {
                $result[$row->key] = $row->value;
            }
        }

        return $result;
    }

    /**
     * Returns a single value of the key
     * @param $key
     * @return a String key
     * @deprecated
     */
    function get ($key)
    {
        $query = $this->db->get_where (self::TABLE_NAME, array ('key' => $key), 1);

        if ($query->num_rows ( ) == 1)
        {
            return $query->row ( )->value;
        }

        return "";

    }

    /**
     * Saves a key, value pair into the database.
     * @param string $key
     * @param string $value
     * @deprecated
     */
    function save ($key, $value)
    {
        //
        // FIXME: a very nasty workaround, that accounts for the new terminal_id
        //
        $config_data=array (
		'key'=>$key,
		'value'=>$value,
        'terminal_id'=>1
        );

        if (!$this->exists ($key))
        {
            return $this->db->insert (self::TABLE_NAME, $config_data);
        }

        $this->db->where ('key', $key);
        return $this->db->update (self::TABLE_NAME, $config_data);
    }

    /**
     * Saves all the key, value pairs as a transaction.
     * @param $data is an associative array, that map keys to values.
     * @deprecated
     */
    function batch_save ($data)
    {
        $success=true;

        //Run these queries as a transaction, we want to make sure we do all or nothing
        $this->db->trans_start ( );
        foreach ($data as $key=>$value)
        {
            if (!$this->save ($key, $value))
            {
                $success = false;
                break;
            }
        }

        $this->db->trans_complete ( );
        return $success;

    }

    /**
     * Deletes a single key from the database.
     * @param $key is the key, that will be deleted.
     * @deprecated
     */
    function delete ($key)
    {
        return $this->db->delete(self::TABLE_NAME, array('key' => $key));
    }

    /**
     * Empties the table.
     * @deprecated
     */
    function delete_all ( )
    {
        return $this->db->empty_table(self::TABLE_NAME);
    }
}

?>
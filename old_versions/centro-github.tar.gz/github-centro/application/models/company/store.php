<?php
require_once 'application/models/entity.php';


/**
 * This class represents a bussiness unit inside a company.-
 *
 * @author luka
 *
 */
class Store extends Entity
{
    var $id;
    var $name;
    var $address;
    var $telephone;
    var $company_id;
    
    
    /**
     * Constructor.-
     *
     * @param $id The ID of the object being constructed, which data 
     *            is to be loaded from the database. Defaults to an 
     *            empty instance.-
     */
    function __construct ($id = NULL)
    {
        parent::__construct ($id);

        //
        // Set the table name and define
        // the attribute <=> column relation.
        //
        $this->table_name        = 'stores';
        $this->column_definition = array ('id'         => 'store_id',
                                          'name'       => 'name',
                                          'address'    => 'address',
                                          'telephone'  => 'telephone',
                                          'company_id' => 'company_id');
        //
        // Set the foreign keys
        //
        $this->foreign_keys = array ('Company' => 'company_id');
        
        //
        // Try to load an object instance if an ID was given
        //
        if ($id != NULL)
        {
            $this->get_by_id ($id);
        }
    }


    /**
     * Returns the parent object.
     *
     * @return an instance of the Company model
     */
    public function get_parent_company ( )
    {
        //
        // Load the Company model
        //
        $this->load->model       ('company/company', 'company');
        $this->_assign_libraries ( );
    	
    	return parent::get_parent ('Company');
    }
}

?>

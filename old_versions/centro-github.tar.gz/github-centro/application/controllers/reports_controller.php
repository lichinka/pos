<?php
require_once (APPPATH . '/controllers/secure_area.php');


/**
 * The entry point of the "Reports" module.-
 * 
 * @author luka
 *
 */
class Reports_controller extends Secure_area
{
    private $time_intervals = array (1 => 'reports_today',
                                     2 => 'reports_this_month');
    
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_link_content_template ( )
    {
        $ret_value = array ('links' => array ( ));
        
        //
        // General page data
        //
        $ret_value['page_title'] = $this->lang->line ('reports_time_interval');

        foreach ($this->time_intervals as $key => $value)
        {
            $link_data = array ( );
            
            $link_data['link'] = site_url ('reports_controller/view/' . $key);
            $link_data['text'] = $this->lang->line ($value);
            
            array_push ($ret_value['links'], $link_data);
        }
        
        
        
        return $ret_value;
    }


    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_content_template ($reports)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // The title is reports
        //
        $ret_value['page_title']    = $this->lang->line ('reports_report'); 
        //
        // The list column titles
        //
        $ret_value['column_titles'] = array (array ('title' => $this->lang->line ('reports_date')),
        									 array ('title' => $this->lang->line ('reports_sale_id')),
        									 array ('title' => $this->lang->line ('reports_items_purchased')));
        //
        // Display or hide the 'No elements' message?
        //
        if (count ($reports) == 0)
        {
            $ret_value['display_status'] = 'display: inline;';
            $ret_value['empty_table']    = $this->lang->line ('common_nothing_to_display');
        }
        else
        {
            $ret_value['display_status'] = 'display: none;';
            $ret_value['empty_table']    = '';
        }

        //
        // Set the actual report data for the whole table of records
        //
        $ret_value['table_data'] = array ( );
        
        foreach ($reports as $report)
        {
            $report_data = array ('date'         => $report['date'],
                          	      'sale_id'      => $report['sale_id']);
            
            if (count ($report['items']) > 0)
            {
                $report_data['item'] = $report['items'][0];
            }
            else
            {
                $report_data['item'] = '&nbsp';
            }
            //
        	// Save the data of first row
        	//
            array_push ($ret_value['table_data'], $report_data);
            
            //
            // Append rows for each other item
            //
            for ($i = 1; $i < count ($report['items']); $i++)
            {
                $report_data = array ('date'         => '&nbsp',
                        	          'sale_id'      => '&nbsp',
                                      'item'         => $report['items'][$i]);
                
                //
            	// Save the data of the current row
            	//
                array_push ($ret_value['table_data'], $report_data);
            }
            
        	
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;    
    }
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
	 *  
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_buttons_template ( )
    {
        return $this->_build_link_buttons_template ( );
    }
    
    
	/**
     * Constructor
     */
    function __construct ( )
    {
        parent::__construct ('reports');
        
        $this->load->library ('parser');
    }
    
    
    /**
     * The default entry point of this controller.-
     */
    public function index ( )
    {
        //
	    // Remember this address as a navigation node to come back later
	    //
	    $this->navigation_stack->clear_stack ( );
	    $this->navigation_stack->push ( );
	    
	    //
	    // The data about the registered employee is held in the parent class
	    //
	    $data['registered_employee'] = $this->registered_employee;
	    $data['active_terminal']     = $this->active_terminal;
	    $data['module_name']         = $this->lang->line ('module_reports');
	    
	
	    //
	    // Fill the page templates wih data
	    //
	    $page_content = $this->_build_link_content_template ( );
	       
	    $data['content'] = $this->parser->parse ('entry_view', 
	      										 $page_content, 
	       										 true);
	    //
	    // Load and display the edit form
	    //
	    $this->load->view ('skeleton', $data);
    }
    
    /**
     * Displays the report.
     * 
     * @param $time_interval is the key from the time_intervals attribute.
     */
    public function view ($time_interval)
    {
        //
        // Create mock items
        //
        $this->load->model ('items/item');
        $items = array ( );
        foreach ($this->item->get_all ( ) as $item)
        {
            array_push ($items, $item->name);
        }
        
        
        //
        // Fetch the reports (mock report)
        //
        if ($time_interval == 1)
        {
            //
            // Today
            //
            $reports = array ( array ('date'    => date('d. m. Y / H:i:s', strtotime ('today')),
                                      'sale_id' => 777,
                                      'items'   => $items));
        }

        else if ($time_interval == 2)
        {
            //
            // Last month
            //
            $reports = array ( array ('date'    => date('d. m. Y / H:i:s', strtotime ('today')),
                                      'sale_id' => 777,
                                      'items'   => $items),
                               
                               array ('date'    => date('d. m. Y / H:i:s', strtotime ('yesterday')),
                                      'sale_id' => 666,
                                      'items'   => array_slice ($items, 1 , -2)),
                               
                               array ('date'    => date('d. m. Y / H:i:s', strtotime ('last week')),
                                      'sale_id' => 555,
                                      'items'   => array ( )));
        }
        
        //
        // Prepare the navigation stack to work inside this module
        //
        $this->navigation_stack->push ( );
    	
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['active_terminal']     = $this->active_terminal;
        $data['module_name']         = $this->lang->line ('module_reports');
        
        
        
        //
        // Fill the page templates with data
        //
        $page_content = $this->_build_table_content_template ($reports);
        $page_buttons = $this->_build_table_buttons_template ( );
        
        $data['content'] = $this->parser->parse ('reports/table_reports', 
        										 $page_content,
        										 true);
        $data['buttons'] = $this->parser->parse ('entry_view_buttons', 
        										 $page_buttons,
        										 true);
        //
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
    }
}
?>
<?php
class No_Access extends Controller 
{
	/**
	 * Constructor
	 */
	function __construct ( )
	{
		parent::Controller ( );
		$this->load->model ('persons/module', 'Module', TRUE);
	}
	
	/**
	 * Restricts access to the module received as parameter.-
	 * 
	 * @param $module_id
	 */
	function index ($module_id = -1)
	{
		$restricted_module = $this->Module->get_by_name ($module_id);

		$data['module_name'] = $restrict_module->name;
		$this->load->view ('no_access', $data);
	}
}
?>
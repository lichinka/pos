<?php
class Test_common extends Controller
{
    function __construct ( )
    {
        parent::Controller ( );
    }

    function index ( )
    {
        echo ("Starting the common package test case\n");
         
        echo ("\tTesting sale model\n");
        $this->load->model ('common/sale');
         
        $a = $this->sale->exists (-1);
        $b = $this->sale->exists (1);

        $c = $this->sale->get_sale_items (-1);
        $d = $this->sale->get_sale_items (1);

        $e = $this->sale->get_customer (-1);
        $f = $this->sale->get_customer (1);

        unset ($a, $b, $c, $d, $e, $f);
        echo ("\tDone\n");

        echo ("Done\n");
    }
}
<?php
class test_pdf extends Controller {

    function __construct()
    {
        parent::Controller();
    }
    
    function index()
    {
        //
        // A new line, that prevents outputing the PDF, is in the buffer.
        //
        ob_clean ( );
        
    	// fetch the bill's data
		$this->load->model ('company/terminal');
		$this->load->model ('sales/sale');
		
		$terminal = new Terminal (1);
		$sale = new Sale (1);
    	
        // create the bill
        $this->load->library ('pdf');
       	$this->pdf->create_bill ($sale, $terminal);
        		      
        //Close and output PDF document
        $this->pdf->Output ('racun.pdf', 'I');        
    }
}
?>

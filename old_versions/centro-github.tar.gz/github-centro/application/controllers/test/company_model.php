<?php
require_once(APPPATH . '/controllers/test/Toast.php');


/**
 * This class tests the company model.
 * @author Matjaz Cepar
 *
 */
class Company_model extends Toast
{
    private function company_model_test ($company)
    {
        $success = true;

        $success = $success && $this->_assert_equals ($company->id, 1);
        $success = $success && $this->_assert_equals ($company->name, 'Centro, Inc.');
        $success = $success && $this->_assert_equals ($company->address, 'Cesta na PM 123');
        $success = $success && $this->_assert_equals ($company->identification, 'INSERT ID INTO THE DATABASE');

        return $success;
    }

    private function store_model_test ($store)
    {
        $success = true;

        $success = $success && $this->_assert_equals ($store->id , '1');
        $success = $success && $this->_assert_equals ($store->name , 'Virtual store');
        $success = $success && $this->_assert_equals ($store->address , 'Virtual street 1911');
        $success = $success && $this->_assert_equals ($store->telephone , '040 666 777');
        $success = $success && $this->_assert_equals ($store->get_parent_company ( )->id , '1');

        return $success;
    }

    private function terminal_model_test ($terminal)
    {
        $success = true;

        $success = $success && $this->_assert_equals ($terminal->id , '1');
        $success = $success && $this->_assert_equals ($terminal->name ,'555-444-333-222');
        $success = $success && $this->_assert_equals ($terminal->get_parent_store ( )->id , '1');

        return $success;
    }


    function __construct ( )
    {
        parent::Toast (__FILE__);
    }

    function test_company ( )
    {
        $this->load->model ('company/company');

        // get a valid company
        $company = $this->company->get_by_id (1);
        if (!$this->company_model_test ($company))
        {
            $this->message = 'Get by id failed';
            return;
        }

        // get null
        $company = $this->company->get_by_id ( );
        if (!$this->_assert_equals ($company, NULL))
        {
            $this->message = 'Get by id failed';
            return;
        }

        // get null
        $company = $this->company->get_by_id (-1);
        if (!$this->_assert_equals ($company, NULL))
        {
            $this->message = 'Get by id failed';
            return;
        }


        $companies = $this->company->get_all ( );
        foreach ($companies as $company)
        {
            if (!$this->company_model_test ($company))
            {
                $this->message = 'Get all failed';
                return;
            }
        }

        // test exists
        $exists = $this->company->exists (1);
        if (!$this->_assert_true ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        $exists = $this->company->exists (-1);
        if (!$this->_assert_false ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }


        $instance = new Company (1);
        $exists = $instance->exists ( );
        if (!$this->_assert_true ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        $instance = new Company (-1);
        $exists = $instance->exists ( );
        if (!$this->_assert_false ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }
    }

    function test_store ( )
    {
        $this->load->model ('company/store');

        // get a valid store
        $store = $this->store->get_by_id (1);
        if (!$this->store_model_test ($store))
        {
            $this->message = 'Get by id failed';
            return;
        }

        // get null
        $store = $this->store->get_by_id ( );
        if (!$this->_assert_equals ($store, NULL))
        {
            $this->message = 'Get by id failed';
            return;
        }

        // get null
        $store = $this->store->get_by_id (-1);
        if (!$this->_assert_equals ($store, NULL))
        {
            $this->message = 'Get by id failed';
            return;
        }


        $stores = $this->store->get_all ( );
        foreach ($stores as $store)
        {
            if (!$this->store_model_test ($store))
            {
                $this->message = 'Get all failed';
                return;
            }
        }


        // test exists
        $exists = $this->store->exists (1);
        if (!$this->_assert_true ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        $exists = $this->store->exists (-1);
        if (!$this->_assert_false ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }


        $instance = new Store (1);
        $exists = $instance->exists ( );
        if (!$this->_assert_true ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        $instance = new Store (-1);
        $exists = $instance->exists ( );
        if (!$this->_assert_false ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }
    }

    function test_terminal ( )
    {
        $this->load->model ('company/terminal');

        // get a valid terminal
        $terminal = $this->terminal->get_by_id (1);
        if (!$this->terminal_model_test ($terminal))
        {
            $this->message = 'Get by id failed';
            return;
        }

        // get null
        $terminal = $this->terminal->get_by_id ( );
        if (!$this->_assert_equals ($terminal, NULL))
        {
            $this->message = 'Get by id failed';
            return;
        }

        // get null
        $terminal = $this->terminal->get_by_id (-1);
        if (!$this->_assert_equals ($terminal, NULL))
        {
            $this->message = 'Get by id failed';
            return;
        }


        // get all
        $terminals = $this->terminal->get_all ( );
        $success = False;
        foreach ($terminals as $terminal)
        {
            $success = $success || $this->terminal_model_test ($terminal);
        }

        if (!$this->_assert_true ($success) || !$this->_assert_equals (count ($terminals) , 2))
        {
            $this->message = 'Get all failed';
            return;
        }

        // test exists
        $exists = $this->terminal->exists (1);
        if (!$this->_assert_true ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        $exists = $this->terminal->exists (-1);
        if (!$this->_assert_false ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        // exists
        $instance = new Terminal (1);
        $exists = $instance->exists ( );
        if (!$this->_assert_true ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }

        $instance = new Terminal (-1);
        $exists = $instance->exists ( );
        if (!$this->_assert_false ($exists))
        {
            $this->message = ('Exists failed');
            return;
        }
    }

    function test_appconfig ( )
    {
        $this->load->model('company/appconfig');
         
        $a = $this->appconfig->get_by_id (1);
        $b = $this->appconfig->get_by_id ( );
        $c = $this->appconfig->get_by_id (-1);
         
        $d = $this->appconfig->get_all ( );

        $this->_assert_true(false);
        $this->message = 'Change the database';
    }
}
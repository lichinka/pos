<?php

/**
 * Controllers that are considered secure extend Secure_area.
 * Optionally a $module_name can be set to also check if a
 * user can access a particular module in the system.-
 */
class Secure_area extends Controller 
{
	var $registered_employee;
	var $active_terminal;
	
	
	/**
	 * Constructor
	 * 
	 * @param $module_name
	 */
	function __construct ($module_name = NULL)
	{
		parent::Controller ( );
		$this->load->model ('persons/employee',  'employee');
		$this->load->model ('company/appconfig', 'appconfig');
		$this->load->model ('company/terminal',  'terminal');
		
		//
		// Check if there is anyone logged in
		//
		if ($this->employee->is_logged_in ( ))
		{
			//
			// Build a new employee object with th ID from the current session
			//
			$this->registered_employee = new Employee ($this->session->userdata ("employee_id"));
			
			//
			// Find out an whisch terminal is the application running.
			//
			$this->active_terminal = new Terminal ($this->appconfig->get ('this_terminal'));
			
			//
			// Check if this employee has permission to access this module
			//
			if (! $this->registered_employee->has_permission ($module_name))
			{
				redirect ('no_access/' . $module_name);
			}
		}
		else
		{
			redirect ('login');
		}		
	}
}
?>
<?php
require_once (APPPATH . "/controllers/secure_area.php");

class Import_controller extends Secure_area
{
    private $importables = array (
    1=>'items_item',
    2=>'customers_plural',
    3=>'employees_plural'
    );

    private $modes = array (
    1=>'import_mode_replace_all',
    2=>'import_mode_replace_existing',
    3=>'import_mode_no_replace'
    );
    
    var $error;
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_content_template ( )
    {
        $ret_value = array ( );

        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
        
        //
        // General page data
        //
        $ret_value['page_title'] 	= $this->lang->line ('import');
        $ret_value['import_object'] = $this->lang->line ('import_relation');
        $ret_value['import_mode']   = $this->lang->line ('import_mode');
        $ret_value['import_files']  = $this->lang->line ('import_upload');
        $ret_value['import_notes']  = $this->lang->line ('export_notes');

        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/import/', 
        								   	   array ('id' => 'import_form'));
        $ret_value['form_close'] = form_close ( );
        
        //
        // Data about the import parameters
        //
        
        //
        // Notes
        //
        $ret_value['notes'] = array ( );
        
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('import_mode_replace_all_warning')));
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('import_number_files_warning')));
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('import_employees_password_warning')));
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('import_multiple_files_warning')));
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('import_items_multiple_files_warning')));
        
        
        
        $ret_value['objects'] = array ( );
        
        //
        // Field "Select object"
        //
        $field = array ( );
        
        $dropdown_items = array ( );
        foreach ($this->importables as $key => $value)
        {
            $dropdown_items[$key] = $this->lang->line ($value);
        }

        $field['label'] = form_label ($this->lang->line ('import_relation'),
        				              'import',
                                      array ('class'=>'wide'));
                         
        $field['input'] = form_dropdown ('import', 
                                         $dropdown_items, 
                                         '' ,
                                         'id = import');
        							  
        
        array_push ($ret_value['objects'], $field);

        //
        // Field "Import mode"
        //
        $ret_value['modes'] = array ( );
        
        //
        // import mode dropdown
        //
        $field = array ( );
        $dropdown_items = array ( );
        foreach ($this->modes as $key => $value)
        {
            $dropdown_items[$key] = $this->lang->line ($value);
        }
        $field['label'] = form_label ($this->lang->line ('import_mode'), 
        							  'mode',
                                      array ('class'=>'wide'));
                                      
        $field['input'] = form_dropdown ('mode', 
                                         $dropdown_items, 
                                         '', 
                                         'id = mode');
        
        array_push ($ret_value['modes'], $field);
        
        
        //
        // Field "Upload slots"
        //
        $ret_value['upload_slots'] = array ( );
        for ($i = 0; $i < 3; $i++)
        {
            $field = array ( );
            
            $field['label'] = form_label (($i + 1) . '. ' . $this->lang->line ('import_file'), 
            							  'upload' . $i,
                                          array ('class'=>'wide'));
                                          
            $field['input']  = form_upload ('file' . $i, 
            							    '', 
            							    'id=upload' . $i);
            
            array_push ($ret_value['upload_slots'], $field);
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }

    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_buttons_template ( )
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
        							   		array ('title' => $this->lang->line ('common_back')));
        
    	//
    	// The SAVE (or Submit) button
    	//
    	$ret_value['submit_button'] = anchor ('#', ' ',
        							   	 	  array ('title'   => $this->lang->line ('common_submit'),
        							   	 	  //
        							   	 	  // This code connects this anchor with the Submit functionality
        							   	 	  //
        							   	 	  'onClick' => "return validate_form_data (event, document.forms[0]);"));
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }    


    /**
     * This function returns the correct data for building the export view.
     *
     * @return an array, that can be used to parse a template.
     */
    private function _get_main_template_data ( )
    {
        $data = array ( );

        //
        // create form
        //
        $data['form_open']   = form_open_multipart ('export-import/import_controller/import', array ('id' => 'submit_form'));
        $data['form_close']  = form_close ( );
        $data['form_submit'] = form_submit('submit', $this->lang->line ('import'));

        //
        // static text
        //
        $data['text_select_relation']     = $this->lang->line ('export_relation');
        $data['text_import_mode']         = $this->lang->line ('import_mode');
        $data['text_upload_files']        = $this->lang->line ('import_upload');
        $data['text_replace_all_warning'] = $this->lang->line ('import_mode_replace_all_warning') . '!';

        //
        // select what to import dropdown
        //
        $dropdown_items = array ( );
        foreach ($this->importables as $key => $value)
        {
            $dropdown_items[$key] = $this->lang->line ($value);
        }

        $data['relation_label'] = form_label ($this->lang->line ('import_relation'), 'import');
        $data['relation_dropdown'] = form_dropdown ('import', $dropdown_items, '' ,'id = import');

        //
        // import mode dropdown
        //
        $dropdown_items = array ( );
        foreach ($this->modes as $key => $value)
        {
            $dropdown_items[$key] = $this->lang->line ($value);
        }
        $data['mode_label'] = form_label ($this->lang->line ('import_mode'), 'mode');
        $data['mode_dropdown'] = form_dropdown ('mode', $dropdown_items, '', 'id = mode');

        //
        // upload file fields
        //
        $data['upload_slots'] = array ( );
        $upload_slot = array ( );
        for ($i = 0; $i < 4; $i++)
        {
            $upload_slot['upload_label'] = form_label ('labela', 'upload' . $i);
            $upload_slot['upload_file']  = form_upload ('file' . $i, '', 'id=upload' . $i);
            array_push ($data['upload_slots'], $upload_slot);
        }


        return $data;
    }

    /**
     * Validates the data retrieved from the input.
     *
     * @return a string of errors, if it is an empty string, there were no validation errors
     */
    private function _validate_import ( )
    {
        $this->form_validation->set_rules ('import', $this->lang->line ('import_relation'), 'trim|required');
        $this->form_validation->set_rules ('mode', $this->lang->line ('import_mode'), 'trim|required');

        if ($this->form_validation->run ( ) == false)
        {
            return validation_errors (' ',' ');
        }
        else
        {
            return '';
        }
    }

    /**
     * Retrieves all the files from the input.
     *
     * @return an asociative array, that maps field names to the parsed csv file, that was
     * 		   uploaded by that field.
     */
    private function _get_csv_files ( )
    {
        $files = array ( );

        foreach($_FILES as $key => $value)
        {
            if(!empty($value['name']))
            {
                $files[$key] = $this->csv->read_file ($key);
            }
        }

        return $files;
    }

    /**
     * Determines which languages were used in the export function.
     *
     * @param $headers is the parsed first row of the csv file
     * @return an array instances of the Language model class.
     */
    private function _extract_languages ($headers)
    {
        $return_val = array ( );
        $languages = $this->language->get_all ( );
        $short_names = array ( );
        foreach ($headers as $header)
        {
            $temp = explode ('_', $header);
            $lang = strtoupper ($temp[count ($temp) - 1]);

            if (count ($temp) > 1 && !in_array ($lang, $short_names))
            {
                array_push ($short_names, $lang);
            }
             
        }

        foreach ($languages as $language)
        {
            foreach ($short_names as $short_name)
            {
                if ($language->short_name === $short_name)
                {
                    array_push ($return_val, $language);
                }
            }
        }

        if (count ($return_val) != count($short_names))
        {
            $this->error = $this->lang->line ('import_error_number_languages');
        }

        return $return_val;
    }

    /**
     * A function, that compares two parsed csv rows by their first column.
     * @param $row1 is the first row
     * @param $row2 is the second row
     *
     * @return Standard compare output.
     */
    private function _compare ($row1, $row2)
    {
        if ($row1[0] == $row2[0])
        {
            return 0;
        }
        if ($row1[0] < $row2[0])
        {
            return -1;
        }
        if ($row1[0] > $row2[0])
        {
            return 1;
        }
        return -1;
    }

    /**
     * Merges two sorted matrixes into a single matrix.
     *
     * @param $old data is the current state of the dabase
     * @param $new_data is the csv, that will be imported
     * @param $mode is the importing mode
     * @param $inline data contains indexes to the columns with the inlined data (mainly the
     * 		  actual sizes column and item tax_data). This important in importing mode 3,
     * 		  because if these columns differ, they are considered new.
     * @return a merged matrix
     */
    private function _merge ($old_data, $new_data, $mode, $inline_data = array ( ))
    {
        if ($mode == 1)
        {
            return $new_data;
        }

        $merged = array ( );

        while (!empty ($old_data) && !empty ($new_data))
        {
            $row1 = $old_data[0];
            $row2 = $new_data[0];

            if ($row1[0] < $row2[0])
            {
                array_push ($merged, $row1);
                array_shift ($matrix1);
            }
            else if ($row1[0] > $row2[0])
            {
                array_push ($merged, $row2);
                array_shift ($new_data);
            }
            else if ($row1[0] == $row2[0])
            {
                if ($mode == 2)
                {
                    array_push ($merged, $row2);
                    array_shift ($old_data);
                    array_shift ($new_data);
                }
                else if ($mode == 3)
                {
                    foreach ($inline_data as $column_index)
                    {
                        if ( $column_index > count ($row1) - 1)
                        {
                            array_push ($row1, $row2[$column_index]);
                        }
                        else
                        {
                            $row1[$column_index] = $row2[$column_index];
                        }
                    }
                    array_push ($merged, $row1);
                    array_shift ($old_data);
                    array_shift ($new_data);
                }
            }
        }

        if (!empty ($old_data))
        {
            foreach ($old_data as $row)
            {
                array_push ($merged, $row);
            }
        }
        if (!empty ($new_data))
        {
            foreach ($new_data as $row)
            {
                array_push ($merged, $row);
            }
        }

        return $merged;
    }

    /**
     * Sorts the parsed csv file by the first column.
     *
     * @param is the parsed csv file $data
     * @return the sorted data without headers, because it may conflict with languages
     */
    private function _sort_by_id ($data)
    {
        $actual_data = array_slice ($data, 1);
        usort ($actual_data, array ($this, '_compare'));
        return $actual_data;
    }
    
	/**
     * Creates the validation matrix, of the current database state, for the employees module.
     *
     * @param $mode is the import mode
     * @param $files are the parsed csv files
     * @param $languages is an array of Language model class instances.
     *
     * @return an array of validation matrixes.
     */
    private function _create_employee_validation_data ($mode, $files, $languages)
    {
        if (count ($files) != 1)
        {
            throw new Exception ('Invalid number of files');
        }
        
        //
        // replace all the passwords with empty string
        //
        $file_state = $this->_sort_by_id ($files['file0']);
        for ($i = 0; $i < count ($file_state); $i++)
        {
            if (strlen ($file_state[$i][count ($file_state[$i]) - 1]) > 0)
            {
                $file_state[$i][count ($file_state[$i]) - 1] = '';
            }
        }        
        
        switch ($mode)
        {
            case 1:
                return array ($file_state);
                
            case 2:
            case 3:
                $database_state = $this->_sort_by_id ($this->employee->export (1, $languages, $this->employee->get_all ( )));
                
                return array ($this->_merge ($database_state, $file_state, $mode));
        }
    }
    
    /**
     * Creates the validation matrix, of the current database state, for the customers module.
     *
     * @param $mode is the import mode
     * @param $files are the parsed csv files
     * @param $languages is an array of Language model class instances.
     *
     * @return an array of validation matrixes.
     */
    private function _create_customer_validation_data ($mode, $files, $languages)
    {
        if (count ($files) != 1)
        {
            throw new Exception ('Invalid number of files');
        }
        
        switch ($mode)
        {
            case 1:
                return array ($this->_sort_by_id ($files['file0']));
                
            case 2:
            case 3:
                $database_state = $this->_sort_by_id ($this->customer->export (1, $languages, $this->customer->get_all ( )));
                $file_state = $this->_sort_by_id ($files['file0']);
                
                return array ($this->_merge ($database_state, $file_state, $mode));
        }
    }

    /**
     * Creates the validation matrix, of the current database state, for the items module.
     *
     * @param $mode is the import mode
     * @param $files are the parsed csv files
     * @param $languages is an array of Language model class instances.
     *
     * @return an array of validation matrixes.
     */
    private function _create_item_validation_data ($mode, $files, $languages)
    {
        switch ($mode)
        {
            case 1:
                switch (count ($files))
                {
                    case 1:
                        return array ($this->_sort_by_id ($files['file0']));

                    case 3:
                        $items = $this->_sort_by_id ($files['file0']);
                        $size_groups = $this->_sort_by_id ($files['file1']);
                        $categories = $this->_sort_by_id ($files['file2']);
                        return array ($items, $size_groups, $categories);
                }

            case 2:
                switch (count ($files))
                {
                    case 1:
                        $database_state = $this->_sort_by_id ($this->item->export (1, $languages, $this->item->get_all ( )));
                        $file_state = $this->_sort_by_id ($files['file0']);

                        return array ($this->_merge ($database_state, $file_state, $mode));

                    case 3:
                        $database_state_items = $this->_sort_by_id ($this->item->export (2, $languages, $this->item->get_all ( )));
                        $file_state_items = $this->_sort_by_id ($files['file0']);
                        $megred_items = $this->_merge ($database_state_items, $file_state_items, $mode);

                        $database_state_size_groups = $this->_sort_by_id ($this->size_group->export (1, $languages, $this->size_group->get_all ( )));
                        $file_state_size_groups = $this->_sort_by_id ($files['file1']);
                        $merged_size_groups = $this->_merge ($database_state_size_groups, $file_state_size_groups, $mode);

                        $database_state_categories = $this->_sort_by_id ($this->category->export (1, $languages, $this->category->get_all ( )));
                        $file_state_categories = $this->_sort_by_id ($files['file2']);
                        $merged_categories = $this->_merge ($database_state_categories, $file_state_categories, $mode);

                        return array ($megred_items, $merged_size_groups, $merged_categories);
                }
                break;

            case 3:
                switch (count ($files))
                {
                    case 1:
                        $database_state = $this->_sort_by_id ($this->item->export (1, $languages, $this->item->get_all ( )));
                        $file_state = $this->_sort_by_id ($files['file0']);

                        //
                        // calculate inline field indexes
                        //
                        $inline_indexes = array ( );

                        //
                        // actual sizes
                        //
                        $sizes_index = 6 + 4 * count ($languages);
                        array_push ($inline_indexes, $sizes_index);

                        //
                        // tax data
                        //
                        $tax_start = 9 + 6 * count ($languages);
                        for ($tax_index = $tax_start; $tax_index < count ($file_state[0]); $tax_index++)
                        {
                            array_push ($inline_indexes, $tax_index);
                        }

                        return array ($this->_merge ($database_state, $file_state, $mode, $inline_indexes));

                    case 3:
                        $database_state_items = $this->_sort_by_id ($this->item->export (2, $languages, $this->item->get_all ( )));
                        $file_state_items = $this->_sort_by_id ($files['file0']);

                        //
                        // calculate inlined tax data
                        //
                        $inline_data = array ( );
                        $tax_start = 6 + 4 * count ($languages);
                        for ($tax_index = $tax_start; $tax_index < count ($file_state_items); $tax_index++)
                        {
                            array_push ($inline_data, $tax_index);
                        }

                        $megred_items = $this->_merge ($database_state_items, $file_state_items, $mode, $inline_data);

                        $database_state_size_groups = $this->_sort_by_id ($this->size_group->export (1, $languages, $this->size_group->get_all ( )));
                        $file_state_size_groups = $this->_sort_by_id ($files['file1']);
                        $merged_size_groups = $this->_merge ($database_state_size_groups, $file_state_size_groups, $mode, array (1));

                        $database_state_categories = $this->_sort_by_id ($this->category->export (1, $languages, $this->category->get_all ( )));
                        $file_state_categories = $this->_sort_by_id ($files['file2']);
                        $merged_categories = $this->_merge ($database_state_categories, $file_state_categories, $mode);

                        return array ($megred_items, $merged_size_groups, $merged_categories);
                }
                break;
        }
    }
    
	/**
     * Imports the employee data into the database
     *
     * @param $mode is the importing mode
     * @param $files are the parsed csv files
     */
    private function _import_employees ($mode, $files)
    {   
        if (count ($files) != 1)
        {
            $this->error = $this->lang->line ('import_error_number_files');
            return;
        }
        
        $validation_data = $this->_create_employee_validation_data ($mode, $files, array ( ));
        $validation_file = $validation_data[0];
        
        $this->db->trans_start ( );
        $this->employee->import_flat ($mode, array_slice($files['file0'], 1), array ( ));
        
        $current_state_file = $this->_sort_by_id ($this->employee->export (1, array ( ), $this->employee->get_all ( )));

        $diff_errors = $this->csv->diff ($validation_file, $current_state_file);
        if ($diff_errors != NULL)
        {
            $this->error = $diff_errors;
        }
        else
        {
            $this->db->trans_complete ( );
        }
    }
    
    /**
     * Imports the customer data into the database
     *
     * @param $mode is the importing mode
     * @param $files are the parsed csv files
     */
    private function _import_customers ($mode, $files)
    {
        $this->load->model ('persons/customer');
        
        if (count ($files) != 1)
        {
            $this->error = $this->lang->line ('import_error_number_files');
            return;
        }
        
        $validation_data = $this->_create_customer_validation_data ($mode, $files, array ( ));
        $validation_file = $validation_data[0];
        
        $this->db->trans_start ( );
        $this->customer->import_flat ($mode, array_slice($files['file0'], 1), array ( ));
        
        $current_state_file = $this->_sort_by_id ($this->customer->export (1, array ( ), $this->customer->get_all ( )));

        $diff_errors = $this->csv->diff ($validation_file, $current_state_file);
        if ($diff_errors != NULL)
        {
            $this->error = $diff_errors;
        }
        else
        {
            $this->db->trans_complete ( );
        }
    }

    /**
     * Imports the item data into the database
     *
     * @param $mode is the importing mode
     * @param $files are the parsed csv files
     */
    private function _import_items ($mode, $files)
    {
        $this->load->model ('items/item');
        $this->load->model ('items/size_group');
        $this->load->model ('items/category');

        switch (count ($files))
        {
            case 1:
                $languages = $this->_extract_languages ($files['file0'][0]);

                $validation_data = $this->_create_item_validation_data ($mode, $files, $languages);
                $validation_file = $validation_data[0];

                $this->db->trans_start ( );
                $this->item->import_flat ($mode, array_slice($files['file0'], 1), $languages);


                $current_state_file = $this->_sort_by_id ($this->item->export (1, $languages, $this->item->get_all ( )));

                $diff_errors = $this->csv->diff ($validation_file, $current_state_file);
                if ($diff_errors != NULL)
                {
                    $this->error = $diff_errors;
                }
                else
                {
                    $this->db->trans_complete ( );
                }
                break;

            case 3:
                $languages = $this->_extract_languages ($files['file0'][0]);

                $validation_data = $this->_create_item_validation_data ($mode, $files, $languages);
                $items_validation = $validation_data[0];
                $size_groups_validation = $validation_data[1];
                $categories_validation = $validation_data[2];

                $this->db->trans_start ( );

                //
                // if mode is 1, delete top down
                //
                if ($mode == 1)
                {
                    $this->item->purge ( );
                    $this->size_group->purge ( );
                    $this->category->purge ( );
                }

                $this->size_group->import_simple ($mode, array_slice($files['file1'], 1), $languages);
                $this->category->import_simple ($mode, array_slice($files['file2'], 1), $languages);
                $this->item->import_simple ($mode, array_slice($files['file0'], 1), $languages);

                $current_state_items_file = $this->_sort_by_id ($this->item->export (2, $languages, $this->item->get_all ( )));
                $current_state_size_groups_file = $this->_sort_by_id ($this->size_group->export (1, $languages, $this->size_group->get_all ( )));
                $current_state_categories_file = $this->_sort_by_id ($this->category->export (1, $languages, $this->category->get_all ( )));

                $items_diff = $this->csv->diff ($items_validation, $current_state_items_file);
                $size_groups_diff = $this->csv->diff ($size_groups_validation, $current_state_size_groups_file);
                $categories_diff = $this->csv->diff ($categories_validation, $current_state_categories_file);


                if ($items_diff == '' && $size_groups_diff == '' && $categories_diff == '')
                {
                    $this->db->trans_complete ( );
                }
                else
                {
                    if ($items_diff != '')
                    {
                        $this->error = $items_diff;
                    }
                    if ($size_groups_diff != '')
                    {
                        $this->error = $size_groups_diff;
                    }
                    if ($categories_diff != '')
                    {
                        $this->error = $categories_diff;
                    }
                }
                break;

            default:
                $this->error = $this->lang->line ('import_error_number_files');
        }
    }


    /**
     * Constructor
     */
    function __construct ( )
    {
        parent::__construct  ('config');

        $this->load->model ('export-import/language');
        $this->load->model ('persons/employee');
        
        $this->load->library ('csv');
        $this->load->library ('zip');
        $this->load->library ('parser');
        $this->load->library ('form_validation');
    }

    
    
    function index ( )
    {
        //
    	// Remember this address as a navigation node to come back later
    	//
    	$this->navigation_stack->push ( );
    	
    	//
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['active_terminal']     = $this->active_terminal;
        $data['module_name']         = $this->lang->line ('module_config');
        
        //
        // Fill the page templates wih data
        //
        $page_content 	 = $this->_build_content_template ( );
        $page_buttons	 = $this->_build_buttons_template ( );
        
        $data['content'] = $this->parser->parse ('export-import/import', 
        										 $page_content, 
        										 true);
        $data['buttons'] = $this->parser->parse ('edit_common_buttons',
        										 $page_buttons,
        										 true);
    	//
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
    }

    function import ( )
    {
        // Form validation
        $errors = $this->_validate_import ( );
        if ($errors != '')
        {
            echo json_encode (array ('success'=>false, 
            						 'message'=>$errors));
            return;
        }

        $object = $this->input->post ('import');
        $mode = $this->input->post ('mode');
        $files = $this->_get_csv_files ( );

        if (count($files) == 0)
        {
            echo json_encode (array ('success'=>false, 
            						 'message'=>$this->lang->line ('import_error_no_files')));
            return;
        }

        switch ($object)
        {
            case 1:
                $this->_import_items ($mode, $files);
                break;
                
            case 2:
                $this->_import_customers ($mode, $files);
                break;
                
            case 3:
                $this->_import_employees ($mode, $files);
                break;

            default:
                echo json_encode (array ('success'=>false, 
            						     'message'=>$this->lang->line ('common_change_unsuccessful')));
                return;
        }
        
        if ($this->error != NULL)
        {
            echo json_encode (array ('success'=>false, 
            					     'message'=>$this->error));
        }
        else
        {
            echo json_encode (array ('success'=>true, 
            					     'message'=>$this->lang->line ('common_change_successful')));
        }
    }
}
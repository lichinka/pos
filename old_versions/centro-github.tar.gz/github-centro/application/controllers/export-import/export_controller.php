<?php
require_once (APPPATH . "/controllers/secure_area.php");

class Export_controller extends Secure_area
{
    private $exportables = array (
    1=>'items_item',
    2=>'customers_plural',
    3=>'employees_plural'
    );

    private $modes       = array (
    1=>'export_mode_flat',
    2=>'export_mode_files'
    );
    
    private $error;
    private $file;
    
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_content_template ( )
    {
        $ret_value = array ( );

        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
        
        //
        // General page data
        //
        $ret_value['page_title'] 	   = $this->lang->line ('export');
        $ret_value['export_object']    = $this->lang->line ('export_relation');
        $ret_value['export_type']      = $this->lang->line ('export_mode');
        $ret_value['export_languages'] = $this->lang->line ('export_languages');
        $ret_value['export_notes']     = $this->lang->line ('export_notes');

        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/validate/', 
        								   	   array ('id' => 'export_form'));
        $ret_value['form_close'] = form_close ( );
        
        //
        // Data about the export parameters
        //
        
        //
        // Notes
        //
        $ret_value['notes'] = array ( );
        
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('export_flat_reference_warning')));
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('export_fields_warning')));
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('export_multiple_warning')));
        array_push ($ret_value['notes'], array ('note' => $this->lang->line ('export_employees_warning')));
        
        
        $ret_value['objects'] = array ( );
        //
        // Field "Select object"
        //
        
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('export_select'), 
        							  'export', 
        							  array ('class'=>'wide'));
        							  
        //
        // select what to export dropdown
        //
        $dropdown_items = array ( );
        foreach ($this->exportables as $key => $value)
        {
            $dropdown_items[$key] = $this->lang->line ($value);
        }

        $field['input'] = form_dropdown ('export', 
                                         $dropdown_items, 
                                         '' ,
                                         'id = export');
        							  
        
        array_push ($ret_value['objects'], $field);

        //
        // Field "Export mode"
        //
        $ret_value['modes'] = array ( );
        foreach ($this->modes as $key => $value)
        {
            $field = array ( );
            
            $field['input'] = form_radio ('mode', 
                                          $key, 
                                          false, 
                                          'id = mode' . $key);


            $field['label'] = form_label ($this->lang->line ($value), 
            							  'mode' . $key,
                                          array ('class'=>'wide'));


            array_push ($ret_value['modes'], $field);
        }
        
        //
        // Field "languages"
        //
        $ret_value['languages'] = array ( );
        $languages = $this->language->get_all ( );
        foreach ($languages as $language)
        {
            $field = array ( );
            $field['input'] = form_checkbox ('languages[]', 
                                             $language->id, 
                                             false, 
                                             'id = "language' . $language->id . '"');
                                             
            $field['label'] = form_label ($this->lang->line ('export_' . $language->name), 
            							  'language' . $language->id,
                                          array ('class'=>'wide'));
            
            array_push ($ret_value['languages'], $field);
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }

    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_buttons_template ( )
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
        							   		array ('title' => $this->lang->line ('common_back')));
        
    	//
    	// The SAVE (or Submit) button
    	//
    	$ret_value['submit_button'] = anchor ('#', ' ',
        							   	 	  array ('title'   => $this->lang->line ('common_submit'),
        							   	 	  //
        							   	 	  // This code connects this anchor with the Submit functionality
        							   	 	  //
        							   	 	  'onClick' => "return validate_form_data (event, document.forms[0]);"));
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }    


    /**
     * Validates the data retrieved from the input.
     *
     * @return a string of errors, if it is an empty string, there were no validation errors
     */
    private function _validate_export ( )
    {
        $this->form_validation->set_rules ('export', $this->lang->line ('export_relation'), 'trim|required');
        $this->form_validation->set_rules ('mode', $this->lang->line ('export_mode'), 'trim|required');
        $this->form_validation->set_rules ('languages[]', $this->lang->line ('export_languages'), 'trim|required');

        if ($this->form_validation->run ( ) == false)
        {
            return validation_errors (' ',' ');
        }
        else
        {
            return '';
        }
    }

    /**
     * This function is responsible for exporting the items relation.
     *
     * @param $mode, specifices the way in which the data will be exported (flat, multi-file)
     * @param $languages is an array of instances of the Language class. The data will be
     * 					 for each language in this array.
     *
     * @return this function forces a download of the generated files
     */
    private function _export_items ($mode, $languages)
    {
        $this->load->model ('items/item');
        $this->load->model ('items/category');
        $this->load->model ('items/size_group');

        switch ($mode)
        {
            case 1:
                $data = $this->item->export ($mode, $languages, $this->item->get_all ( ));
                $this->ci_zip->add_data ('items.csv', $this->csv->write_to_file ($data));

                $this->file = $this->ci_zip->get_zip ( );
                break;

            case 2:
                $data = $this->item->export ($mode, $languages, $this->item->get_all ( ));
                $this->ci_zip->add_data ('items.csv', $this->csv->write_to_file ($data));

                $data = $this->category->export (1, $languages, $this->category->get_all ( ));
                $this->ci_zip->add_data ('categories.csv', $this->csv->write_to_file ($data));

                $data = $this->size_group->export (1, $languages, $this->size_group->get_all ( ));
                $this->ci_zip->add_data ('sizes.csv', $this->csv->write_to_file ($data));

                $this->file = $this->ci_zip->get_zip ( );
                break;

            default:
                $this->error = True;
                break;
        }
    }
    
    /**
     * This function is responsible for exporting the customers relation.
     *
     * @param $mode, specifices the way in which the data will be exported (flat, multi-file)
     * @param $languages is an array of instances of the Language class. The data will be
     * 					 for each language in this array.
     *
     * @return this function forces a download of the generated files
     */
    private function _export_customers ($mode, $languages)
    {
        $this->load->model ('persons/customer');
        
        switch ($mode)
        {
            case 1:
                $data = $this->customer->export ($mode, $languages, $this->customer->get_all ( ));
                $file_data = $this->csv->write_to_file ($data);
                $this->ci_zip->add_data ('customers.csv', $file_data);
                
                $this->file = $this->ci_zip->get_zip ( );
                break;
            
            
            default:
                $this->error = True;
                break;
        }
    }
    
    /**
     * This function is responsible for exporting the employees relation.
     *
     * @param $mode, specifices the way in which the data will be exported (flat, multi-file)
     * @param $languages is an array of instances of the Language class. The data will be
     * 					 for each language in this array.
     *
     * @return this function forces a download of the generated files
     */
    private function _export_employees ($mode, $languages)
    {
        $this->load->model ('persons/employee');
        
        switch ($mode)
        {
            case 1:
                $data = $this->employee->export ($mode, $languages, $this->employee->get_all ( ));
                $file_data = $this->csv->write_to_file ($data);
                $this->ci_zip->add_data ('employees.csv', $file_data);
                
                $this->file = $this->ci_zip->get_zip ( );
                break;
            
            
            default:
                $this->error = True;
                break;
        }
    }
    
    /**
     * This function is responsible for exporting the correct object, mode and 
     * languages.
     * 
     * @param $object:       is the index of the object that will be exported (see the 
     * 				         private attribute $exportables)
     * @param $mode:         is the index of the exporting mode (see the private 
     * 						 attribute $modes)
     * @param $language_ids: is an array, that contains the database id's of the 
     * 						 languages, that will be exported
     */
    private function _export ($object, $mode, $language_ids)
    {
        $languages = array ( );
        foreach ($language_ids as $id)
        {
            array_push ($languages, new Language ($id));
        }

        $this->error = False;
        switch ($object)
        {
            case 1:
                $this->_export_items ($mode, $languages);
                break;
                
            case 2:
                $this->_export_customers ($mode, $languages);
                break;
                
            case 3:
                $this->_export_employees ($mode, $languages);
                break;

            default:
                $this->error = true;
        }
    }
    

    /**
     * Constructor
     */
    function __construct ( )
    {
        parent::__construct  ('config');
        
        $this->load->library ('csv');
        $this->load->library ('zip', '', 'ci_zip');
        $this->load->library ('parser');
        $this->load->library ('form_validation');
        $this->load->model   ('export-import/language');
    }

    function index ( )
    {
        //
    	// Remember this address as a navigation node to come back later
    	//
    	$this->navigation_stack->push ( );
    	
    	//
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['active_terminal']     = $this->active_terminal;
        $data['module_name']         = $this->lang->line ('module_config');
        
        //
        // Fill the page templates wih data
        //
        $page_content 	 = $this->_build_content_template ( );
        $page_buttons	 = $this->_build_buttons_template ( );
        
        $data['content'] = $this->parser->parse ('export-import/export', 
        										 $page_content, 
        										 true);
        $data['buttons'] = $this->parser->parse ('edit_common_buttons',
        										 $page_buttons,
        										 true);
    	//
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
    }

    /**
     * This function tries to generate the file and returns the appropriate message. 
     * The response also returns the URL for accessing the file.
     */
    function validate ( )
    {
        // Form validation
        $errors = $this->_validate_export ( );
        if ($errors != '')
        {
            echo json_encode (array ('success'=>false, 
            						 'message'=>$errors));
            return;
        }

        $object       = $this->input->post ('export');
        $mode         = $this->input->post ('mode');
        $language_ids = $this->input->post ('languages');
        if (!sort ($language_ids, SORT_NUMERIC))
        {
            echo json_encode (array ('success'=>false, 
            						 'message'=>$this->lang->line ('common_change_unsuccessful')));
            return;
        }
        
        $this->_export ($object, $mode, $language_ids);
        
        if ($this->error)
        {
            echo json_encode( array ('success' => false,
        						 	 'message' => $this->lang->line ('common_change_unsuccessful')));
        }
        else
        {

            //
            // The URI of this controller
            //
            $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
            
            //
            // Generate the URL of the file
            //
            $file_uri  = $controller_uri . '/download/';
            $file_uri .= $object . '/';
            $file_uri .= $mode . '/';
            foreach ($language_ids as $language_id)
            {
                $file_uri .= $language_id . '/';
            }
            
            echo json_encode( array ('success' => true,
        						 	 'message' => $this->lang->line ('export_successfull'),
                                     'follow_address' => site_url ($file_uri)));
       
        }
    }
    
    /**
     * This function generates and downloads the file. It requires at least 
     * three parameters.
     * 
     * @param $object:      is the index of the object that will be exported (see the 
     * 				        private attribute $exportables)
     * @param $mode:        is the index of the exporting mode (see the private 
     * 						attribute $modes)
     * @param $language_id: every attribute with index 2 or more is considered to be
     * 						a database language id, of a language that will be exported
     */
    function download ( )
    {
        if (func_num_args ( ) < 3)
        {
            echo json_encode( array ('success' => false,
        						 	 'message' => $this->lang->line ('common_change_unsuccessful')));
            return;
        }
        
        $object       = func_get_arg(0);
        $mode         = func_get_arg(1);
        $language_ids = array ( );
        
        for ($i = 2; $i < func_num_args ( ); $i++)
        {
            array_push ($language_ids, func_get_arg($i));
        }
        if (!sort ($language_ids, SORT_NUMERIC))
        {
            echo json_encode (array ('success'=>false, 
            						 'message'=>$this->lang->line ('common_change_unsuccessful')));
            return;
        }
        
        $this->_export ($object, $mode, $language_ids);
        
        if ($this->error)
        {
            echo json_encode( array ('success' => false,
        						 	 'message' => $this->lang->line ('common_change_unsuccessful')));
            return;
        }
        else
        {
            $this->ci_zip->download ('data.zip');
        }
    }
}
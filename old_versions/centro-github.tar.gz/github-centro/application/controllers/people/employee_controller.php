<?php
require_once (APPPATH . '/controllers/secure_area.php');;


class Employee_controller extends Secure_area
{
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $employees  An array containing all employees.
     * 
     * @return An array ready to be applied over the template page.-
     */
   	private function _build_table_content_template ($employees)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // The title is employees
        //
        $ret_value['page_title']    = $this->lang->line ('employees_plural'); 
        //
        // The list column titles
        //
        $ret_value['column_titles'] = array (array ('title' => $this->lang->line ('common_last_name')),
        									 array ('title' => $this->lang->line ('common_first_name')),
        									 array ('title' => $this->lang->line ('common_email')),
        									 array ('title' => $this->lang->line ('common_phone_number')),
        									 //
        									 // Column for the EDIT button
        									 //
        									 array ('title'=>'&nbsp'),
        									 //
        									 // Column for the DELETE button
        									 //
        									 array ('title'=>'&nbsp'));
        //
        // Display or hide the 'No elements' message?
        //
        if (count ($employees) == 0)
        {
            $ret_value['display_status'] = 'display: inline;';
            $ret_value['empty_table']    = $this->lang->line ('common_nothing_to_display');
        }
        else
        {
            $ret_value['display_status'] = 'display: none;';
            $ret_value['empty_table']    = '';
        }

        //
        // Set the actual employee data for the whole table of records
        //
        $ret_value['table_data'] = array ( );
        
        foreach ($employees as $employee)
        {
            $employee_data = array ('last_name'    => $employee->last_name,
                             	    'first_name'   => $employee->first_name,
                             	    'email'        => $employee->email,
                                    'phone_number' => $employee->phone_number,
            
                                    'edit_link'    => anchor ($controller_uri . '/edit/' . $employee->id, 
            										          '...',
            										          array ('title' => $this->lang->line ('common_edit'))),
            										      
                    			    'delete_link'  => anchor ($controller_uri . '/delete/' . $employee->id . '/',
            										          'x', 
            					                              array ('id'    => 'delete',
            					                          	 	     'title' => $this->lang->line ('common_delete'),
					        							   	  	     //
					        							   	  	     // This code connects this anchor with the Delete functionality
					        							   	 	     //
					        							   	 	     'onClick' => "return delete_table_row (event);")));
        	//
        	// Save the data of the current employee
        	//
            array_push ($ret_value['table_data'], $employee_data);
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }


    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
	 *  
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_buttons_template ( )
    {
    	$ret_value = array ( );
    	
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
    	
        //
        // Don't display the BACK button
        //
        $ret_value['back_button'] = NULL;
        
		//
		// The NEW (or Add) EMPLOYEE button
		//
        $ret_value['new_button'] = anchor ($controller_uri . '/edit/', ' ',
                                           array ('title' => $this->lang->line('employees_add')));
                                          
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }
    
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $employee	The employee being edited.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_content_template ($employee)
    {
        $ret_value = array ( );
        
    	//
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // General page data
        //
        $ret_value['page_title'] 			  = $this->lang->line ('common_edit');
        $ret_value['fields_required_message'] = $this->lang->line ('common_fields_required_message');
        $ret_value['page_info'] 	 		  = $this->lang->line ('employees_basic_information');
        $ret_value['login_information']       = $this->lang->line ("employees_login_info");
        $ret_value['permission_info']         = $this->lang->line ("employees_permission_info");
        $ret_value['permission_description']  = $this->lang->line ("employees_permission_desc");
        $ret_value['terminal_description']    = $this->lang->line ('employees_login_terminal_desc');
        
        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/save/' . $employee->id, 
        								   	   array ('id' => 'employee_form'));
        $ret_value['form_close'] = form_close ( );
        
        //
        // Basic data about the employee parameter
        //
        $ret_value['data'] = array ( );
        
        //
        // Field "Employee first_name"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('common_first_name'), 
        							  'first_name', 
        							  array ('class'=>'wide required'));
        							  
        $field['input'] = form_input (array ('name' => 'first_name', 
        							  		 'id'   => 'first_name', 
        							  		 'value' => $employee->first_name));
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Employee last name"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('common_last_name'),
        							  'last_name', 
        							  array ('class' => 'wide required'));
        							  
        $field['input'] = form_input (array ('name' => 'last_name', 
        							  		 'id'   => 'last_name', 
        							  		 'value' => $employee->last_name));
        
        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Email"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('common_email'),
        							  'email', 
        							  array ('class' => 'wide'));
        							  
        $field ['input'] = form_input (array ('name' => 'email',
        									  'id'   => 'email',
        									  'value'=> $employee->email));

        array_push ($ret_value['data'], $field);

        //
        // Field "Employee telephone"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_phone_number'), 
        							   'phone_number', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'phone_number',
        									  'id'   => 'phone_number',
        									  'value'=> $employee->phone_number));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Employee address"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_address'), 
        							   'address', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'address',
        									  'id'   => 'address',
        									  'value'=> $employee->address));

        array_push ($ret_value['data'], $field);
        
        
		//
        // Field "Employee city"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_city'), 
        							   'city', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'city',
        									  'id'   => 'city',
        									  'value'=> $employee->city));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Employee state"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_state'), 
        							   'state', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'state',
        									  'id'   => 'state',
        									  'value'=> $employee->state));

        array_push ($ret_value['data'], $field);
        
        //
        // Field "Employee zip_code"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_zip'), 
        							   'zip_code', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'zip_code',
        									  'id'   => 'zip_code',
        									  'value'=> $employee->zip_code));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Employee country"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_country'), 
        							   'country', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'country',
        									  'id'   => 'country',
        									  'value'=> $employee->country));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Field "Employee country"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('common_comments'), 
        							   'comments', 
        							   array ('class'=>'wide'));
        							   
        $field ['input'] = form_input (array ('name' => 'comments',
        									  'id'   => 'comments',
        									  'value'=> $employee->comments));

        array_push ($ret_value['data'], $field);
        
        
        //
        // Data about the login parameters (uername & password)
        //
        $ret_value['login_data'] = array ( );
        
        
        //
        // Field "Employee username"
        //
        $field['label'] = form_label ($this->lang->line ('employees_username'), 
        		  					  'username',
                                      array('class'=>'wide required'));
                                      
        $field['input'] = form_input (array ('name'=>'username',
        									 'id'=>'username', 
        									 'value'=>$employee->username));
        
        array_push ($ret_value['login_data'], $field);
        

        //
        // Field "Employe password"
        //
        if ($employee->id == "")
        {
            $password_label_attributes = array ('class'=>'wide required');
        }
        else
        {
            $password_label_attributes = array ('class'=>'wide');
        }
        
        $field['label'] = form_label ($this->lang->line ('employees_password'),
        		  				      'password',
                                      $password_label_attributes);
                                               
        $field['input'] = form_password (array ('name'=>'password',
        										'id'=>'password'));
        
        array_push ($ret_value['login_data'], $field);
        
        //
        // Field "Employee repeat password
        //
        $field['label'] = form_label ($this->lang->line ('employees_repeat_password'),
        							  'repeat_password',
                                      $password_label_attributes);
        
        $field['input'] = form_password (array ('name'=>'repeat_password',
        										'id'=>'repeat_password'));
        
        array_push ($ret_value['login_data'], $field);

       
        
        //
        // Data about allowed modules
        //
        $ret_value['module_data'] = array ( );
        
        foreach ($this->Module->get_active ( ) as $module)
        {
            $checkbox = array ( );
            
            $checkbox['thick'] = form_checkbox ("permissions[]",
                                                $module->name, 
                                                $employee->has_permission ($module->name));
            
            $checkbox['module_name'] = $this->lang->line ($module->name_lang_key);
            $checkbox['module_description'] = $this->lang->line ($module->desc_lang_key);
            
            array_push ($ret_value['module_data'], $checkbox);
        }
        
        
        //
        // Data about allowed terminals
        //
        $ret_value['terminal_data'] = array ( );
        $stores = $this->store->get_all ( );
        $terminals = $this->terminal->get_all ( );

        //
        // First loop adds already active terminals
        //
        $active_terminals = $employee->get_terminals ( );
        for ($i = 0; $i < count ($active_terminals); $i++)
        {
            $data_array = array ( );
            $dropdown_items = array (-1=>'---' . $this->lang->line ('common_without') . '---');
            $invalid = -2;
            foreach ($stores as $store)
            {
                $dropdown_items[$invalid] = $store->name;
                foreach ($terminals as $terminal)
                {
                    if ($terminal->get_parent_store ( )->id == $store->id)
                    {
                        $dropdown_items[$terminal->id] = '=> ' . $terminal->name;
                    }
                }
            }

            $data_array['label'] = form_label ($this->lang->line ('config_terminal_page_title'), 
            								   'terminal' . $i);
            
            $data_array['input'] = form_dropdown ('terminal' . $i, 
                                   $dropdown_items, array ($active_terminals[$i]->id), 
                                   'id="terminal' . $i . '"');
            array_push ($ret_value['terminal_data'], $data_array);
        }

        //
        // Seconf loop adds two empty terminal slots
        //
        for ($i = count ($active_terminals); $i < count ($active_terminals) + 2; $i++)
        {
            $data_array = array ( );
            $dropdown_items = array (-1=>'---' . $this->lang->line ('common_without') . '---');
            $invalid = -2;
            foreach ($stores as $store)
            {
                $dropdown_items[$invalid] = $store->name;
                foreach ($terminals as $terminal)
                {
                    if ($terminal->get_parent_store ( )->id == $store->id)
                    {
                        $dropdown_items[$terminal->id] = '=> ' . $terminal->name;
                    }
                }
            }

            $data_array['label'] = form_label ($this->lang->line ('config_terminal_page_title'), 
            								   'terminal' . $i);
            
            $data_array['input'] = form_dropdown ('terminal' . $i, 
                                                  $dropdown_items, '' ,
                                                  'id="terminal' . $i . '"');
                                                  
            array_push ($ret_value['terminal_data'], $data_array);
        }
        
        
        //
        // Return the dynamic template built
        //
        return $ret_value;
    }

    
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_buttons_template ( )
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
        							   		array ('title' => $this->lang->line ('common_back')));

        //
    	// The SAVE (or Submit) button
    	//
    	$ret_value['submit_button'] = anchor ('#', ' ',
        							   	 	  array ('title'   => $this->lang->line ('common_submit'),
        							   	 	  //
        							   	 	  // This code connects this anchor with the Submit functionality
        							   	 	  //
        							   	 	  'onClick' => "return validate_form_data (event, document.forms[0]);"));
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }

    /**
     * Validates the data retrieved from the input.
     *
     * @param $validate_password, true if the password needs to be validated,
     * 		  false otherwise
     * @return a string of errors, if it is an empty string, there were no validation errors
     */
    private function validate_save ($validate_password)
    {
        $this->form_validation->set_rules ('first_name', $this->lang->line ('common_first_name'), 'trim|required');
        $this->form_validation->set_rules ('last_name', $this->lang->line ('common_last_name'), 'trim|required');
        $this->form_validation->set_rules ('username', $this->lang->line ('employees_username'), 'trim|required');
        $this->form_validation->set_rules ('email', $this->lang->line ('common_email'), 'trim|valid_email');

        if ($validate_password)
        {
            $this->form_validation->set_rules ('password', $this->lang->line ('employees_password'), 'required|md5');
            $this->form_validation->set_rules ('repeat_password', $this->lang->line ('employees_repeat_password'), 'required|matches[password]|md5');
        }

        if ($this->form_validation->run ( ) == false)
        {
            return validation_errors (' ',' ');
        }
        else
        {
            return '';
        }
    }


    /**
     * Constructor
     */
    function __construct ( )
    {
        parent::__construct ('employee');
        $this->load->model ('persons/employee');
        $this->load->model ('company/store');
        $this->load->model ('company/terminal');
        $this->load->model ('persons/module', 'Module', TRUE);
        $this->load->library ('parser');
        $this->load->library ('form_validation');
    }


    /**
     * The entry point of this controller.-
     */
    function index ( )
    {
        //
        // Prepare the navigation stack to work inside this module
        //
        $this->navigation_stack->clear_stack ( );
        $this->navigation_stack->push ( );
    	
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['active_terminal']     = $this->active_terminal;
        $data['module_name']         = $this->lang->line ('module_employee');
        
        //
        // Fetch the employees
        //
        $employees = $this->employee->get_all ( );
        
        //
        // Fill the page templates with data
        //
        $page_content = $this->_build_table_content_template ($employees);
        $page_buttons = $this->_build_table_buttons_template ( );
        
        $data['content'] = $this->parser->parse ('people/table_people', 
        										 $page_content,
        										 true);
        $data['buttons'] = $this->parser->parse ('table_buttons', 
        										 $page_buttons,
        										 true);
        //
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
    }

    
    /**
     * Loads the employee edit form.-
     */
    function edit ($employee_id = NULL)
    {
        //
	    // Remember this address as a navigation node to come back later
	    //
	    $this->navigation_stack->push ( );
	    
	    //
	    // The data about the registered employee is held in the parent class
	    //
	    $data['registered_employee'] = $this->registered_employee;
	    $data['active_terminal']     = $this->active_terminal;
	    $data['module_name']         = $this->lang->line ('module_employee');
	
	    //
	    // Fetch the employee being edited
	    //
	    $employee = new Employee ($employee_id);
	
	    //
	    // Fill the page templates wih data
	    //
	    $page_content = $this->_build_edit_content_template ($employee);
	    $page_buttons = $this->_build_edit_buttons_template ( );
	       
	    $data['content'] = $this->parser->parse ('people/edit_employee', 
	      										 $page_content, 
	       										 true);
	        										 
	    $data['buttons'] = $this->parser->parse ('edit_common_buttons', 
	       										 $page_buttons,
	       										 true);
	    //
	    // Load and display the edit form
	    //
	    $this->load->view ('skeleton', $data);
    }

    /**
     * Inserts/updates an employee
     */
    function save($employee_id = NULL)
    {
        // Form validation
        // Password has been changed OR first time password set
        $errors = $this->validate_save ($employee_id == NULL || strlen($this->input->post ('password')) > 0);
        if ($errors != '')
        {
            echo json_encode (array ('success'=>false, 'message'=>$errors));
            return;
        }


        $employee               = new Employee ($employee_id);
        $employee->first_name   = $this->input->post('first_name');
        $employee->last_name    = $this->input->post('last_name');
        $employee->email        = $this->input->post('email');
        $employee->phone_number = $this->input->post('phone_number');
        $employee->address      = $this->input->post('address');
        $employee->city         = $this->input->post('city');
        $employee->state        = $this->input->post('state');
        $employee->zip_code     = $this->input->post('zip_code');
        $employee->country      = $this->input->post('country');
        $employee->comments     = $this->input->post('comments');
        $employee->username     = $this->input->post('username');
        $employee->module_ids   = array ( );
        $employee->terminal_ids = array ( );

        //Password has been changed OR first time password set
        if($employee_id == NULL || strlen($this->input->post ('password')) > 0)
        {
            $employee->password = $this->input->post('password');
        }

        // get all possible permissions
        $modules = array ( );
        $selected_module_names = $this->input->post("permissions");

        if ($selected_module_names != false)
        {
            foreach ($this->Module->get_all ( ) as $module)
            {
                if (in_array ($module->name, $selected_module_names))
                {
                    array_push ($modules, $module);
                }
            }
        }


        // get all allowed terminals
        $terminals = array ( );
        $terminal_ids = array ( );
        $i = 0;
        while ($i < 1000)
        {
            $raw_id =  $this->input->post("terminal" . $i);
            if ($raw_id == false)
            {
                break;
            }

            if ($raw_id > 0 && !in_array($raw_id, $terminal_ids))
            {
                array_push ($terminal_ids, $raw_id);
            }
            else if ($raw_id < -1)
            {
                echo json_encode(array('success'=>false,'message'=>$this->lang->line ('employees_login_terminal_store_selected')));
                return;
            }
            $i++;
        }

        foreach ($terminal_ids as $terminal_id)
        {
            array_push ($terminals, new Terminal ($terminal_id));
        }

        //
        // finally add all the modules and terminals to the employee
        //
        foreach ($modules as $module)
        {
            array_push ($employee->module_ids, $module->id);
        }
        foreach ($terminals as $terminal)
        {
            array_push ($employee->terminal_ids, $terminal->id);
        }

        $employee->update ( );


         
        echo json_encode (array ('success'=>true,
                                 'message'=>$this->lang->line ('common_change_successful')));         
    }

    /**
     * Deletes a employee from the database.
     *
     * @param $id The emploeyee ID being deleted.-
     */
    function delete ($id = NULL)
    {
        //TODO: Using a deprecated method
        
        if ($id != NULL)
        {
            if($this->employee->delete_all (array ($id)))
            {
                echo json_encode (array ('success'=>true, 
                					     'message'=>$this->lang->line ('common_change_successful')));
            }
            else
            {
                echo json_encode (array ('success'=>false,
                						 'message'=>$this->lang->line ('common_change_unsuccessful')));
            }
        }
    }
    
	/**
     * FIXME: Implement ...
     */
    function search ( )
    {
        // FIXME: implement
        echo 'Implement';
    }


    /**
     * FIXME: Implement ...
     */
    function suggest ( )
    {
        // FIXME: implement
        echo 'Implement';
    }
}
?>
<?php
require_once (APPPATH . '/controllers/secure_area.php');


/**
 * Controller for displaying and editing the stores 
 * (or bussiness units) of a specific company.-
 *
 * @author luka
 *
 */
class Store_controller extends Secure_area
{
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $stores  An array containing all stores of a company.
     * @param $company The company object that is parent of the $stores.-
     * 
     * @return An array ready to be applied over the template page.-
     */
   	private function _build_table_content_template ($stores, $company)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // The title is the name of the company + the page title
        //
        $ret_value['page_title']    = $company->name . ' - ' . 
        						 	  $this->lang->line ('config_store_page_title'); 
        //
        // The list column titles
        //
        $ret_value['column_titles'] = array (array ('title' => $this->lang->line ('config_store_name')),
        									 array ('title' => $this->lang->line ('config_store_address')),
        									 array ('title' => $this->lang->line ('config_store_telephone')),
        									 //
        									 // Column for the EDIT button
        									 //
        									 array ('title'=>'&nbsp'),
        									 //
        									 // Column for the DELETE button
        									 //
        									 array ('title'=>'&nbsp'));
        //
        // Display or hide the 'No elements' message?
        //
        if (count ($stores) == 0)
        {
            $ret_value['display_status'] = 'display: inline;';
            $ret_value['empty_table']    = $this->lang->line ('common_nothing_to_display');
        }
        else
        {
            $ret_value['display_status'] = 'display:none;';
            $ret_value['empty_table']    = '';
        }

        //
        // Set the actual store data for the whole table of records
        //
        $ret_value['table_data'] = array ( );
        
        foreach ($stores as $store)
        {
            $store_data = array ('name'        => $store->name,
                             	 'address'     => $store->address,
                             	 'telephone'   => $store->telephone,
            
                                 'edit_link'   => anchor ($controller_uri . '/edit/' . $company->id . '/' . $store->id . '/', 
            										      '...',
            										      array ('title' => $this->lang->line ('common_edit'))),
            										      
                    			 'delete_link' => anchor ($controller_uri . '/delete/' . $store->id . '/',
            										      'x', 
            					                          array ('id'    => 'delete',
            					                          		 'title' => $this->lang->line ('common_delete'),
					        							   	 	  //
					        							   	 	  // This code connects this anchor with the Delete functionality
					        							   	 	  //
					        							   	 	  'onClick' => "return delete_table_row (event);")));
        	//
        	// Save the data of the current store
        	//
            array_push ($ret_value['table_data'], $store_data);
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }


    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
	 * @param $company The company object that is parent of this store.-
	 *  
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_buttons_template ($company)
    {
    	$ret_value = array ( );
    	
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
    	
        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
	                                        array ('title' => $this->lang->line ('common_back')));
        
		//
		// The NEW (or Add) STORE button
		//
        $ret_value['new_button'] = anchor ($controller_uri . '/edit/' . $company->id, ' ',
                                           array ('title' => $this->lang->line('config_store_add')));
                                          
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }
    
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $store 	The store being edited.-
	 * @param $company  The company object that is parent of this $store.- 
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_content_template ($store, $company)
    {
        $ret_value = array ( );
        
    	//
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // General page data
        //
        $ret_value['page_title'] 			  = $this->lang->line ('config_store_edit_page_title');
        $ret_value['fields_required_message'] = $this->lang->line ('common_fields_required_message');
        $ret_value['page_info'] 	 		  = $this->lang->line ('config_store_info');
        
        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/save/' . $store->id, 
        								   	   array ('id' => 'store_form'));
        $ret_value['form_close'] = form_close ( );
        
        //
        // Data about the store parameter
        //
        $ret_value['data'] = array ( );
        
        //
        // Field "Store name"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('config_store_name'), 
        							  'name', 
        							  array ('class'=>'wide required'));
        							  
        $field['input'] = form_input (array ('name' => 'name', 
        							  		 'id'   => 'name', 
        							  		 'value' => $store->name));
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Store address"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('config_store_address'),
        							  'address', 
        							  array ('class' => 'wide required'));
        							  
        $field['input'] = form_textarea (array ('name' => 'address', 
        										'id'   => 'address', 
        										'rows' => 4,
        									    'cols' => 23,
        										'value'=> $store->address));
        
        array_push ($ret_value['data'], $field);

        //
        // Field "Store telephone"
        //
        $field = array ( );
        
        $field ['label'] = form_label ($this->lang->line ('config_store_telephone'), 
        							   'telephone', 
        							   array ('class'=>'wide required'));
        							   
        $field ['input'] = form_input (array ('name' => 'telephone',
        									  'id'   => 'telephone',
        									  'value'=> $store->telephone));

        array_push ($ret_value['data'], $field);
        
        //
        // Field "Company (parent)"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('config_company_name'),
        							  'parent', 
        							  array ('class' => 'wide required'));
		
        //
        // Fill the possible values for the "Company (parent)" field
        //
        $options = array ( );
        
        foreach ($this->company->get_all ( ) as $my_company)
        {
            $options[$my_company->id] = $my_company->name;
        }

        //
        // ... and add a drop down with all the possible values
        //
        $selected       = $company->id;
        $field['input'] = form_dropdown ('parent', $options, $selected);
        
        array_push ($ret_value['data'], $field);

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }

    
    
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @param $store The store object being displayed.
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_buttons_template ($store)
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
        							   		array ('title' => $this->lang->line ('common_back')));
        //
        // The EDIT TERMINALS button should be displayed
        // if the store ID is not NULL
        //
        if ($store->id != NULL)
        {
	        $ret_value['edit_button'] = anchor ('company/terminal_controller/view/' . $store->id . '/', ' ', 
	                                            array ('title' => $this->lang->line ('config_terminal_edit_terminals')));
        }
        else
        {
            $ret_value['edit_button'] = '';
        }

        //
    	// The SAVE (or Submit) button
    	//
    	$ret_value['submit_button'] = anchor ('#', ' ',
        							   	 	  array ('title'   => $this->lang->line ('common_submit'),
        							   	 	  //
        							   	 	  // This code connects this anchor with the Submit functionality
        							   	 	  //
        							   	 	  'onClick' => "return validate_form_data (event, document.forms[0]);"));
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }

    
    
    /**
     * Validates the data entered in the form.-
     *
     * @return A string of error description if any validation rule fails.
     *         An empty string if there were no validation errors.-
     */
    private function _validate_save ( )
    {
    	//
    	// Set the rules that have to be validated
    	//
        $this->form_validation->set_rules ('name', 
        								   $this->lang->line ('config_store_name'), 
        								   'trim|required');
        $this->form_validation->set_rules ('address', 
        								   $this->lang->line ('config_store_address'), 
        								   'trim|required');
        $this->form_validation->set_rules ('telephone', 
        								   $this->lang->line ('config_store_telephone'), 
        								   'trim|required');

        //
        // Start the data validation based on the rules just added
        //
        if ($this->form_validation->run ( ))
        {
        	//
        	// Data is valid, no errors
        	//
        	return '';
        }
        else
        {
        	//
        	// Data is invalid, return an error message with 
        	// a given prefix (' ') and suffix (' ')
        	//
            return validation_errors (' ', ' ');
        }
    }
    
    

    /**
     * Constructor
     */
    function __construct ( )
    {
        parent::__construct ('config');
        
        $this->load->model 	 ('company/company');
        $this->load->model   ('company/store');
        $this->load->library ('parser');
        $this->load->library ('form_validation');
    }

    
    /**
     * The default entry point of this controller.-
     */
    function index ( )
    {
        $this->view ( );
    }

    
    /**
     * Displays multiple stores with a single parent company.
     *
     * @param $company_id is the parent's database id.
     */
    function view ($company_id = NULL)
    {
     	//
    	// Remember this address as a navigation node to come back later
    	//
    	$this->navigation_stack->push ( );
    	
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['active_terminal']     = $this->active_terminal;
        $data['module_name']         = $this->lang->line ('module_config');

        //
        // Did we receive a company ID?
        //
        if ($company_id == NULL)
        {
        	//
        	// Use the first company found as a replacement
        	//
        	$all_companies = $this->company->get_all ( );
        	$company_id    = $all_companies[0]->id;
        }
        
		//
        // Fetch the stores of this company
        //
        $stores = array ( );
        
        foreach ($this->store->get_all ( ) as $store)
        {
            if ($store->get_parent_company ( )->id == $company_id)
            {
                array_push ($stores, $store);
            }
        }
        
        //
        // Fill the page templates with data
        //
        $page_content = $this->_build_table_content_template ($stores,
                                                              $this->company->get_by_id ($company_id));
        $page_buttons = $this->_build_table_buttons_template ($this->company->get_by_id ($company_id));
        
        $data['content'] = $this->parser->parse ('company/table_stores', 
        										 $page_content,
        										 true);
        $data['buttons'] = $this->parser->parse ('table_buttons', 
        										 $page_buttons,
        										 true);
        //
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
    }

    
    /**
     * Displays a form for editing/adding a store.
     *
     * @param $company_id The ID of the parent company.
     * @param $store_id   The ID of the store being displayed.
     */
    function edit ($company_id = NULL, $store_id = NULL)
    {
    	//
    	// Check if we received valid parameters
    	//
    	if ($company_id != NULL)
    	{
	     	//
	    	// Remember this address as a navigation node to come back later
	    	//
	    	$this->navigation_stack->push ( );
	    	
	    	//
	        // The data about the registered employee is held in the parent class
	        //
	        $data['registered_employee'] = $this->registered_employee;
	        $data['active_terminal']     = $this->active_terminal;
	        $data['module_name']         = $this->lang->line ('module_config');
	
	        //
	        // Fetch the store being edited 
	        // (or create a new one, if it is NULL)
	        //
	        $store = new Store ($store_id);
	
	        //
	        // Fill the page templates wih data
	        //
	        $page_content = $this->_build_edit_content_template ($store,
	        													 $this->company->get_by_id ($company_id));
	        $page_buttons = $this->_build_edit_buttons_template ($store);
	        
	        $data['content'] = $this->parser->parse ('edit_common', 
	        										 $page_content, 
	        										 true);
	        										 
	        $data['buttons'] = $this->parser->parse ('company/edit_buttons', 
	        										 $page_buttons,
	        										 true);
	        //
	        // Load and display the edit form
	        //
	        $this->load->view ('skeleton', $data);
    	}
    }
    

    /**
     * Saves the store into the database.
     *
     * @param $id The ID of the store being saved.-
     */
    function save ($id = NULL)
    {
    	//
    	// Validate all data in the form before saving it to the database
    	//
        $errors = $this->_validate_save ( );
        
        //
        // Are there any validation errors?
        //
        if (empty ($errors))
        {
			//
			// No errors. Create a new store object
			// and update its data in the database
			//
	        $store = new Store ($id);

	        $store->name 	   = $this->input->post ('name');
	        $store->address    = $this->input->post ('address');
	        $store->telephone  = $this->input->post ('telephone');
	        $store->company_id = $this->input->post ('parent');
	
	        $store->update ( );

	        //
	        // Return a JSON-encoded message about the successful update
	        //
	        echo json_encode (array ('success' => true, 
	        						 'message' => $this->lang->line ('common_change_successful')));
        }
        else
        {
        	//
        	// Return a JSON-encoded message with the error description
        	//
        	echo json_encode (array ('success' => false, 
        							 'message' => $errors));
        }
    }

    

    /**
     * Deletes a store from the database.
     *
     * @param $id The store ID being deleted.-
     */
    function delete ($id = NULL)
    {
    	//
    	// Did we receive any valid ID?
    	//
    	if ($id != NULL)
    	{
    		//
    		// Delete the store with the given ID
    		//
	        if ($this->store->delete_all (array ($id)))
	        {
	            echo json_encode (array ('success'=>true, 'message'=>$this->lang->line ('common_change_successful')));
	        }
	        else
	        {
	            echo json_encode (array ('success'=>false, 'message'=>$this->lang->line ('common_change_unsuccessful')));
	        }
    	}
    }
}

?>

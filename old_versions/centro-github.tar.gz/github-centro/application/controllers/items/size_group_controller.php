<?php
require_once (APPPATH . '/controllers/secure_area.php');
/**
 * This controller handles the display of different size groups.-
 * 
 * @author luka
 *
 */
class Size_group_controller extends Secure_area
{
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $size_groups  An array containing all size_groups.
     * 
     * @return An array ready to be applied over the template page.-
     */
   	private function _build_table_content_template ($size_groups)
    {
        $ret_value = array ( );
        
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // The title is sizes
        //
        $ret_value['page_title']    = $this->lang->line ('sizes_groups_plural'); 
        //
        // The list column titles
        //
        $ret_value['column_titles'] = array (array ('title' => $this->lang->line ('common_first_name')),
        									 //
        									 // Column for the EDIT button
        									 //
        									 array ('title'=>'&nbsp'),
        									 //
        									 // Column for the DELETE button
        									 //
        									 array ('title'=>'&nbsp'));
        //
        // Display or hide the 'No elements' message?
        //
        if (count ($size_groups) == 0)
        {
            $ret_value['display_status'] = 'display: inline;';
            $ret_value['empty_table']    = $this->lang->line ('common_nothing_to_display');
        }
        else
        {
            $ret_value['display_status'] = 'display: none;';
            $ret_value['empty_table']    = '';
        }

        //
        // Set the actual size_group data for the whole table of records
        //
        $ret_value['table_data'] = array ( );
        
        foreach ($size_groups as $size_group)
        {
            $size_group_data = array ('name'         => $size_group->name,
            
                                      'edit_link'    => anchor ($controller_uri . '/edit/' . $size_group->id, 
            		    						                '...',
            									                array ('title' => $this->lang->line ('common_edit'))),
            										      
                    		          'delete_link'  => anchor ($controller_uri . '/delete/' . $size_group->id . '/',
            									                'x', 
            				                                    array ('id'    => 'delete',
            			                       	 	                   'title' => $this->lang->line ('common_delete'),
					        				   	  	                    //
					        				   	  	                    // This code connects this anchor with the Delete functionality
					        				   	 	                    //
					        				   	 	                    'onClick' => "return delete_table_row (event);")));
        	//
        	// Save the data of the current size_group
        	//
            array_push ($ret_value['table_data'], $size_group_data);
        }

        //
        // Return the dynamic template built
        //
        return $ret_value;
    }
    
 	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
	 *  
     * @return An array ready to be applied over the template page.-
     */
    private function _build_table_buttons_template ( )
    {
    	$ret_value = array ( );
    	
        //
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));
    	
        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
	                                        array ('title' => $this->lang->line ('common_back')));
        
		//
		// The NEW (or Add) SIZE_GROUP button
		//
        $ret_value['new_button'] = anchor ($controller_uri . '/edit/', ' ',
                                           array ('title' => $this->lang->line('sizes_add')));
                                          
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }
    
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     *
     * @param $size_group The size_group being edited.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_content_template ($size_group)
    {
        $ret_value = array ( );
        
    	//
        // The URI of this controller
        //
        $controller_uri = strtolower ($this->uri->segment (1)) . "/" . strtolower ($this->uri->segment (2));

        //
        // General page data
        //
        $ret_value['page_title'] 			  = $this->lang->line ('sizes_edit');
        $ret_value['fields_required_message'] = $this->lang->line ('common_fields_required_message');
        $ret_value['page_info'] 	 		  = $this->lang->line ('sizes_basic_information');
        
        //
        // Form data
        //
        $ret_value['form_open']  = form_open  ($controller_uri . '/save/' . $size_group->id, 
        								   	   array ('id' => 'size_group_form'));
        $ret_value['form_close'] = form_close ( );
        
        //
        // Data about the size_group parameter
        //
        $ret_value['data'] = array ( );
        
        //
        // Field "Size group name"
        //
        $field = array ( );
        
        $field['label'] = form_label ($this->lang->line ('sizes_group_name'), 
        							  'name', 
        							  array ('class'=>'wide required'));
        							  
        $field['input'] = form_input (array ('name' => 'name', 
        							  		 'id'   => 'name', 
        							  		 'value' => $size_group->name));
        
        array_push ($ret_value['data'], $field);

        //
        // Fields "Size_group sizes"
        //
        
        $sizes = $size_group->get_sizes ( );
        for ($i = 0; $i < count ($sizes); $i++)
        {
            $field = array ( );
            
            if ($i == 0)
            {
                $label_attributes = array ('class' => 'wide required');
            }
            else
            {
                $label_attributes = array ('class' => 'wide');
            }
            
            $field['label'] = form_label (($i + 1) . '. ' . $this->lang->line ('sizes_single'),
            							  'size' . $i, 
            							  $label_attributes);
            							  
            $field ['input'] = form_input (array ('name' => 'sizes[]', 
        							  		      'id'   => 'size' . $i, 
        							  		      'value' => $sizes[$i]->name));
    
            array_push ($ret_value['data'], $field);
        }
        
        for ($i; $i < 12; $i++)
        {
            $field = array ( );
            
            if ($i == 0)
            {
                $label_attributes = array ('class' => 'wide required');
            }
            else
            {
                $label_attributes = array ('class' => 'wide');
            }
            
            $field['label'] = form_label (($i + 1) . '. ' .  $this->lang->line ('sizes_single'),
            							  'size' . $i, 
            							  $label_attributes);
            							  
            $field ['input'] = form_input (array ('name' => 'sizes[]', 
        							  		      'id'   => 'size' . $i, 
        							  		      'value' => ''));
    
            array_push ($ret_value['data'], $field);
        }
        
        
        
        //
        // Return the dynamic template built
        //
        return $ret_value;
    }
    
	/**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated buttons.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_edit_buttons_template ( )
    {
        $ret_value = array ( );

        //
        // The BACK button
        //
        $ret_value['back_button'] = anchor ('back', ' ',
        							   		array ('title' => $this->lang->line ('common_back')));

        //
    	// The SAVE (or Submit) button
    	//
    	$ret_value['submit_button'] = anchor ('#', ' ',
        							   	 	  array ('title'   => $this->lang->line ('common_submit'),
        							   	 	  //
        							   	 	  // This code connects this anchor with the Submit functionality
        							   	 	  //
        							   	 	  'onClick' => "return validate_form_data (event, document.forms[0]);"));
    	//
    	// Return the template just built
    	//
    	return $ret_value;
    }
    
	/**
     * Validates the data retrieved from the input.
     *
     * @return a string of errors, if it is an empty string, there were no validation errors
     */
    private function _validate_save ( )
    {
        $this->form_validation->set_rules ('name', $this->lang->line ('sizes_group_name'), 'trim|required');

        if ($this->form_validation->run ( ) == false)
        {
            return validation_errors (' ',' ');
        }
        else
        {
            return '';
        }
    }
    
    
	/**
	 * Constructor
	 */
	function __construct ( )
	{
		parent::__construct  ('items');
		$this->load->model   ("items/size_group");
		$this->load->library ('parser');
        $this->load->library ('form_validation');
	}
	
	
	/**
	 * Entry function
	 */
	function index ( )
	{
		//
        // Prepare the navigation stack to work inside this module
        //
        $this->navigation_stack->push ( );
    	
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['active_terminal']     = $this->active_terminal;
        $data['module_name']         = $this->lang->line ('module_items');
        
        //
        // Fetch the size groups
        //
        $size_groups = $this->size_group->get_all ( );
        
        //
        // Fill the page templates with data
        //
        $page_content = $this->_build_table_content_template ($size_groups);
        $page_buttons = $this->_build_table_buttons_template ( );
        
        $data['content'] = $this->parser->parse ('items/table_size_groups', 
        										 $page_content,
        										 true);
        $data['buttons'] = $this->parser->parse ('table_buttons', 
        										 $page_buttons,
        										 true);
        //
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
	}
	
	/**
	 * Opens the pop-up window that displays all the data related to a size group.-
	 */
	function edit ($size_group_id = NULL)
	{
		//
	    // Remember this address as a navigation node to come back later
	    //
	    $this->navigation_stack->push ( );
	    
	    //
	    // The data about the registered employee is held in the parent class
	    //
	    $data['registered_employee'] = $this->registered_employee;
	    $data['active_terminal']     = $this->active_terminal;
	    $data['module_name']         = $this->lang->line ('module_items');
	
	    //
	    // Fetch the size group being edited
	    //
	    $size_group = new Size_group ($size_group_id);
	
	    //
	    // Fill the page templates wih data
	    //
	    $page_content = $this->_build_edit_content_template ($size_group);
	    $page_buttons = $this->_build_edit_buttons_template ( );
	       
	    $data['content'] = $this->parser->parse ('edit_common', 
	      										 $page_content, 
	       										 true);
	        										 
	    $data['buttons'] = $this->parser->parse ('edit_common_buttons', 
	       										 $page_buttons,
	       										 true);
	    //
	    // Load and display the edit form
	    //
	    $this->load->view ('skeleton', $data);
	}
	
	/**
     * Inserts/updates a category
     */
	function save ($size_group_id = NULL)
	{
	    // Form validation
        $errors = $this->_validate_save ( );
        if ($errors != '')
        {
            echo json_encode (array ('success'=>false, 'message'=>$errors));
            return;
        }
        
        $size_group = new Size_group ($size_group_id);
        $size_group->name = $this->input->post ('name');
        
        $sizes = $this->input->post ('sizes');
        if ($sizes[0] == '')
        {
            //
	        // Return a JSON-encoded message about the unsuccessful update
	        //
	        echo json_encode (array ('success' => false, 
	      						 	 'message' => $this->lang->line ('sizes_no_size_error')));
	        return;        
        }
        
        $size_strings = array ( );
        foreach ($sizes as $size)
        {
            if ($size != '')
            {
                array_push ($size_strings, $size);
            }
        }
        
        
        $size_group->update ( );
        $size_group->replace_sizes ($size_strings);
        
        
        
        //
	    // Return a JSON-encoded message about the successful update
	    //
	    echo json_encode (array ('success' => true, 
	      						 'message' => $this->lang->line ('common_change_successful')));        
	}
	
	/**
     * Deletes a size group from the database.
     *
     * @param $id The size group ID being deleted.-
     */
	function delete ($id = NULL)
	{
	    //
    	// Did we receive any valid ID?
    	//
    	if ($id != NULL)
    	{	
    	    //
    		// Delete the category with the given ID
    		//
	        if ($this->size_group->delete ($id))
	        {
	            echo json_encode (array ('success'=>true, 'message'=>$this->lang->line ('common_change_successful')));
	        }
	        else
	        {
	            echo json_encode (array ('success'=>false, 'message'=>$this->lang->line ('common_change_unsuccessful')));
	        }
    	}
	}
}
?>
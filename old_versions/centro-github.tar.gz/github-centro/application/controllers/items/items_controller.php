<?php
require_once (APPPATH . '/controllers/secure_area.php');


/**
 * This class is the entry point of the items package.
 * 
 * @author luka
 *
 */
class Items_controller extends Secure_area
{
    /**
     * Returns an array containing all template meta variables 
     * replaced with dynamically generated content.-
     * 
     * @return An array ready to be applied over the template page.-
     */
    private function _build_link_content_template ( )
    {
        $ret_value = array ('links' => array ( ));
        
        //
        // General page data
        //
        $ret_value['page_title'] = $this->lang->line ('common_select_submodule');

        //
        // Items link
        //
        $link_data = array ( );
        
        $link_data['link'] = site_url ('items/item_controller');
        $link_data['text'] = $this->lang->line ('items_plural');
        
        array_push ($ret_value['links'], $link_data);
        
        //
        // Categories link
        //
        $link_data = array ( );
        
        $link_data['link'] = site_url ('items/category_controller');
        $link_data['text'] = $this->lang->line ('categories_plural');;
        
        array_push ($ret_value['links'], $link_data);
        
        //
        // Size_group link
        //
        $link_data = array ( );
        
        $link_data['link'] = site_url ('items/size_group_controller');
        $link_data['text'] = $this->lang->line ('sizes_plural');;
        
        array_push ($ret_value['links'], $link_data);
        
        return $ret_value;
    }


    /**
	 * Constructor
	 */
	function __construct ( )
	{
		parent::__construct  ('items');
		$this->load->library ('parser');
	}
	
	/**
     * The default entry point of this controller.-
     */
	public function index ( )
	{
	    //
        // Prepare the navigation stack to work inside this module
        //
        $this->navigation_stack->clear_stack ( );
        $this->navigation_stack->push ( );
    	
        //
        // The data about the registered employee is held in the parent class
        //
        $data['registered_employee'] = $this->registered_employee;
        $data['active_terminal']     = $this->active_terminal;
        $data['module_name']         = $this->lang->line ('module_items');
	    
        //
        // Fill the page templates with data
        //
	    $page_content = $this->_build_link_content_template ( );
	    
	    $data['content'] = $this->parser->parse ('entry_view', 
        										 $page_content,
        										 true);
        										 
        //
        // Load and display the view
        //
        $this->load->view ('skeleton', $data);
	}
}

?>
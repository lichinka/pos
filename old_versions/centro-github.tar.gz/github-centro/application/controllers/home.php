<?php
require_once ("secure_area.php");


class Home extends Secure_area 
{
	/**
	 * Constructor
	 */
	function __construct ( )
	{
		parent::__construct ( );	
	}
	
	function index ( )
	{
		//
		// The data about the registered employee is held in the parent class
		//
		$data = array ('registered_employee' => $this->registered_employee, 
		               'active_terminal'     => $this->active_terminal);

		$this->load->view ('home', $data);
	}

	
	/**
	 * Logs out the current logged in employee.-
	 */
	function logout ( )
	{
		$this->employee->logout ( );
		redirect ('login');
	}
}
?>